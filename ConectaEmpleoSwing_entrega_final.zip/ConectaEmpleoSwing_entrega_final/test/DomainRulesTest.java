import Main.Main;
import controlador.CapacitacionesController;
import controlador.DashboardController;
import controlador.DocumentosController;
import controlador.EmpresasController;
import controlador.HabilidadesController;
import controlador.LoginController;
import controlador.OfertasController;
import controlador.PostulacionesController;
import controlador.TrabajadoresController;
import modelo.DatosAplicacion;
import modelo.Documento;
import modelo.EstadoPostulacion;
import utilidades.ArchivoUtil;
import utilidades.DatosIniciales;
import utilidades.Theme;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

/** Smoke tests funcionales sin dependencias de JUnit; se ejecutan con ant test. */
public final class DomainRulesTest {
    private static int assertions;

    private DomainRulesTest() {
    }

    public static void main(String[] args) throws Exception {
        Path carpetaPruebas = Path.of("build", "test-tmp").toAbsolutePath();
        Files.createDirectories(carpetaPruebas);
        Path raizTemporal = Files.createTempDirectory(carpetaPruebas, "conectaempleo-pruebas-");
        try {
            probarResolucionDirectorioDatos(raizTemporal);
            probarInicioDeSesionYDatosIniciales(raizTemporal.resolve("login"));
            probarCambioDeContrasena(raizTemporal.resolve("cambio-clave"));
            probarModulosRelacionesYRoles(raizTemporal.resolve("modulos"));
            probarPersistenciaPdfYTransparencia(raizTemporal.resolve("persistencia"), raizTemporal);
            System.out.println("OK: " + assertions + " comprobaciones funcionales.");
        } finally {
            eliminarArbol(raizTemporal);
        }
    }

    private static void probarInicioDeSesionYDatosIniciales(Path raiz) throws Exception {
        DatosAplicacion datos = nuevaAplicacion(raiz);
        LoginController login = new LoginController(datos);
        comprobar(login.iniciar("admin", "admin123".toCharArray()), "acceso administrador");
        comprobar(datos.esAdministrador(), "rol administrador");
        login.cerrar();
        comprobar(login.iniciar("recicaribe", "empresa123".toCharArray()), "acceso empresa");
        comprobar(datos.esEmpresa(), "rol empresa");
        login.cerrar();
        comprobar(login.iniciar("andrea", "trabajador123".toCharArray()), "acceso trabajador");
        comprobar(datos.esTrabajador(), "rol trabajador");
        login.cerrar();
        comprobar(!login.iniciar("admin", "incorrecta".toCharArray()), "rechaza contraseña incorrecta");
        comprobar(datos.trabajadores.size() == 10 && datos.empresas.size() == 5,
                "carga los datos de ejemplo una sola vez");
        DatosIniciales.inicializar(datos);
        comprobar(datos.trabajadores.size() == 10 && datos.empresas.size() == 5
                && datos.ofertas.size() == 8, "no duplica la demostración si se inicializa de nuevo");
    }

    private static void probarCambioDeContrasena(Path raiz) throws Exception {
        DatosAplicacion datos = nuevaAplicacion(raiz);
        LoginController login = new LoginController(datos);
        comprobar(login.iniciar("admin", "admin123".toCharArray()), "inicia sesión antes del cambio de clave");
        comprobar(excepcion(IllegalArgumentException.class, () -> login.cambiarContrasena(
                "incorrecta".toCharArray(), "ClaveNueva123".toCharArray())),
                "rechaza una contraseña actual incorrecta");
        comprobar(excepcion(IllegalArgumentException.class, () -> login.cambiarContrasena(
                "admin123".toCharArray(), "corta".toCharArray())),
                "rechaza una contraseña nueva demasiado corta");
        login.cambiarContrasena("admin123".toCharArray(), "ClaveNueva123".toCharArray());
        login.cerrar();
        comprobar(!login.iniciar("admin", "admin123".toCharArray()), "rechaza la clave anterior después del cambio");
        comprobar(login.iniciar("admin", "ClaveNueva123".toCharArray()), "acepta la nueva clave después del cambio");
        login.cerrar();
        DatosAplicacion recargados = ArchivoUtil.cargar(raiz);
        comprobar(new LoginController(recargados).iniciar("admin", "ClaveNueva123".toCharArray()),
                "conserva la nueva clave al recargar los TXT");
    }

    private static void probarModulosRelacionesYRoles(Path raiz) throws Exception {
        DatosAplicacion datos = nuevaAplicacion(raiz);
        iniciar(datos, "admin", "admin123");

        TrabajadoresController trabajadores = new TrabajadoresController(datos);
        Map<String, String> nuevoTrabajador = mapa(
                "nombre", "Prueba Persona", "documento", "CC 9000000001", "correo", "prueba@demo.co",
                "telefono", "+57 300 555 8899", "ubicacion", "Cartagena", "nivel", "Técnico",
                "disponibilidad", "Disponible", "experiencia", "Experiencia de prueba",
                "habilidades", "Excel", "usuario", "prueba", "password", "prueba123");
        trabajadores.save(null, nuevoTrabajador);
        int idTrabajadorNuevo = datos.trabajadores.get(datos.trabajadores.size() - 1).getId();
        comprobar(trabajadores.rows().size() == 11, "crear trabajador");
        trabajadores.save(idTrabajadorNuevo, mapa("nombre", "Persona Editada", "documento", "CC 9000000001",
                "correo", "prueba@demo.co", "telefono", "+57 300 555 8899", "ubicacion", "Turbaco",
                "nivel", "Profesional", "disponibilidad", "En búsqueda", "experiencia", "Actualizada",
                "habilidades", "Excel, Gestión ambiental", "password", ""));
        comprobar(datos.trabajadores.get(datos.trabajadores.size() - 1).getNombre().equals("Persona Editada"),
                "editar trabajador");

        EmpresasController empresas = new EmpresasController(datos);
        empresas.save(null, mapa("nombre", "Empresa de Prueba", "nit", "901000001-9", "sector", "Reciclaje",
                "correo", "empresa@prueba.co", "telefono", "+57 300 555 9900", "direccion", "Cartagena",
                "usuario", "empresaPrueba", "password", "empresa123"));
        int idEmpresaNueva = datos.empresas.get(datos.empresas.size() - 1).getId();
        comprobar(empresas.rows().size() == 6, "crear empresa");
        empresas.save(idEmpresaNueva, mapa("nombre", "Empresa Editada", "nit", "901000001-9",
                "sector", "Economía circular", "correo", "empresa@prueba.co", "telefono", "+57 300 555 9900",
                "direccion", "Turbaco", "password", ""));
        comprobar(datos.empresas.get(datos.empresas.size() - 1).getNombre().equals("Empresa Editada"),
                "editar empresa");

        OfertasController ofertas = new OfertasController(datos);
        Map<String, String> nuevaOferta = mapa("empresa", idEmpresaNueva + " - Empresa Editada", "cargo", "Cargo de prueba",
                "descripcion", "Descripción", "requisitos", "Requisitos", "habilidades", "Excel",
                "vacantes", "2", "ubicacion", "Cartagena", "contrato", "Indefinido", "salario", "2500000",
                "publicacion", LocalDate.now().toString(), "limite", LocalDate.now().plusDays(20).toString(),
                "estado", "ACTIVA");
        ofertas.save(null, nuevaOferta);
        int idOfertaNueva = datos.ofertas.get(datos.ofertas.size() - 1).getId();
        comprobar(datos.ofertas.size() == 9, "crear oferta");
        nuevaOferta.put("cargo", "Cargo editado");
        ofertas.save(idOfertaNueva, nuevaOferta);
        comprobar(datos.ofertas.get(datos.ofertas.size() - 1).getCargo().equals("Cargo editado"), "editar oferta");
        comprobar(excepcion(IllegalArgumentException.class, () -> ofertas.delete(1)),
                "bloquea borrar oferta con postulaciones relacionadas");
        comprobar(datos.postulaciones.size() == 12, "no elimina postulaciones relacionadas en cascada");

        PostulacionesController postulaciones = new PostulacionesController(datos);
        comprobar(excepcion(IllegalArgumentException.class, () -> empresas.delete(1)),
                "bloquea borrar empresa con ofertas relacionadas");
        comprobar(datos.ofertas.size() == 9, "no elimina ofertas relacionadas en cascada");
        comprobar(excepcion(IllegalArgumentException.class, () -> trabajadores.delete(1)),
                "bloquea borrar trabajador con postulaciones relacionadas");
        comprobar(datos.postulaciones.size() == 12, "conserva postulaciones tras intento de baja");

        HabilidadesController habilidades = new HabilidadesController(datos);
        habilidades.save(null, mapa("nombre", "Habilidad temporal", "categoria", "Prueba"));
        int idHabilidadNueva = datos.habilidades.get(datos.habilidades.size() - 1).getId();
        habilidades.save(idHabilidadNueva, mapa("nombre", "Habilidad editada", "categoria", "Prueba"));
        comprobar(datos.habilidades.stream().anyMatch(h -> h.getNombre().equals("Habilidad editada")),
                "crear y editar habilidad");
        comprobar(excepcion(IllegalArgumentException.class, () -> habilidades.delete(1)),
                "bloquea borrar habilidad asociada a perfiles");

        CapacitacionesController capacitaciones = new CapacitacionesController(datos);
        capacitaciones.save(null, mapa("nombre", "Curso temporal", "entidad", "SENA", "descripcion", "Curso",
                "inicio", LocalDate.now().plusDays(30).toString(), "fin", LocalDate.now().plusDays(37).toString(),
                "cupos", "5"));
        int idCursoNuevo = datos.capacitaciones.get(datos.capacitaciones.size() - 1).getId();
        capacitaciones.save(idCursoNuevo, mapa("nombre", "Curso editado", "entidad", "SENA",
                "descripcion", "Curso actualizado", "inicio", LocalDate.now().plusDays(30).toString(),
                "fin", LocalDate.now().plusDays(37).toString(), "cupos", "5"));
        comprobar(datos.capacitaciones.get(datos.capacitaciones.size() - 1).getNombre().equals("Curso editado"),
                "crear y editar capacitación");

        DashboardController dashboard = new DashboardController(datos);
        comprobar(dashboard.metricas().get("Ofertas") == 9 && dashboard.metricas().get("Postulaciones") == 12,
                "dashboard obtiene conteos de listas reales tras el CRUD");
        comprobar(dashboard.estadosOfertas().values().stream().mapToInt(Integer::intValue).sum()
                == datos.ofertas.size(), "estadísticas de ofertas incluyen sus estados reales");
        comprobar(dashboard.estadosPostulaciones().values().stream().mapToInt(Integer::intValue).sum()
                == datos.postulaciones.size(), "estadísticas de postulaciones incluyen sus estados reales");
        comprobar(dashboard.trabajadoresRecientes(3).get(0).getId()
                > dashboard.trabajadoresRecientes(3).get(1).getId(), "actividad reciente ordenada por registro");
        comprobar(dashboard.ofertasRecientes(3).size() == 3
                && dashboard.postulacionesRecientes(3).size() == 3, "dashboard muestra actividad reciente real");
        comprobar(new vista.EstadisticasView(datos).getComponentCount() > 0,
                "estadísticas se presentan en una pantalla separada");
        DatosAplicacion vacios = new DatosAplicacion(raiz.resolve("estadisticas-vacias"));
        vacios.administradores.add(datos.administradores.get(0));
        vacios.setUsuarioActual(datos.administradores.get(0));
        comprobar(new vista.EstadisticasView(vacios).getComponentCount() > 0
                && new DashboardController(vacios).estadosOfertas().values().stream()
                        .allMatch(cantidad -> cantidad == 0), "gráficos funcionan sin registros");

        // Las operaciones creadas por administración se guardan en archivo y se recargan sin sesión.
        iniciar(datos, "admin", "admin123");
        DatosAplicacion recargados = ArchivoUtil.cargar(raiz);
        comprobar(recargados.trabajadores.size() == 11 && recargados.empresas.size() == 6
                && recargados.ofertas.size() == 9, "persistencia de trabajadores, empresas y ofertas");

        iniciar(datos, "andrea", "trabajador123");
        comprobar(excepcion(SecurityException.class, dashboard::estadosOfertas),
                "trabajador no accede a estadísticas administrativas");
        comprobar(!trabajadores.canCreate() && trabajadores.canEdit() && !trabajadores.canDelete(),
                "permisos CRUD de trabajador");
        comprobar(trabajadores.rows().size() == 1, "trabajador solo ve su perfil");
        comprobar(excepcion(SecurityException.class, () -> trabajadores.fields(2)),
                "trabajador no puede editar perfiles ajenos");
        comprobar(excepcion(SecurityException.class, () -> ofertas.save(null, nuevaOferta)),
                "trabajador no puede publicar ofertas");
        comprobar(excepcion(SecurityException.class, () -> postulaciones.fields(1)),
                "trabajador no puede gestionar estado de postulaciones");
        comprobar(!postulaciones.rows().isEmpty()
                && postulaciones.rows().stream().allMatch(fila -> fila[2].equals("Andrea Mercado")),
                "trabajador ve solamente sus postulaciones");
        int cantidadPostulaciones = datos.postulaciones.size();
        postulaciones.postular(idOfertaNueva);
        comprobar(datos.postulaciones.size() == cantidadPostulaciones + 1, "crear postulación");
        comprobar(excepcion(IllegalArgumentException.class, () -> postulaciones.postular(idOfertaNueva)),
                "rechaza postulación duplicada");
        int idPostulacionNueva = datos.postulaciones.get(datos.postulaciones.size() - 1).getId();
        postulaciones.delete(idPostulacionNueva);
        comprobar(datos.postulaciones.size() == cantidadPostulaciones, "retirar postulación propia");
        capacitaciones.runAction(idCursoNuevo);
        comprobar(datos.capacitaciones.stream().filter(c -> c.getId() == idCursoNuevo).findFirst()
                .orElseThrow().getParticipanteIds().contains(1), "inscripción de trabajador a curso");
        capacitaciones.runAction(idCursoNuevo);
        comprobar(!datos.capacitaciones.stream().filter(c -> c.getId() == idCursoNuevo).findFirst()
                .orElseThrow().getParticipanteIds().contains(1), "retiro de capacitación");
        habilidades.save(null, mapa("nombre", "Competencia personal"));
        comprobar(datos.trabajadores.get(0).getHabilidades().contains("Competencia personal"),
                "trabajador agrega habilidad a su perfil");
        int idCompetencia = datos.habilidades.stream().filter(h -> h.getNombre().equals("Competencia personal"))
                .findFirst().orElseThrow().getId();
        habilidades.runAction(idCompetencia);
        comprobar(!datos.trabajadores.get(0).getHabilidades().contains("Competencia personal"),
                "trabajador quita habilidad de su perfil");

        iniciar(datos, "recicaribe", "empresa123");
        comprobar(excepcion(SecurityException.class, dashboard::estadosPostulaciones),
                "empresa no accede a estadísticas administrativas");
        comprobar(!empresas.canCreate() && empresas.canEdit() && !empresas.canDelete(), "permisos CRUD de empresa");
        comprobar(empresas.rows().size() == 1, "empresa solo ve su perfil");
        comprobar(ofertas.rows().stream().allMatch(fila -> fila[2].toString().equals("Recicla Caribe SAS")),
                "empresa solo ve sus ofertas");
        comprobar(excepcion(SecurityException.class, () -> empresas.fields(2)), "empresa no ve otra empresa");
        comprobar(excepcion(SecurityException.class, () -> trabajadores.fields(idTrabajadorNuevo)),
                "empresa no ve trabajador sin postulación a sus ofertas");
        comprobar(postulaciones.canEdit() && postulaciones.rows().stream()
                .allMatch(fila -> fila[4].toString().equals("Recicla Caribe SAS")),
                "empresa ve postulaciones de sus ofertas");
        PostulacionesController postulacionesEmpresa = new PostulacionesController(datos);
        int idPostulacionEmpresa = ((Number) postulacionesEmpresa.rows().get(0)[0]).intValue();
        postulacionesEmpresa.save(idPostulacionEmpresa, mapa("estado", EstadoPostulacion.EN_REVISION.name()));
        comprobar(datos.postulaciones.stream().anyMatch(p -> p.getId() == idPostulacionEmpresa
                && p.getEstado() == EstadoPostulacion.EN_REVISION), "empresa actualiza el estado");
        comprobar(excepcion(SecurityException.class, () -> capacitaciones.save(null, Map.of())),
                "empresa no puede crear capacitación");

        iniciar(datos, "admin", "admin123");
        ofertas.delete(idOfertaNueva);
        comprobar(datos.ofertas.size() == 8, "eliminar oferta sin postulaciones relacionadas");
        empresas.delete(idEmpresaNueva);
        comprobar(datos.empresas.size() == 5, "eliminar empresa sin ofertas relacionadas");
        trabajadores.delete(idTrabajadorNuevo);
        comprobar(datos.trabajadores.size() == 10, "eliminar trabajador sin relaciones activas");
        capacitaciones.delete(idCursoNuevo);
        comprobar(datos.capacitaciones.size() == 5, "eliminar capacitación sin inscritos");
        habilidades.delete(idHabilidadNueva);
        habilidades.delete(idCompetencia);
        comprobar(datos.habilidades.stream().noneMatch(h -> h.getId() == idHabilidadNueva
                || h.getId() == idCompetencia), "eliminar habilidades sin trabajadores relacionados");
    }

    private static void probarPersistenciaPdfYTransparencia(Path raiz, Path temporal) throws Exception {
        DatosAplicacion datos = nuevaAplicacion(raiz);
        iniciar(datos, "admin", "admin123");
        Path pdf = temporal.resolve("hoja-prueba.pdf");
        try (PDDocument documento = new PDDocument()) {
            documento.addPage(new PDPage());
            documento.save(pdf.toFile());
        }
        DocumentosController documentos = new DocumentosController(datos);
        comprobar(documentos.inspect(pdf).toLowerCase().contains("página"), "lectura de PDFBox");
        documentos.importPdf(1, pdf, false);
        comprobar(documentos.rows().size() == 1 && documentos.hasCv(1), "importación de hoja de vida");
        Documento primeraCopia = datos.documentos.get(0);
        comprobar(Files.exists(raiz.resolve(primeraCopia.getRutaRelativa())),
                "copia PDF dentro de datos/documentos");
        documentos.importPdf(1, pdf, true);
        comprobar(datos.documentos.size() == 1, "reemplazo de PDF sin duplicar documentos");
        comprobar(!Files.exists(raiz.resolve(primeraCopia.getRutaRelativa())), "reemplazo elimina la copia anterior");
        Documento registro = datos.documentos.get(0);

        iniciar(datos, "andrea", "trabajador123");
        comprobar(documentos.rows().size() == 1 && documentos.canModify(), "trabajador ve su propio PDF");
        comprobar(excepcion(SecurityException.class, () -> documentos.open(999)),
                "bloquea la apertura de PDF ajeno o inexistente");
        iniciar(datos, "trabajador2", "trabajador123");
        comprobar(documentos.rows().isEmpty(), "otro trabajador no ve el PDF");
        comprobar(excepcion(SecurityException.class, () -> documentos.open(registro.getId())),
                "otro trabajador no puede abrir el PDF ajeno");
        iniciar(datos, "recicaribe", "empresa123");
        comprobar(documentos.rows().size() == 1, "empresa ve CV de candidato a sus ofertas");
        comprobar(excepcion(SecurityException.class, () -> documentos.delete(registro.getId())),
                "empresa no puede eliminar CV de candidato");
        iniciar(datos, "admin", "admin123");
        documentos.delete(registro.getId());
        comprobar(datos.documentos.isEmpty() && !documentos.hasCv(1), "elimina el registro y archivo PDF");

        Theme.install();
        JPanel tarjeta = Theme.card();
        JButton boton = Theme.button("Guardar", Theme.TipoBoton.PRINCIPAL);
        JTextField campo = Theme.textField("", 12);
        JComboBox<String> combo = Theme.comboBox(new String[]{"A", "B"});
        JTable tabla = new JTable(1, 1);
        Theme.styleTable(tabla);
        JScrollPane scroll = Theme.scrollPane(tabla, Theme.SURFACE);
        comprobar(tarjeta.isOpaque() && tarjeta.getBackground().equals(Theme.SURFACE), "opacidad y fondo de tarjeta");
        comprobar(!boton.isOpaque() && !boton.isContentAreaFilled()
                && fondoPintado(boton, Theme.GREEN), "el botón principal pinta su fondo verde sin transparencia");
        comprobar(campo.isOpaque() && campo.getBackground().equals(Color.WHITE), "opacidad de campo de texto");
        comprobar(combo.isOpaque() && combo.getBackground().equals(Color.WHITE), "opacidad del selector");
        comprobar(tabla.isOpaque() && tabla.getTableHeader().isOpaque(), "opacidad de tabla y cabecera");
        comprobar(scroll.isOpaque() && scroll.getViewport().isOpaque(), "opacidad del scroll y viewport");
        probarEstilosDeBotones();

        DatosAplicacion recargados = ArchivoUtil.cargar(raiz);
        comprobar(recargados.documentos.isEmpty() && recargados.trabajadores.size() == 10,
                "lectura de listas desde archivos de texto");
        comprobar(recargados.getUsuarioActual() == null, "la sesión no se persiste");
        comprobar(Files.isRegularFile(raiz.resolve("datos/trabajadores.txt"))
                && Files.readString(raiz.resolve("datos/trabajadores.txt")).contains("Andrea Mercado"),
                "archivo TXT legible con datos de trabajadores");
        try (var archivos = Files.list(raiz.resolve("datos"))) {
            comprobar(archivos.filter(Files::isRegularFile).count() == 8,
                    "ocho colecciones vigentes en archivos TXT dentro de datos");
        }
        comprobar(!Files.exists(raiz.resolve("datos/materiales.txt")),
                "no se recrea la persistencia del módulo eliminado");
        try (var rutas = Files.walk(raiz.resolve("datos"))) {
            comprobar(rutas.noneMatch(ruta -> {
                String nombre = ruta.getFileName() == null ? "" : ruta.getFileName().toString().toLowerCase();
                return nombre.endsWith(".ser") || nombre.endsWith(".dat") || nombre.endsWith(".tmp");
            }), "no crea archivos de serialización ni temporales");
        }
    }

    private static void probarEstilosDeBotones() {
        JButton editar = Theme.button("Editar", Theme.TipoBoton.EDITAR);
        JButton consultar = Theme.button("Consultar", Theme.TipoBoton.CONSULTAR);
        JButton eliminar = Theme.button("Eliminar", Theme.TipoBoton.ELIMINAR);
        JButton cancelar = Theme.button("Cancelar", Theme.TipoBoton.CANCELAR);
        JButton navegacion = Theme.button("Módulo", Theme.TipoBoton.NAVEGACION);
        JButton seleccionado = Theme.button("Activo", Theme.TipoBoton.NAVEGACION_SELECCIONADA);
        comprobar(!editar.getBackground().equals(Theme.GREEN), "editar tiene identidad azul petróleo");
        comprobar(consultar.getForeground().equals(Theme.TEAL), "consultar tiene identidad turquesa");
        comprobar(eliminar.getBackground().equals(Theme.RED), "eliminar tiene identidad roja moderada");
        comprobar(cancelar.getBackground().equals(Theme.PALE_GRAY), "cancelar tiene identidad gris clara");
        comprobar(navegacion.getBackground().equals(Theme.NAV_BUTTON), "navegación usa un azul más claro que la barra");
        comprobar(fondoPintado(navegacion, Theme.NAV_BUTTON),
                "el fondo normal de navegación se pinta opaco");
        java.awt.Color navReposo = navegacion.getBackground();
        navegacion.getModel().setRollover(true);
        comprobar(!navegacion.getBackground().equals(navReposo), "navegación cambia a verde al pasar el cursor");
        comprobar(fondoPintado(navegacion, new Color(0x09916A)),
                "el fondo hover de navegación se pinta opaco");
        navegacion.getModel().setRollover(false);
        comprobar(seleccionado.getBackground().equals(Theme.GREEN)
                && seleccionado.getForeground().equals(java.awt.Color.WHITE), "módulo activo queda resaltado en verde");
        comprobar(fondoPintado(seleccionado, Theme.GREEN),
                "el fondo del módulo seleccionado se pinta opaco");
        java.awt.Color reposo = consultar.getBackground();
        consultar.getModel().setRollover(true);
        comprobar(!consultar.getBackground().equals(reposo), "botón cambia de aspecto al pasar el cursor");
        consultar.getModel().setRollover(false);
        consultar.setEnabled(false);
        comprobar(consultar.getBackground().equals(Theme.PALE_GRAY), "botón deshabilitado tiene estado visible");
    }

    private static boolean fondoPintado(JButton boton, Color esperado) {
        boton.setSize(200, 44);
        BufferedImage imagen = new BufferedImage(200, 44, BufferedImage.TYPE_INT_RGB);
        Graphics2D graficos = imagen.createGraphics();
        boton.paint(graficos);
        graficos.dispose();
        return new Color(imagen.getRGB(190, 22)).equals(esperado);
    }

    private static DatosAplicacion nuevaAplicacion(Path raiz) throws Exception {
        Files.createDirectories(raiz);
        DatosAplicacion datos = ArchivoUtil.cargar(raiz);
        DatosIniciales.inicializar(datos);
        return datos;
    }

    private static void probarResolucionDirectorioDatos(Path raizTemporal) throws Exception {
        Path raizProyecto = raizTemporal.resolve("proyecto").toAbsolutePath().normalize();
        Path clases = raizProyecto.resolve("build").resolve("classes");
        Files.createDirectories(clases);
        Path jar = raizProyecto.resolve("dist").resolve("ConectaEmpleoSwing.jar");
        comprobar(Main.resolverDirectorioDatos(clases).equals(raizProyecto),
                "NetBeans guarda los datos junto al proyecto y no dentro de build/classes");
        comprobar(Main.resolverDirectorioDatos(jar).equals(raizProyecto),
                "el JAR guarda los datos junto al proyecto y no dentro de dist");
    }

    private static void iniciar(DatosAplicacion datos, String usuario, String clave) {
        boolean entro = new LoginController(datos).iniciar(usuario, clave.toCharArray());
        comprobar(entro, "inicio de sesión " + usuario);
    }

    private static Map<String, String> mapa(String... pares) {
        Map<String, String> valores = new HashMap<>();
        for (int i = 0; i < pares.length; i += 2) valores.put(pares[i], pares[i + 1]);
        return valores;
    }

    private static boolean excepcion(Class<? extends Throwable> tipo, AccionDePrueba accion) {
        try {
            accion.ejecutar();
            return false;
        } catch (Throwable error) {
            return tipo.isInstance(error);
        }
    }

    @FunctionalInterface
    private interface AccionDePrueba {
        void ejecutar() throws Exception;
    }

    private static void comprobar(boolean condicion, String mensaje) {
        assertions++;
        if (!condicion) throw new AssertionError("Falló: " + mensaje);
    }

    private static void eliminarArbol(Path raiz) throws Exception {
        if (!Files.exists(raiz)) return;
        try (var rutas = Files.walk(raiz)) {
            rutas.sorted((a, b) -> b.getNameCount() - a.getNameCount()).forEach(ruta -> {
                try {
                    Files.deleteIfExists(ruta);
                } catch (Exception ex) {
                    throw new IllegalStateException("No se pudo limpiar " + ruta, ex);
                }
            });
        }
    }
}
