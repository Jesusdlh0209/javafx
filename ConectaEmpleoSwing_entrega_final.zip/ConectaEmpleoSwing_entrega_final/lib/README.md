PDFBox 3.0.7 en formato app está incluido para que el proyecto Ant compile sin buscar una copia externa. La referencia del JAR es relativa y está declarada en nbproject/project.properties.
