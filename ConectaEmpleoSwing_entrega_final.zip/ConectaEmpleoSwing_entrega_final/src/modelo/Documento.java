package modelo;

import java.time.LocalDateTime;

/** Metadatos de una hoja de vida guardada localmente. */
public final class Documento {
    private final int id;
    private final int trabajadorId;
    private String nombre;
    private String rutaRelativa;
    private final long bytes;
    private final LocalDateTime agregado;

    public Documento(int id, int trabajadorId, String nombre, String rutaRelativa,
            long bytes, LocalDateTime agregado) {
        this.id = id;
        this.trabajadorId = trabajadorId;
        this.nombre = nombre;
        this.rutaRelativa = rutaRelativa;
        this.bytes = bytes;
        this.agregado = agregado;
    }

    public int getId() {
        return id;
    }

    public int getTrabajadorId() {
        return trabajadorId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRutaRelativa() {
        return rutaRelativa;
    }

    public long getBytes() {
        return bytes;
    }

    public LocalDateTime getAgregado() {
        return agregado;
    }
}
