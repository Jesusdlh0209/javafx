package modelo;

/** Estados posibles del proceso de selección. */
public enum EstadoPostulacion {
    PENDIENTE,
    EN_REVISION,
    ENTREVISTA,
    SELECCIONADA,
    RECHAZADA
}
