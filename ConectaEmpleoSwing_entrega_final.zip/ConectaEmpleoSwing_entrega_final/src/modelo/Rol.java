package modelo;

public enum Rol {
    ADMINISTRADOR("Administrador"), EMPRESA("Empresa"), TRABAJADOR("Trabajador");

    private final String etiqueta;

    Rol(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }
}
