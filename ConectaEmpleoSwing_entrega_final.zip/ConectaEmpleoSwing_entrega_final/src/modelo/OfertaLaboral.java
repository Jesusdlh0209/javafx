package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Vacante publicada por una empresa. */
public final class OfertaLaboral {
    private final int id;
    private int empresaId;
    private String cargo;
    private String descripcion;
    private String requisitos;
    private String ubicacion;
    private String tipoContrato;
    private List<String> habilidades;
    private int vacantes;
    private double salario;
    private LocalDate fechaPublicacion;
    private LocalDate fechaLimite;
    private EstadoOferta estado;

    public OfertaLaboral(int id, int empresaId, String cargo, String descripcion,
            String requisitos, List<String> habilidades, int vacantes, String ubicacion,
            String tipoContrato, double salario, LocalDate fechaPublicacion,
            LocalDate fechaLimite, EstadoOferta estado) {
        this.id = id;
        this.empresaId = empresaId;
        this.cargo = limpio(cargo);
        this.descripcion = limpio(descripcion);
        this.requisitos = limpio(requisitos);
        this.habilidades = new ArrayList<>(habilidades);
        this.vacantes = vacantes;
        this.ubicacion = limpio(ubicacion);
        this.tipoContrato = limpio(tipoContrato);
        this.salario = salario;
        this.fechaPublicacion = fechaPublicacion;
        this.fechaLimite = fechaLimite;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public int getEmpresaId() {
        return empresaId;
    }

    public void setEmpresaId(int empresaId) {
        this.empresaId = empresaId;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = limpio(cargo);
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = limpio(descripcion);
    }

    public String getRequisitos() {
        return requisitos;
    }

    public void setRequisitos(String requisitos) {
        this.requisitos = limpio(requisitos);
    }

    public List<String> getHabilidades() {
        return List.copyOf(habilidades);
    }

    public void setHabilidades(List<String> habilidades) {
        this.habilidades = new ArrayList<>(habilidades);
    }

    public int getVacantes() {
        return vacantes;
    }

    public void setVacantes(int vacantes) {
        this.vacantes = vacantes;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = limpio(ubicacion);
    }

    public String getTipoContrato() {
        return tipoContrato;
    }

    public void setTipoContrato(String tipoContrato) {
        this.tipoContrato = limpio(tipoContrato);
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public LocalDate getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(LocalDate fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public LocalDate getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(LocalDate fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public EstadoOferta getEstado() {
        return estado;
    }

    public void setEstado(EstadoOferta estado) {
        this.estado = estado;
    }

    public boolean estaDisponible() {
        return estado == EstadoOferta.ACTIVA
                && (fechaLimite == null || !fechaLimite.isBefore(LocalDate.now()));
    }

    private static String limpio(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
