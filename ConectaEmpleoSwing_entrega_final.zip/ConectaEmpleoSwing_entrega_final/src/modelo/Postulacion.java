package modelo;

import java.time.LocalDate;

public final class Postulacion {
    private final int id;
    private final int trabajadorId;
    private final int ofertaId;
    private final LocalDate fecha;
    private EstadoPostulacion estado;

    public Postulacion(int id, int trabajadorId, int ofertaId, LocalDate fecha,
            EstadoPostulacion estado) {
        this.id = id;
        this.trabajadorId = trabajadorId;
        this.ofertaId = ofertaId;
        this.fecha = fecha;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public int getTrabajadorId() {
        return trabajadorId;
    }

    public int getOfertaId() {
        return ofertaId;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public EstadoPostulacion getEstado() {
        return estado;
    }

    public void setEstado(EstadoPostulacion estado) {
        this.estado = estado;
    }
}
