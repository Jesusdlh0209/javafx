package modelo;

import java.util.LinkedHashSet;
import java.util.Set;

/** Habilidad del catálogo y trabajadores que la tienen asociada. */
public final class Habilidad {
    private final int id;
    private String nombre;
    private String categoria;
    private Set<Integer> trabajadorIds = new LinkedHashSet<>();

    public Habilidad(int id, String nombre, String categoria) {
        this.id = id;
        this.nombre = limpio(nombre);
        this.categoria = limpio(categoria);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = limpio(nombre);
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = limpio(categoria);
    }

    public Set<Integer> getTrabajadorIds() {
        return Set.copyOf(trabajadorIds);
    }

    public void setTrabajadorIds(Set<Integer> trabajadorIds) {
        this.trabajadorIds = trabajadorIds == null
                ? new LinkedHashSet<>() : new LinkedHashSet<>(trabajadorIds);
    }

    private static String limpio(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
