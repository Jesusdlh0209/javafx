package modelo;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

/** Curso disponible para los trabajadores y sus inscripciones. */
public final class Capacitacion {
    private final int id;
    private String nombre;
    private String entidad;
    private String descripcion;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private int cupos;
    private Set<Integer> participanteIds = new LinkedHashSet<>();

    public Capacitacion(int id, String nombre, String entidad, String descripcion,
            LocalDate fechaInicio, LocalDate fechaFin, int cupos) {
        this.id = id;
        this.nombre = limpio(nombre);
        this.entidad = limpio(entidad);
        this.descripcion = limpio(descripcion);
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.cupos = cupos;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = limpio(nombre);
    }

    public String getEntidad() {
        return entidad;
    }

    public void setEntidad(String entidad) {
        this.entidad = limpio(entidad);
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = limpio(descripcion);
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public int getCupos() {
        return cupos;
    }

    public void setCupos(int cupos) {
        this.cupos = cupos;
    }

    public Set<Integer> getParticipanteIds() {
        return Set.copyOf(participanteIds);
    }

    public void setParticipanteIds(Set<Integer> participanteIds) {
        this.participanteIds = participanteIds == null
                ? new LinkedHashSet<>() : new LinkedHashSet<>(participanteIds);
    }

    private static String limpio(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
