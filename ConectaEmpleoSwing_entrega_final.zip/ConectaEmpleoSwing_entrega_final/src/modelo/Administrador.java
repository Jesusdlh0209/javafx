package modelo;

/** Usuario con permisos para administrar los registros del sistema. */
public final class Administrador extends Usuario {
    public Administrador(int id, String nombre, String usuario, String correo,
            String telefono, String passwordHash) {
        super(id, nombre, usuario, correo, telefono, passwordHash);
    }

    @Override
    public Rol getRol() {
        return Rol.ADMINISTRADOR;
    }
}
