package modelo;

import utilidades.ArchivoUtil;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Las listas que usa toda la aplicación y el usuario de la sesión actual. */
public final class DatosAplicacion {
    public List<Administrador> administradores = new ArrayList<>();
    public List<Empresa> empresas = new ArrayList<>();
    public List<Trabajador> trabajadores = new ArrayList<>();
    public List<OfertaLaboral> ofertas = new ArrayList<>();
    public List<Postulacion> postulaciones = new ArrayList<>();
    public List<Habilidad> habilidades = new ArrayList<>();
    public List<Capacitacion> capacitaciones = new ArrayList<>();
    public List<Documento> documentos = new ArrayList<>();

    private Path directorioBase;
    private Usuario usuarioActual;
    private boolean primeraVez;

    public DatosAplicacion() {
        this(Path.of("."));
    }

    public DatosAplicacion(Path directorioBase) {
        preparar(directorioBase, true);
    }

    public void preparar(Path directorio, boolean esPrimeraVez) {
        directorioBase = directorio.toAbsolutePath().normalize();
        primeraVez = esPrimeraVez;
    }

    public Path getDirectorioBase() {
        return directorioBase;
    }

    public Path getCarpetaDatos() {
        return directorioBase.resolve("datos");
    }

    public boolean esPrimeraVez() {
        return primeraVez;
    }

    public Usuario getUsuarioActual() {
        return usuarioActual;
    }

    public void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }

    public boolean esAdministrador() {
        return usuarioActual instanceof Administrador;
    }

    public boolean esEmpresa() {
        return usuarioActual instanceof Empresa;
    }

    public boolean esTrabajador() {
        return usuarioActual instanceof Trabajador;
    }

    public void guardar() {
        ArchivoUtil.guardar(this);
    }
}
