package modelo;

/** Estados posibles de una vacante. */
public enum EstadoOferta {
    ACTIVA,
    PAUSADA,
    CERRADA
}
