package modelo;


public abstract class Usuario {
    private final int id;
    private String nombre;
    private final String usuario;
    private String correo;
    private String telefono;
    private String passwordHash;

    protected Usuario(int id, String nombre, String usuario, String correo,
            String telefono, String passwordHash) {
        this.id = id;
        this.nombre = limpio(nombre);
        this.usuario = limpio(usuario);
        this.correo = limpio(correo);
        this.telefono = limpio(telefono);
        this.passwordHash = passwordHash;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = limpio(nombre);
    }

    public String getUsuario() {
        return usuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = limpio(correo);
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = limpio(telefono);
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public abstract Rol getRol();

    protected static String limpio(String value) {
        return value == null ? "" : value.trim();
    }
}
