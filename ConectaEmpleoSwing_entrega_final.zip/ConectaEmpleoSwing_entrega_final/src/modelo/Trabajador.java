package modelo;

import java.util.ArrayList;
import java.util.List;

public final class Trabajador extends Usuario {
    private String documento;
    private String ubicacion;
    private String nivelEducativo;
    private String disponibilidad;
    private String experiencia;
    private String rutaHojaVida = "";
    private List<String> habilidades = new ArrayList<>();

    public Trabajador(int id, String nombre, String usuario, String correo, String telefono, String passwordHash,
            String documento, String ubicacion, String nivelEducativo, String disponibilidad,
            String experiencia, List<String> habilidades) {
        super(id, nombre, usuario, correo, telefono, passwordHash);
        this.documento = limpio(documento);
        this.ubicacion = limpio(ubicacion);
        this.nivelEducativo = limpio(nivelEducativo);
        this.disponibilidad = limpio(disponibilidad);
        this.experiencia = limpio(experiencia);
        setHabilidades(habilidades);
    }

    public String getDocumento() { return documento; }
    public void setDocumento(String value) { documento = limpio(value); }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String value) { ubicacion = limpio(value); }
    public String getNivelEducativo() { return nivelEducativo; }
    public void setNivelEducativo(String value) { nivelEducativo = limpio(value); }
    public String getDisponibilidad() { return disponibilidad; }
    public void setDisponibilidad(String value) { disponibilidad = limpio(value); }
    public String getExperiencia() { return experiencia; }
    public void setExperiencia(String value) { experiencia = limpio(value); }
    public List<String> getHabilidades() { return List.copyOf(habilidades); }
    public void setHabilidades(List<String> values) {
        habilidades = values == null ? new ArrayList<>() : new ArrayList<>(values);
    }
    public String getRutaHojaVida() { return rutaHojaVida; }
    public void setRutaHojaVida(String value) { rutaHojaVida = limpio(value); }
    @Override
    public Rol getRol() {
        return Rol.TRABAJADOR;
    }
}
