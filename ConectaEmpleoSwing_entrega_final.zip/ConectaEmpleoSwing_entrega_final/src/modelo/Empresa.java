package modelo;

public final class Empresa extends Usuario {
    private String nit;
    private String sector;
    private String direccion;

    public Empresa(int id, String nombre, String usuario, String correo, String telefono, String passwordHash,
            String nit, String sector, String direccion) {
        super(id, nombre, usuario, correo, telefono, passwordHash);
        this.nit = limpio(nit);
        this.sector = limpio(sector);
        this.direccion = limpio(direccion);
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = limpio(nit);
    }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = limpio(sector);
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = limpio(direccion);
    }

    @Override
    public Rol getRol() {
        return Rol.EMPRESA;
    }
}
