package vista;
import controlador.CapacitacionesController;
import java.util.function.Consumer;
public final class CapacitacionesView extends ModuleTableView { public CapacitacionesView(CapacitacionesController c,Consumer<String> messages){super(c,"Oferta formativa local para cerrar brechas y fortalecer la empleabilidad.",messages);} }
