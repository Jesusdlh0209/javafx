package vista;
import controlador.HabilidadesController;
import java.util.function.Consumer;
public final class HabilidadesView extends ModuleTableView { public HabilidadesView(HabilidadesController c,Consumer<String> messages){super(c,"Catálogo de competencias y su asociación con perfiles de trabajadores.",messages);} }
