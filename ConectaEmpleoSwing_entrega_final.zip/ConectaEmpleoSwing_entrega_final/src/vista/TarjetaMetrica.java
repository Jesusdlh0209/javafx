package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.border.EmptyBorder;
import utilidades.Theme;

/** Indicador breve reutilizado por el panel y la pantalla de estadísticas. */
final class TarjetaMetrica extends JPanel {
    TarjetaMetrica(String titulo, int valor, String icono, Color acento) {
        setOpaque(true);
        setBackground(Theme.SURFACE);
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, acento),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Theme.BORDER),
                        new EmptyBorder(12, 14, 12, 14))));

        JLabel tituloLabel = Theme.label(titulo, 12, true, Theme.MUTED);
        add(tituloLabel, BorderLayout.NORTH);
        JPanel contenido = new JPanel(new BorderLayout(8, 0));
        contenido.setOpaque(false);
        contenido.add(Theme.label(String.format("%,d", valor), 27, true, Theme.TEXT), BorderLayout.WEST);
        JLabel iconoLabel = Theme.label(icono, 21, true, acento);
        iconoLabel.setOpaque(true);
        iconoLabel.setBackground(Theme.PALE_GREEN);
        iconoLabel.setHorizontalAlignment(JLabel.CENTER);
        iconoLabel.setPreferredSize(new Dimension(40, 40));
        contenido.add(iconoLabel, BorderLayout.EAST);
        add(contenido, BorderLayout.CENTER);
    }
}
