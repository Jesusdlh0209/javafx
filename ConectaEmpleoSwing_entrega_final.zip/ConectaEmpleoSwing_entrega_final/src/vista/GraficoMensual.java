package vista;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.Arrays;
import javax.swing.JPanel;
import utilidades.Theme;

/** Tendencia mensual de ofertas y postulaciones para la pantalla de estadísticas. */
final class GraficoMensual extends JPanel {
    private final int[] ofertas;
    private final int[] postulaciones;
    private final String[] meses;

    GraficoMensual(int[] ofertas, int[] postulaciones, String[] meses) {
        this.ofertas = Arrays.copyOf(ofertas, ofertas.length);
        this.postulaciones = Arrays.copyOf(postulaciones, postulaciones.length);
        this.meses = Arrays.copyOf(meses, meses.length);
        setOpaque(true);
        setBackground(Theme.SURFACE);
        setPreferredSize(new Dimension(760, 270));
        setMinimumSize(new Dimension(320, 210));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        int left = 38;
        int right = 16;
        int top = 16;
        int bottom = 34;
        int plotWidth = Math.max(1, getWidth() - left - right);
        int plotHeight = Math.max(1, getHeight() - top - bottom);
        int maximo = Math.max(1, Math.max(Arrays.stream(ofertas).max().orElse(0),
                Arrays.stream(postulaciones).max().orElse(0)));

        for (int linea = 0; linea <= 4; linea++) {
            int y = top + plotHeight * linea / 4;
            int valor = maximo - maximo * linea / 4;
            g.setColor(Theme.BORDER);
            g.drawLine(left, y, left + plotWidth, y);
            g.setColor(Theme.MUTED);
            g.drawString(Integer.toString(valor), 4, y + 4);
        }

        int grupo = plotWidth / Math.max(1, meses.length);
        int anchoBarra = Math.max(8, Math.min(28, grupo / 4));
        for (int i = 0; i < meses.length; i++) {
            int centro = left + grupo * i + grupo / 2;
            int altoOferta = plotHeight * ofertas[i] / maximo;
            int altoPostulaciones = plotHeight * postulaciones[i] / maximo;
            dibujarBarra(g, centro - anchoBarra - 2, top + plotHeight - altoOferta,
                    anchoBarra, altoOferta, Theme.GREEN);
            dibujarBarra(g, centro + 2, top + plotHeight - altoPostulaciones,
                    anchoBarra, altoPostulaciones, Theme.TEAL);
            g.setColor(Theme.MUTED);
            String mes = meses[i];
            int textX = centro - g.getFontMetrics().stringWidth(mes) / 2;
            g.drawString(mes, textX, getHeight() - 10);
        }
        g.dispose();
    }

    private static void dibujarBarra(Graphics2D g, int x, int y, int ancho, int alto, Color color) {
        if (alto <= 0) return;
        g.setColor(color);
        g.fillRoundRect(x, y, ancho, alto, 7, 7);
    }
}
