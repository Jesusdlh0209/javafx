package vista;

import controlador.FormField;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

/** Formulario común. Cada controlador entrega únicamente los campos de su módulo. */
final class FormDialog extends JDialog {
    private final Map<String, JComponent> entradas = new LinkedHashMap<>();
    private boolean aceptado;

    private FormDialog(Window propietario, String titulo, List<FormField> campos) {
        super(propietario, titulo, ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setOpaque(true);
        formulario.setBackground(Theme.SURFACE);
        formulario.setBorder(new EmptyBorder(16, 18, 12, 18));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(4, 0, 7, 0);

        for (FormField campo : campos) {
            formulario.add(Theme.label(campo.label(), 12, true, Theme.MUTED), c);
            c.gridy++;
            JComponent entrada = crearEntrada(campo);
            entrada.setFont(entrada.getFont().deriveFont(13f));
            entradas.put(campo.key(), entrada);
            formulario.add(entrada, c);
            c.gridy++;
        }

        JPanel pie = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 8, 10));
        pie.setOpaque(true);
        pie.setBackground(Theme.CANVAS);
        JButton cancelar = Theme.button("Cancelar", Theme.TipoBoton.CANCELAR);
        JButton guardar = Theme.button("Guardar", Theme.TipoBoton.PRINCIPAL);
        cancelar.addActionListener(event -> dispose());
        guardar.addActionListener(event -> {
            aceptado = true;
            dispose();
        });
        pie.add(cancelar);
        pie.add(guardar);

        JScrollPane contenidoFormulario = Theme.scrollPane(formulario, Theme.SURFACE);
        JPanel contenido = new JPanel(new BorderLayout());
        contenido.setOpaque(true);
        contenido.setBackground(Theme.SURFACE);
        contenido.add(contenidoFormulario, BorderLayout.CENTER);
        contenido.add(pie, BorderLayout.SOUTH);
        setContentPane(contenido);
        setSize(520, Math.min(780, Math.max(320, 230 + campos.size() * 70)));
        setLocationRelativeTo(propietario);
    }

    static Map<String, String> show(Window propietario, String titulo, List<FormField> campos) {
        FormDialog dialogo = new FormDialog(propietario, titulo, campos);
        dialogo.setVisible(true);
        if (!dialogo.aceptado) return null;

        Map<String, String> valores = new LinkedHashMap<>();
        for (Map.Entry<String, JComponent> entrada : dialogo.entradas.entrySet()) {
            valores.put(entrada.getKey(), leerValor(entrada.getValue()));
        }
        return valores;
    }

    private JComponent crearEntrada(FormField campo) {
        String valor = campo.value() == null ? "" : campo.value();
        if (!campo.options().isEmpty()) {
            JComboBox<String> combo = Theme.comboBox(campo.options().toArray(new String[0]));
            if (!valor.isBlank()) combo.setSelectedItem(valor);
            combo.setPreferredSize(new Dimension(370, 34));
            return combo;
        }
        if (campo.key().toLowerCase(Locale.ROOT).contains("password")) {
            JPasswordField clave = new JPasswordField(valor);
            clave.setOpaque(true);
            clave.setBackground(Theme.SURFACE);
            clave.setForeground(Theme.TEXT);
            clave.setCaretColor(Theme.GREEN);
            clave.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                    javax.swing.BorderFactory.createLineBorder(Theme.BORDER),
                    new EmptyBorder(6, 8, 6, 8)));
            clave.setPreferredSize(new Dimension(370, 34));
            return clave;
        }
        if (campo.multiline()) {
            JTextArea area = new JTextArea(valor, 3, 30);
            area.setOpaque(true);
            area.setBackground(Theme.SURFACE);
            area.setForeground(Theme.TEXT);
            area.setCaretColor(Theme.GREEN);
            area.setLineWrap(true);
            area.setWrapStyleWord(true);
            area.setBorder(new EmptyBorder(7, 8, 7, 8));
            JScrollPane desplazamiento = Theme.scrollPane(area, Theme.SURFACE);
            desplazamiento.setPreferredSize(new Dimension(370, 72));
            return desplazamiento;
        }
        JTextField texto = Theme.textField(valor, 20);
        texto.setPreferredSize(new Dimension(370, 34));
        return texto;
    }

    private static String leerValor(JComponent entrada) {
        if (entrada instanceof JPasswordField) {
            return new String(((JPasswordField) entrada).getPassword());
        }
        if (entrada instanceof JTextField) {
            return ((JTextField) entrada).getText();
        }
        if (entrada instanceof JComboBox<?>) {
            return String.valueOf(((JComboBox<?>) entrada).getSelectedItem());
        }
        if (entrada instanceof JScrollPane) {
            JScrollPane desplazamiento = (JScrollPane) entrada;
            if (desplazamiento.getViewport().getView() instanceof JTextArea) {
                return ((JTextArea) desplazamiento.getViewport().getView()).getText();
            }
        }
        return "";
    }
}
