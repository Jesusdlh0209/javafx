package vista;
import controlador.EmpresasController;
import java.util.function.Consumer;
public final class EmpresasView extends ModuleTableView { public EmpresasView(EmpresasController c,Consumer<String> messages){super(c,"Directorio de empresas y organizaciones con oportunidades laborales.",messages);} }
