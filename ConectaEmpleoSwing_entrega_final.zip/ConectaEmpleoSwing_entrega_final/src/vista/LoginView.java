package vista;

import controlador.LoginController;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.Arrays;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/** Formulario inicial; el controlador comprueba la cuenta y asigna el rol. */
public final class LoginView extends JPanel {
    private final JTextField usuario = Theme.textField("admin", 20);
    private final JPasswordField contrasena = new JPasswordField("admin123", 20);

    public LoginView(LoginController controlador, Runnable alIngresar) {
        setOpaque(true);
        setLayout(new GridBagLayout());
        setBackground(Theme.CANVAS);

        JPanel tarjeta = new JPanel(new GridLayout(1, 2));
        tarjeta.setOpaque(true);
        tarjeta.setBackground(Theme.SURFACE);
        tarjeta.setPreferredSize(new Dimension(980, 610));
        tarjeta.setBorder(javax.swing.BorderFactory.createLineBorder(Theme.BORDER));

        JPanel marca = new JPanel();
        marca.setOpaque(true);
        marca.setBackground(Theme.PETROL);
        marca.setLayout(new BoxLayout(marca, BoxLayout.Y_AXIS));
        marca.setBorder(new EmptyBorder(50, 42, 42, 42));
        marca.add(Theme.label("●  CONECTAEMPLEO", 18, true, Color.WHITE));
        marca.add(Box.createVerticalStrut(68));
        marca.add(Theme.label("Oportunidades que", 28, true, Color.WHITE));
        marca.add(Box.createVerticalStrut(4));
        marca.add(Theme.label("conectan talento y", 28, true, Color.WHITE));
        marca.add(Box.createVerticalStrut(4));
        marca.add(Theme.label("empleo formal.", 28, true, Theme.MINT));
        marca.add(Box.createVerticalStrut(20));
        JLabel texto = Theme.label("<html>Una plataforma para fortalecer habilidades<br>y acercar oportunidades de empleo formal<br>en Cartagena y Bolívar.</html>", 15, false, new Color(0xDBEAFE));
        texto.setAlignmentX(LEFT_ALIGNMENT);
        marca.add(texto);
        marca.add(Box.createVerticalGlue());
        marca.add(Theme.label("CAPACITACIÓN  ·  TALENTO  ·  EMPLEO", 11, true, Theme.MINT));

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setOpaque(true);
        formulario.setBackground(Theme.SURFACE);
        formulario.setBorder(new EmptyBorder(42, 48, 42, 48));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 0, 12, 0);
        formulario.add(Theme.label("Bienvenido de nuevo", 25, true, Theme.TEXT), c);
        c.gridy++;
        formulario.add(Theme.label("Ingresa a tu espacio de trabajo", 14, false, Theme.MUTED), c);
        c.gridy++;
        c.insets = new Insets(28, 0, 7, 0);
        formulario.add(Theme.label("Usuario", 12, true, Theme.TEXT), c);
        c.gridy++;
        c.insets = new Insets(0, 0, 16, 0);
        usuario.setPreferredSize(new Dimension(350, 38));
        formulario.add(usuario, c);
        c.gridy++;
        c.insets = new Insets(4, 0, 7, 0);
        formulario.add(Theme.label("Contraseña", 12, true, Theme.TEXT), c);
        c.gridy++;
        c.insets = new Insets(0, 0, 22, 0);
        contrasena.setOpaque(true);
        contrasena.setBackground(Theme.SURFACE);
        contrasena.setForeground(Theme.TEXT);
        contrasena.setCaretColor(Theme.GREEN);
        contrasena.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(Theme.BORDER),
                new EmptyBorder(6, 8, 6, 8)));
        contrasena.setPreferredSize(new Dimension(350, 38));
        formulario.add(contrasena, c);
        c.gridy++;
        c.insets = new Insets(0, 0, 14, 0);
        JCheckBox mostrarClave = new JCheckBox("Mostrar contraseña");
        mostrarClave.setOpaque(false);
        mostrarClave.setForeground(Theme.MUTED);
        mostrarClave.setFocusPainted(false);
        char caracterOculto = contrasena.getEchoChar();
        mostrarClave.addActionListener(event -> contrasena.setEchoChar(
                mostrarClave.isSelected() ? (char) 0 : caracterOculto));
        formulario.add(mostrarClave, c);
        c.gridy++;
        c.insets = new Insets(0, 0, 8, 0);
        JButton entrar = Theme.button("Iniciar sesión", Theme.TipoBoton.PRINCIPAL);
        formulario.add(entrar, c);
        c.gridy++;
        JLabel error = Theme.label("", 12, false, new Color(0xB91C1C));
        error.setHorizontalAlignment(SwingConstants.CENTER);
        formulario.add(error, c);
        c.gridy++;
        c.insets = new Insets(16, 0, 0, 0);
        JLabel demostracion = Theme.label("<html>Admin: admin / admin123<br>"
                + "Empresa: recicaribe / empresa123<br>"
                + "Trabajador: andrea / trabajador123</html>", 11, false, Theme.MUTED);
        formulario.add(demostracion, c);

        Runnable intentar = () -> {
            char[] clave = contrasena.getPassword();
            try {
                if (controlador.iniciar(usuario.getText(), clave)) {
                    error.setText("");
                    alIngresar.run();
                } else {
                    error.setText("Usuario o contraseña incorrectos.");
                }
            } finally {
                Arrays.fill(clave, '\0');
            }
        };
        entrar.addActionListener(event -> intentar.run());
        contrasena.addActionListener(event -> intentar.run());

        tarjeta.add(marca);
        tarjeta.add(formulario);
        add(tarjeta);
    }
}
