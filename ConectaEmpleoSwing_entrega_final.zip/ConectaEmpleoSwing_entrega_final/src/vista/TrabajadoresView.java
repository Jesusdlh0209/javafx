package vista;
import controlador.TrabajadoresController;
import java.util.function.Consumer;
public final class TrabajadoresView extends ModuleTableView { public TrabajadoresView(TrabajadoresController c,Consumer<String> messages){super(c,"Consulta perfiles, disponibilidad, habilidades y documentos de los trabajadores.",messages);} }
