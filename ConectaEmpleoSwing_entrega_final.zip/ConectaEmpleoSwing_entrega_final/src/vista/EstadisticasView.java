package vista;

import controlador.DashboardController;
import modelo.DatosAplicacion;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

/** Desglose de tendencias y distribución para el perfil administrador. */
public final class EstadisticasView extends JPanel {
    private final DashboardController controlador;

    public EstadisticasView(DatosAplicacion datos) {
        controlador = new DashboardController(datos);
        controlador.validarAccesoEstadisticas();
        setOpaque(true);
        setLayout(new BorderLayout());
        setBackground(Theme.CANVAS);
        setBorder(new EmptyBorder(20, 24, 22, 24));
        add(crearContenido(), BorderLayout.CENTER);
    }

    private JScrollPane crearContenido() {
        JPanel pagina = new PanelDesplazable();
        pagina.setLayout(new GridBagLayout());
        pagina.setOpaque(true);
        pagina.setBackground(Theme.CANVAS);
        int fila = 0;
        agregarFila(pagina, crearEncabezado(), fila++, 0, 14);
        agregarFila(pagina, crearIndicadores(), fila++, 0, 14);
        agregarFila(pagina, crearGraficosEstados(), fila++, 0, 14);
        agregarFila(pagina, crearTendencia(), fila++, 0, 14);
        agregarFila(pagina, crearSectores(), fila, 1, 0);

        JScrollPane scroll = Theme.scrollPane(pagina, Theme.CANVAS);
        scroll.setBorder(null);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return scroll;
    }

    private void agregarFila(JPanel pagina, java.awt.Component componente, int fila,
            double pesoVertical, int espacioInferior) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = fila;
        c.weightx = 1;
        c.weighty = pesoVertical;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new java.awt.Insets(0, 0, espacioInferior, 0);
        pagina.add(componente, c);
    }

    private JPanel crearEncabezado() {
        JPanel encabezado = new JPanel();
        encabezado.setOpaque(false);
        encabezado.setLayout(new javax.swing.BoxLayout(encabezado, javax.swing.BoxLayout.Y_AXIS));
        encabezado.add(Theme.label("ANÁLISIS DEL SISTEMA", 11, true, Theme.GREEN));
        encabezado.add(javax.swing.Box.createVerticalStrut(5));
        encabezado.add(Theme.label("Estadísticas", 26, true, Theme.TEXT));
        encabezado.add(javax.swing.Box.createVerticalStrut(3));
        encabezado.add(Theme.label("Distribución y tendencias calculadas desde los registros guardados.",
                13, false, Theme.MUTED));
        return encabezado;
    }

    private JPanel crearIndicadores() {
        Map<String, Integer> metricas = controlador.metricas();
        JPanel panel = new JPanel(new GridLayout(1, 4, 12, 0));
        panel.setOpaque(false);
        panel.add(new TarjetaMetrica("Total ofertas", metricas.get("Ofertas"), "▣", Theme.TEAL));
        panel.add(new TarjetaMetrica("Ofertas activas", metricas.get("Ofertas activas"), "↗", Theme.GREEN));
        panel.add(new TarjetaMetrica("Total postulaciones", metricas.get("Postulaciones"), "◇", Theme.PETROL));
        panel.add(new TarjetaMetrica("Postulaciones pendientes", metricas.get("Postulaciones pendientes"), "…", Theme.AMBER));
        return panel;
    }

    private JPanel crearGraficosEstados() {
        JPanel graficos = new JPanel(new GridLayout(1, 2, 14, 0));
        graficos.setOpaque(false);

        Map<String, Integer> ofertas = controlador.estadosOfertas();
        List<GraficoBarras.Dato> ofertaDatos = List.of(
                new GraficoBarras.Dato("Activas", ofertas.get("Activas"), Theme.GREEN),
                new GraficoBarras.Dato("En pausa", ofertas.get("En pausa"), Theme.AMBER),
                new GraficoBarras.Dato("Cerradas", ofertas.get("Cerradas"), Theme.PETROL));
        graficos.add(tarjetaGrafico("Ofertas por estado", ofertaDatos));

        Map<String, Integer> postulaciones = controlador.estadosPostulaciones();
        List<GraficoBarras.Dato> postulacionDatos = new ArrayList<>();
        postulacionDatos.add(new GraficoBarras.Dato("Pendientes", postulaciones.get("Pendientes"), Theme.AMBER));
        postulacionDatos.add(new GraficoBarras.Dato("En revisión", postulaciones.get("En revisión"), Theme.TEAL));
        postulacionDatos.add(new GraficoBarras.Dato("Entrevista", postulaciones.get("Entrevista"), Theme.PETROL));
        postulacionDatos.add(new GraficoBarras.Dato("Seleccionadas", postulaciones.get("Seleccionadas"), Theme.GREEN));
        postulacionDatos.add(new GraficoBarras.Dato("Rechazadas", postulaciones.get("Rechazadas"), Theme.RED));
        graficos.add(tarjetaGrafico("Postulaciones por estado", postulacionDatos));
        return graficos;
    }

    private JPanel tarjetaGrafico(String titulo, List<GraficoBarras.Dato> datos) {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 8));
        tarjeta.add(Theme.label(titulo, 15, true, Theme.TEXT), BorderLayout.NORTH);
        tarjeta.add(new GraficoBarras(datos), BorderLayout.CENTER);
        return tarjeta;
    }

    private JPanel crearTendencia() {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 8));
        tarjeta.add(Theme.label("Ofertas y postulaciones por mes · últimos seis meses",
                15, true, Theme.TEXT), BorderLayout.NORTH);
        tarjeta.add(new GraficoMensual(controlador.ofertasPorMes(),
                controlador.postulacionesPorMes(), controlador.meses()), BorderLayout.CENTER);
        JPanel leyenda = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 14, 0));
        leyenda.setOpaque(false);
        leyenda.add(Theme.label("● Ofertas publicadas", 11, true, Theme.GREEN));
        leyenda.add(Theme.label("● Postulaciones recibidas", 11, true, Theme.TEAL));
        tarjeta.add(leyenda, BorderLayout.SOUTH);
        return tarjeta;
    }

    private JPanel crearSectores() {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 8));
        tarjeta.add(Theme.label("Empresas por sector", 15, true, Theme.TEXT), BorderLayout.NORTH);
        List<Map.Entry<String, Integer>> sectores = controlador.sectores().entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey(String.CASE_INSENSITIVE_ORDER)))
                .limit(8).toList();
        Color[] colores = {Theme.GREEN, Theme.PETROL, Theme.TEAL, Theme.AMBER};
        List<GraficoBarras.Dato> datos = new ArrayList<>();
        for (int i = 0; i < sectores.size(); i++) {
            Map.Entry<String, Integer> sector = sectores.get(i);
            datos.add(new GraficoBarras.Dato(sector.getKey(), sector.getValue(), colores[i % colores.length]));
        }
        tarjeta.add(new GraficoBarras(datos), BorderLayout.CENTER);
        return tarjeta;
    }
}
