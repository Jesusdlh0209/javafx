package vista;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import utilidades.Theme;

/** Tabla con un estado vacío visible también cuando un filtro no encuentra filas. */
final class TablaConMensaje extends JTable {
    private String mensajeVacio = "No hay registros para mostrar.";

    TablaConMensaje(TableModel modelo) {
        super(modelo);
    }

    void setMensajeVacio(String mensaje) {
        mensajeVacio = mensaje;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        if (getRowCount() != 0) return;
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(Theme.MUTED);
        FontMetrics metrics = g.getFontMetrics();
        int x = Math.max(12, (getWidth() - metrics.stringWidth(mensajeVacio)) / 2);
        int y = Math.max(metrics.getAscent() + 12, getHeight() / 2);
        g.drawString(mensajeVacio, x, y);
        g.dispose();
    }
}
