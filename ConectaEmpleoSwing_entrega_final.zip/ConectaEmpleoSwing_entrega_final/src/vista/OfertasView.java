package vista;
import controlador.OfertasController;
import java.util.function.Consumer;
public final class OfertasView extends ModuleTableView { public OfertasView(OfertasController c,Consumer<String> messages){super(c,"Publica vacantes sostenibles, consulta requisitos y gestiona el proceso de selección.",messages);} }
