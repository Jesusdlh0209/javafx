package vista;

import controlador.DocumentosController;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.nio.file.Path;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/** Vista para asociar, buscar, abrir, reemplazar y quitar hojas de vida PDF. */
public final class DocumentosView extends JPanel {
    private final DocumentosController controlador;
    private final DefaultTableModel modelo;
    private final TablaConMensaje tabla;
    private final JComboBox<String> trabajador;
    private final JTextField buscar = Theme.textField("", 20);
    private final JButton abrir = Theme.button("Abrir", Theme.TipoBoton.CONSULTAR);
    private final JButton eliminar = Theme.button("Eliminar", Theme.TipoBoton.ELIMINAR);
    private final java.util.function.Consumer<String> mensajes;

    public DocumentosView(DocumentosController controlador,
            java.util.function.Consumer<String> mensajes) {
        this.controlador = controlador;
        this.mensajes = mensajes;
        setOpaque(true);
        setLayout(new BorderLayout(0, 16));
        setBackground(Theme.CANVAS);
        setBorder(new EmptyBorder(20, 24, 22, 24));

        JPanel encabezado = new JPanel();
        encabezado.setOpaque(false);
        encabezado.setLayout(new javax.swing.BoxLayout(encabezado, javax.swing.BoxLayout.Y_AXIS));
        encabezado.add(Theme.label(controlador.canModify()
                ? "Documentos y hojas de vida" : "Hojas de vida de candidatos", 25, true, Theme.TEXT));
        encabezado.add(javax.swing.Box.createVerticalStrut(5));
        encabezado.add(Theme.label(controlador.canModify()
                ? "Importa, revisa, reemplaza y abre hojas de vida PDF guardadas localmente."
                : "Consulta los PDF de las personas postuladas a tus ofertas.", 13, false, Theme.MUTED));
        add(encabezado, BorderLayout.NORTH);

        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 12));
        JPanel herramientas = new JPanel(new BorderLayout(8, 8));
        herramientas.setOpaque(false);
        JPanel filtros = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filtros.setOpaque(false);
        trabajador = controlador.isAdmin()
                ? Theme.comboBox(controlador.trabajadores().toArray(new String[0])) : null;
        if (trabajador != null) {
            filtros.add(Theme.label("Trabajador", 12, true, Theme.MUTED));
            trabajador.setPreferredSize(new Dimension(220, 34));
            filtros.add(trabajador);
        }
        buscar.putClientProperty("JTextField.placeholderText", "Buscar por trabajador o archivo…");
        buscar.setPreferredSize(new Dimension(250, 34));
        filtros.add(buscar);
        filtros.add(Theme.label("PDF verificado con Apache PDFBox 3.0.7", 11, false, Theme.MUTED));
        herramientas.add(filtros, BorderLayout.WEST);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setOpaque(false);
        JButton adjuntar = Theme.button("＋ Adjuntar / reemplazar PDF", Theme.TipoBoton.PRINCIPAL);
        adjuntar.setVisible(controlador.canModify());
        eliminar.setVisible(controlador.canModify());
        abrir.setEnabled(false);
        eliminar.setEnabled(false);
        botones.add(adjuntar);
        botones.add(abrir);
        botones.add(eliminar);
        herramientas.add(botones, BorderLayout.EAST);
        tarjeta.add(herramientas, BorderLayout.NORTH);

        modelo = new DefaultTableModel(new Object[]{"ID", "Trabajador", "Archivo PDF", "Tamaño", "Fecha de carga"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new TablaConMensaje(modelo);
        tabla.setMensajeVacio("No hay documentos PDF que mostrar.");
        Theme.styleTable(tabla);
        tabla.setRowHeight(38);
        tabla.setShowVerticalLines(false);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        TableRowSorter<DefaultTableModel> ordenar = new TableRowSorter<>(modelo);
        tabla.setRowSorter(ordenar);
        tarjeta.add(Theme.scrollPane(tabla, Theme.SURFACE), BorderLayout.CENTER);
        add(tarjeta, BorderLayout.CENTER);

        adjuntar.addActionListener(event -> adjuntar());
        abrir.addActionListener(event -> abrirSeleccionado());
        eliminar.addActionListener(event -> eliminarSeleccionado());
        tabla.getSelectionModel().addListSelectionListener(event -> actualizarBotones());
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2) abrirSeleccionado();
            }
        });
        buscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            private void filtrar() {
                String consulta = buscar.getText().trim().toLowerCase(java.util.Locale.ROOT);
                ordenar.setRowFilter(consulta.isEmpty() ? null : RowFilter.regexFilter("(?i)" +
                        java.util.regex.Pattern.quote(consulta), 1, 2));
            }
            @Override public void insertUpdate(javax.swing.event.DocumentEvent event) { filtrar(); }
            @Override public void removeUpdate(javax.swing.event.DocumentEvent event) { filtrar(); }
            @Override public void changedUpdate(javax.swing.event.DocumentEvent event) { filtrar(); }
        });
        actualizarTabla();
    }

    private void adjuntar() {
        int trabajadorId;
        if (controlador.isAdmin()) {
            if (trabajador == null || trabajador.getSelectedItem() == null) {
                mensajes.accept("No hay trabajadores para asociar el PDF.");
                return;
            }
            trabajadorId = Integer.parseInt(trabajador.getSelectedItem().toString().split(" - ")[0]);
        } else {
            trabajadorId = controlador.currentWorkerId();
        }

        JFileChooser selector = new JFileChooser();
        selector.setDialogTitle("Seleccionar hoja de vida PDF");
        selector.setFileFilter(new FileNameExtensionFilter("Documentos PDF (*.pdf)", "pdf"));
        if (selector.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        Path archivo = selector.getSelectedFile().toPath();
        try {
            String informacion = controlador.inspect(archivo);
            boolean reemplazar = controlador.hasCv(trabajadorId);
            String pregunta = reemplazar
                    ? "El PDF se puede leer (" + informacion + "). ¿Reemplazar la hoja de vida actual?"
                    : "El PDF se puede leer (" + informacion + "). ¿Guardar una copia local?";
            int confirmacion = JOptionPane.showConfirmDialog(this, pregunta,
                    "Confirmar documento", JOptionPane.YES_NO_OPTION);
            if (confirmacion != JOptionPane.YES_OPTION) return;
            controlador.importPdf(trabajadorId, archivo, reemplazar);
            actualizarTabla();
            mensajes.accept("PDF guardado en datos/documentos/hojas-vida.");
        } catch (Exception ex) {
            mensajes.accept(ex.getMessage());
        }
    }

    private void abrirSeleccionado() {
        Integer id = idSeleccionado();
        if (id == null) return;
        try {
            controlador.open(id);
        } catch (Exception ex) {
            mensajes.accept(ex.getMessage());
        }
    }

    private void eliminarSeleccionado() {
        Integer id = idSeleccionado();
        if (id == null) return;
        int respuesta = JOptionPane.showConfirmDialog(this,
                "¿Eliminar este documento de forma permanente?", "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) return;
        try {
            controlador.delete(id);
            actualizarTabla();
            mensajes.accept("Documento eliminado.");
        } catch (Exception ex) {
            mensajes.accept(ex.getMessage());
        }
    }

    private Integer idSeleccionado() {
        int filaVisible = tabla.getSelectedRow();
        if (filaVisible < 0) return null;
        int fila = tabla.convertRowIndexToModel(filaVisible);
        return ((Number) modelo.getValueAt(fila, 0)).intValue();
    }

    private void actualizarBotones() {
        boolean seleccionado = idSeleccionado() != null;
        abrir.setEnabled(seleccionado);
        eliminar.setEnabled(seleccionado && controlador.canModify());
    }

    private void actualizarTabla() {
        modelo.setRowCount(0);
        for (Object[] fila : controlador.rows()) modelo.addRow(fila);
        actualizarBotones();
    }
}
