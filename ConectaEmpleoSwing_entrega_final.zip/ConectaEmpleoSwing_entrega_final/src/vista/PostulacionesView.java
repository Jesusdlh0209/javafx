package vista;
import controlador.PostulacionesController;
import java.util.function.Consumer;
public final class PostulacionesView extends ModuleTableView { public PostulacionesView(PostulacionesController c,Consumer<String> messages){super(c,"Seguimiento de candidatos y estados de los procesos laborales.",messages);} }
