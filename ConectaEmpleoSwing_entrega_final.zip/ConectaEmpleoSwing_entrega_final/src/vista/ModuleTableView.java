package vista;

import controlador.TableController;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Locale;
import java.util.function.Consumer;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/** Tabla compartida; los controladores definen columnas, campos y reglas por módulo. */
abstract class ModuleTableView extends JPanel {
    protected final TableController controlador;
    private final DefaultTableModel modelo;
    private final TablaConMensaje tabla;
    private final javax.swing.JTextField buscar = Theme.textField("", 20);
    private final JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
    private final JButton nuevo = Theme.button("＋ Nuevo", Theme.TipoBoton.PRINCIPAL);
    private final JButton editar = Theme.button("Editar", Theme.TipoBoton.EDITAR);
    private final JButton eliminar = Theme.button("Eliminar", Theme.TipoBoton.ELIMINAR);
    private final JButton detalle = Theme.button("Ver detalle", Theme.TipoBoton.CONSULTAR);
    private final JButton accion;
    private final Consumer<String> mensajes;

    ModuleTableView(TableController controlador, String subtitulo, Consumer<String> mensajes) {
        this.controlador = controlador;
        this.mensajes = mensajes;
        setOpaque(true);
        setLayout(new BorderLayout(0, 16));
        setBackground(Theme.CANVAS);
        setBorder(new EmptyBorder(20, 24, 22, 24));

        JPanel encabezado = new JPanel(new BorderLayout(8, 8));
        encabezado.setOpaque(false);
        JPanel titulos = new JPanel();
        titulos.setOpaque(false);
        titulos.setLayout(new javax.swing.BoxLayout(titulos, javax.swing.BoxLayout.Y_AXIS));
        titulos.add(Theme.label(controlador.title(), 25, true, Theme.TEXT));
        titulos.add(javax.swing.Box.createVerticalStrut(5));
        titulos.add(Theme.label(subtitulo, 13, false, Theme.MUTED));
        encabezado.add(titulos, BorderLayout.WEST);
        add(encabezado, BorderLayout.NORTH);

        modelo = new DefaultTableModel(controlador.columns().toArray(), 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new TablaConMensaje(modelo);
        tabla.setMensajeVacio("No hay registros que coincidan con esta búsqueda.");
        Theme.styleTable(tabla);
        tabla.setRowHeight(38);
        tabla.setShowVerticalLines(false);
        tabla.getTableHeader().setFont(tabla.getTableHeader().getFont().deriveFont(Font.BOLD, 12f));
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        TableRowSorter<DefaultTableModel> ordenar = new TableRowSorter<>(modelo);
        tabla.setRowSorter(ordenar);

        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 12));
        JPanel barra = new JPanel(new BorderLayout(8, 8));
        barra.setOpaque(false);
        buscar.putClientProperty("JTextField.placeholderText", "Buscar en este módulo…");
        buscar.setPreferredSize(new Dimension(250, 36));
        barra.add(buscar, BorderLayout.WEST);
        acciones.setOpaque(false);
        String etiquetaAccion = controlador.actionLabel();
        accion = etiquetaAccion == null ? null
                : Theme.button(etiquetaAccion, Theme.TipoBoton.PRINCIPAL);
        if (accion != null) {
            accion.setVisible(controlador.canRunAction());
            acciones.add(accion);
        }
        detalle.setVisible(controlador.canShowDetails());
        nuevo.setVisible(controlador.canCreate());
        editar.setVisible(controlador.canEdit());
        eliminar.setVisible(controlador.canDelete());
        acciones.add(detalle);
        acciones.add(nuevo);
        acciones.add(editar);
        acciones.add(eliminar);
        barra.add(acciones, BorderLayout.EAST);
        tarjeta.add(barra, BorderLayout.NORTH);
        JScrollPane desplazamiento = Theme.scrollPane(tabla, Theme.SURFACE);
        tarjeta.add(desplazamiento, BorderLayout.CENTER);
        add(tarjeta, BorderLayout.CENTER);

        buscar.getDocument().addDocumentListener(new DocumentListenerSimple(() -> filtrar(ordenar)));
        nuevo.addActionListener(event -> editarRegistro(null));
        editar.addActionListener(event -> editarRegistro(idSeleccionado()));
        detalle.addActionListener(event -> mostrarDetalle());
        eliminar.addActionListener(event -> eliminarSeleccionado());
        if (accion != null) accion.addActionListener(event -> ejecutarAccion());
        tabla.getSelectionModel().addListSelectionListener(event -> actualizarBotones());
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2) {
                    if (controlador.canEdit()) editarRegistro(idSeleccionado());
                    else if (controlador.canShowDetails()) mostrarDetalle();
                }
            }
        });
        actualizarTabla();
    }

    private void filtrar(TableRowSorter<DefaultTableModel> ordenar) {
        String consulta = buscar.getText().trim().toLowerCase(Locale.ROOT);
        if (consulta.isBlank()) {
            ordenar.setRowFilter(null);
            return;
        }
        ordenar.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> fila) {
                try {
                    int id = ((Number) fila.getValue(0)).intValue();
                    return controlador.searchableText(id).toLowerCase(Locale.ROOT).contains(consulta);
                } catch (RuntimeException ex) {
                    return fila.toString().toLowerCase(Locale.ROOT).contains(consulta);
                }
            }
        });
    }

    private Integer idSeleccionado() {
        int filaVisible = tabla.getSelectedRow();
        if (filaVisible < 0) return null;
        int filaModelo = tabla.convertRowIndexToModel(filaVisible);
        Object valor = modelo.getValueAt(filaModelo, 0);
        return valor instanceof Number ? ((Number) valor).intValue() : Integer.parseInt(valor.toString());
    }

    private void actualizarBotones() {
        Integer id = idSeleccionado();
        editar.setEnabled(id != null && controlador.canEdit());
        eliminar.setEnabled(id != null && controlador.canDelete());
        detalle.setEnabled(id != null && controlador.canShowDetails());
        if (accion != null) accion.setEnabled(id != null && controlador.canRunAction());
    }

    private void editarRegistro(Integer id) {
        if (id == null && !controlador.canCreate()) {
            mensajes.accept("Selecciona un registro para editar.");
            return;
        }
        try {
            String titulo = id == null ? "Nuevo registro" : "Editar registro";
            java.util.Map<String, String> valores = FormDialog.show(
                    SwingUtilities.getWindowAncestor(this), titulo, controlador.fields(id));
            if (valores == null) return;
            controlador.save(id, valores);
            actualizarTabla();
            mensajes.accept("Los cambios se guardaron correctamente.");
        } catch (Exception ex) {
            mensajes.accept(ex.getMessage());
        }
    }

    private void eliminarSeleccionado() {
        Integer id = idSeleccionado();
        if (id == null) return;
        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el registro seleccionado?", "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);
        if (confirmacion != JOptionPane.YES_OPTION) return;
        try {
            controlador.delete(id);
            actualizarTabla();
            mensajes.accept("Registro eliminado.");
        } catch (Exception ex) {
            mensajes.accept(ex.getMessage());
        }
    }

    private void ejecutarAccion() {
        Integer id = idSeleccionado();
        if (id == null) return;
        try {
            controlador.runAction(id);
            actualizarTabla();
            mensajes.accept("Operación completada.");
        } catch (Exception ex) {
            mensajes.accept(ex.getMessage());
        }
    }

    private void mostrarDetalle() {
        Integer id = idSeleccionado();
        if (id == null) return;
        JTextArea texto = new JTextArea(controlador.details(id), 16, 46);
        texto.setOpaque(true);
        texto.setBackground(Theme.SURFACE);
        texto.setForeground(Theme.TEXT);
        texto.setEditable(false);
        texto.setLineWrap(true);
        texto.setWrapStyleWord(true);
        texto.setBorder(new EmptyBorder(8, 8, 8, 8));
        JOptionPane.showMessageDialog(this, Theme.scrollPane(texto, Theme.SURFACE),
                "Detalle del registro", JOptionPane.INFORMATION_MESSAGE);
    }

    protected final void actualizarTabla() {
        modelo.setRowCount(0);
        for (Object[] fila : controlador.rows()) modelo.addRow(fila);
        actualizarBotones();
    }

    private static final class DocumentListenerSimple implements javax.swing.event.DocumentListener {
        private final Runnable actualizar;

        DocumentListenerSimple(Runnable actualizar) {
            this.actualizar = actualizar;
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent event) {
            actualizar.run();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent event) {
            actualizar.run();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent event) {
            actualizar.run();
        }
    }
}
