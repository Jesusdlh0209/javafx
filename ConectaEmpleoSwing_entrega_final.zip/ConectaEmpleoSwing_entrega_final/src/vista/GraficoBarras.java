package vista;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.List;
import javax.swing.JPanel;
import utilidades.Theme;

/** Gráfico horizontal sencillo, con cantidades visibles y escala segura para cero. */
final class GraficoBarras extends JPanel {
    record Dato(String etiqueta, int cantidad, Color color) { }

    private final List<Dato> datos;

    GraficoBarras(List<Dato> datos) {
        this.datos = List.copyOf(datos);
        setOpaque(true);
        setBackground(Theme.SURFACE);
        setPreferredSize(new Dimension(420, Math.max(150, datos.size() * 34 + 24)));
        setMinimumSize(new Dimension(220, 120));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        if (datos.isEmpty()) {
            g.setColor(Theme.MUTED);
            g.drawString("Sin registros para mostrar.", 10, getHeight() / 2);
            g.dispose();
            return;
        }

        int maximo = Math.max(1, datos.stream().mapToInt(Dato::cantidad).max().orElse(0));
        FontMetrics metrics = g.getFontMetrics();
        int anchoEtiqueta = 0;
        for (Dato dato : datos) anchoEtiqueta = Math.max(anchoEtiqueta, metrics.stringWidth(dato.etiqueta()));
        anchoEtiqueta = Math.min(150, anchoEtiqueta + 8);
        int xBarra = anchoEtiqueta + 8;
        int anchoCantidad = 40;
        int anchoDisponible = Math.max(18, getWidth() - xBarra - anchoCantidad - 20);
        int alturaFila = Math.max(20, (getHeight() - 8) / datos.size());

        for (int i = 0; i < datos.size(); i++) {
            Dato dato = datos.get(i);
            int y = 8 + i * alturaFila;
            int altoBarra = Math.min(17, alturaFila - 6);
            int yBarra = y + (alturaFila - altoBarra) / 2;
            int lineaBase = y + (alturaFila - metrics.getHeight()) / 2 + metrics.getAscent();
            String etiqueta = ajustar(dato.etiqueta(), metrics, anchoEtiqueta - 6);
            g.setColor(Theme.TEXT);
            g.drawString(etiqueta, 2, lineaBase);
            int ancho = dato.cantidad() == 0 ? 0
                    : Math.max(5, anchoDisponible * dato.cantidad() / maximo);
            g.setColor(new Color(dato.color().getRed(), dato.color().getGreen(), dato.color().getBlue(), 32));
            g.fillRoundRect(xBarra, yBarra, anchoDisponible, altoBarra, 9, 9);
            if (ancho > 0) {
                g.setColor(dato.color());
                g.fillRoundRect(xBarra, yBarra, ancho, altoBarra, 9, 9);
            }
            g.setColor(Theme.TEXT);
            g.drawString(Integer.toString(dato.cantidad()), xBarra + anchoDisponible + 8, lineaBase);
        }
        g.dispose();
    }

    private static String ajustar(String texto, FontMetrics metrics, int ancho) {
        if (metrics.stringWidth(texto) <= ancho) return texto;
        String corto = texto;
        while (!corto.isEmpty() && metrics.stringWidth(corto + "…") > ancho) {
            corto = corto.substring(0, corto.length() - 1);
        }
        return corto.isEmpty() ? "…" : corto + "…";
    }
}
