package vista;

import controlador.*;
import modelo.DatosAplicacion;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

/** Ventana principal: muestra el menú del rol y cambia entre las vistas. */
public final class MainFrame extends JFrame {
    private final DatosAplicacion datos;
    private final LoginController loginController;
    private JPanel contenido;
    private JLabel etiquetaPagina;
    private JLabel etiquetaEstado;
    private final Map<String, String> etiquetasRutas = new LinkedHashMap<>();
    private final Map<String, JButton> botonesNavegacion = new LinkedHashMap<>();

    public MainFrame(DatosAplicacion datos) {
        super("ConectaEmpleo");
        this.datos = datos;
        this.loginController = new LoginController(datos);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        ajustarTamano(1440, 900);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent event) {
                cerrarAplicacion();
            }
        });
        mostrarLogin();
    }

    private void mostrarLogin() {
        setContentPane(new LoginView(loginController, this::mostrarAreaTrabajo));
        revalidate();
        repaint();
    }

    private void mostrarAreaTrabajo() {
        List<Nav> menu = elementosMenu();
        etiquetasRutas.clear();
        for (Nav elemento : menu) etiquetasRutas.put(elemento.ruta, elemento.etiqueta);

        JPanel marco = new JPanel(new BorderLayout());
        marco.setOpaque(true);
        marco.setBackground(Theme.CANVAS);
        marco.add(crearBarraLateral(menu), BorderLayout.WEST);

        JPanel principal = new JPanel(new BorderLayout());
        principal.setOpaque(true);
        principal.setBackground(Theme.CANVAS);
        principal.add(crearBarraSuperior(), BorderLayout.NORTH);
        contenido = new JPanel(new BorderLayout());
        contenido.setOpaque(true);
        contenido.setBackground(Theme.CANVAS);
        principal.add(contenido, BorderLayout.CENTER);
        principal.add(crearBarraEstado(), BorderLayout.SOUTH);
        marco.add(principal, BorderLayout.CENTER);

        setContentPane(marco);
        ajustarTamano(1500, 940);
        mostrarRuta("dashboard");
        revalidate();
        repaint();
    }

    private void ajustarTamano(int anchoDeseado, int altoDeseado) {
        Rectangle area = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        setMinimumSize(new Dimension(Math.min(1100, area.width), Math.min(720, area.height)));
        setSize(Math.min(anchoDeseado, area.width), Math.min(altoDeseado, area.height));
        setLocationRelativeTo(null);
    }

    private JPanel crearBarraLateral(List<Nav> elementos) {
        botonesNavegacion.clear();
        JPanel lateral = new JPanel(new BorderLayout());
        lateral.setOpaque(true);
        lateral.setPreferredSize(new Dimension(242, 760));
        lateral.setBackground(Theme.PETROL);
        lateral.setBorder(new EmptyBorder(18, 13, 14, 13));

        JPanel encabezado = new JPanel();
        encabezado.setOpaque(false);
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        JLabel logo = Theme.label("●  ConectaEmpleo", 18, true, Color.WHITE);
        logo.setBorder(new EmptyBorder(3, 8, 0, 0));
        encabezado.add(logo);
        JLabel lema = Theme.label("CAPACITACIÓN Y EMPLEO FORMAL", 10, true, Theme.MINT);
        lema.setBorder(new EmptyBorder(4, 33, 18, 0));
        encabezado.add(lema);
        encabezado.add(Theme.label("OPERACIÓN  ·  "
                + datos.getUsuarioActual().getRol().getEtiqueta().toUpperCase(Locale.ROOT),
                10, true, new Color(0xB6D3DD)));
        encabezado.add(Box.createVerticalStrut(3));
        encabezado.add(Theme.label(datos.getUsuarioActual().getNombre(), 12, true, Color.WHITE));
        encabezado.add(Box.createVerticalStrut(12));
        lateral.add(encabezado, BorderLayout.NORTH);

        JPanel listaMenu = new JPanel();
        listaMenu.setOpaque(false);
        listaMenu.setLayout(new BoxLayout(listaMenu, BoxLayout.Y_AXIS));
        for (Nav elemento : elementos) {
            JButton boton = Theme.button(elemento.icono + "   " + elemento.etiqueta,
                    Theme.TipoBoton.NAVEGACION);
            boton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            boton.setAlignmentX(Component.LEFT_ALIGNMENT);
            boton.addActionListener(event -> mostrarRuta(elemento.ruta));
            botonesNavegacion.put(elemento.ruta, boton);
            listaMenu.add(boton);
            listaMenu.add(Box.createVerticalStrut(3));
        }
        JScrollPane desplazamiento = Theme.scrollPane(listaMenu, Theme.PETROL);
        desplazamiento.setBorder(null);
        lateral.add(desplazamiento, BorderLayout.CENTER);

        JPanel pie = new JPanel();
        pie.setOpaque(false);
        pie.setLayout(new BoxLayout(pie, BoxLayout.Y_AXIS));
        JButton cambiarClave = botonLateral("⚙   Cambiar contraseña");
        cambiarClave.addActionListener(event -> cambiarContrasena());
        JButton cerrarSesion = Theme.button("↪   Cerrar sesión", Theme.TipoBoton.ELIMINAR);
        cerrarSesion.setHorizontalAlignment(SwingConstants.LEFT);
        cerrarSesion.setBorder(new EmptyBorder(9, 10, 9, 5));
        cerrarSesion.setAlignmentX(Component.LEFT_ALIGNMENT);
        cerrarSesion.addActionListener(event -> {
            datos.guardar();
            loginController.cerrar();
            mostrarLogin();
        });
        pie.add(cambiarClave);
        pie.add(Box.createVerticalStrut(7));
        pie.add(cerrarSesion);
        pie.add(Box.createVerticalStrut(10));
        pie.add(Theme.label("Guardado en este equipo", 10, false, new Color(0xB6D3DD)));
        lateral.add(pie, BorderLayout.SOUTH);
        return lateral;
    }

    private JButton botonLateral(String texto) {
        JButton boton = Theme.button(texto, Theme.TipoBoton.NAVEGACION);
        boton.setFont(boton.getFont().deriveFont(12f));
        boton.setBorder(new EmptyBorder(9, 10, 9, 5));
        boton.setAlignmentX(Component.LEFT_ALIGNMENT);
        return boton;
    }

    private JPanel crearBarraSuperior() {
        JPanel barra = new JPanel(new BorderLayout(12, 0));
        barra.setOpaque(true);
        barra.setBackground(Theme.SURFACE);
        barra.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER),
                new EmptyBorder(11, 20, 11, 20)));
        etiquetaPagina = Theme.label("Inicio", 17, true, Theme.TEXT);
        barra.add(etiquetaPagina, BorderLayout.WEST);

        JPanel centro = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        centro.setOpaque(false);
        JTextField buscar = Theme.textField("Buscar módulo…", 22);
        buscar.setForeground(Theme.MUTED);
        buscar.setToolTipText("Escribe el nombre de un módulo disponible y pulsa Enter.");
        buscar.setPreferredSize(new Dimension(270, 35));
        buscar.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent event) {
                if (buscar.getText().equals("Buscar módulo…")) {
                    buscar.setText("");
                    buscar.setForeground(Theme.TEXT);
                }
            }

            @Override
            public void focusLost(FocusEvent event) {
                if (buscar.getText().isBlank()) {
                    buscar.setText("Buscar módulo…");
                    buscar.setForeground(Theme.MUTED);
                }
            }
        });
        buscar.addActionListener(event -> {
            if (!buscar.getText().equals("Buscar módulo…")) buscarModulo(buscar.getText());
        });
        centro.add(buscar);
        barra.add(centro, BorderLayout.CENTER);

        JPanel usuario = new JPanel();
        usuario.setOpaque(false);
        usuario.setLayout(new BoxLayout(usuario, BoxLayout.Y_AXIS));
        JLabel nombre = Theme.label(datos.getUsuarioActual().getNombre(), 12, true, Theme.PETROL);
        nombre.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel rol = Theme.label(datos.getUsuarioActual().getRol().getEtiqueta(), 11, false, Theme.MUTED);
        rol.setHorizontalAlignment(SwingConstants.RIGHT);
        nombre.setAlignmentX(Component.RIGHT_ALIGNMENT);
        rol.setAlignmentX(Component.RIGHT_ALIGNMENT);
        usuario.add(nombre);
        usuario.add(rol);
        barra.add(usuario, BorderLayout.EAST);
        return barra;
    }

    private JPanel crearBarraEstado() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        panel.setBackground(Theme.CANVAS);
        panel.setBorder(new EmptyBorder(4, 18, 7, 18));
        etiquetaEstado = Theme.label("●  Sistema listo  ·  Datos guardados en datos/", 10, false, Theme.MUTED);
        panel.add(etiquetaEstado, BorderLayout.WEST);
        panel.add(Theme.label("ConectaEmpleo  ·  v1.0", 10, false, Theme.MUTED), BorderLayout.EAST);
        return panel;
    }

    private List<Nav> elementosMenu() {
        List<Nav> elementos = new ArrayList<>();
        elementos.add(new Nav("dashboard", "Inicio", "▦"));
        if (datos.esAdministrador()) {
            elementos.add(new Nav("trabajadores", "Trabajadores", "♙"));
            elementos.add(new Nav("empresas", "Empresas", "▥"));
            elementos.add(new Nav("ofertas", "Ofertas laborales", "▣"));
            elementos.add(new Nav("postulaciones", "Postulaciones", "◇"));
            elementos.add(new Nav("habilidades", "Habilidades", "✧"));
            elementos.add(new Nav("capacitaciones", "Capacitaciones", "⌂"));
            elementos.add(new Nav("documentos", "Documentos", "▤"));
            elementos.add(new Nav("estadisticas", "Estadísticas", "▤"));
        } else if (datos.esEmpresa()) {
            elementos.add(new Nav("empresas", "Mi empresa", "▥"));
            elementos.add(new Nav("ofertas", "Mis ofertas", "▣"));
            elementos.add(new Nav("postulaciones", "Postulaciones recibidas", "◇"));
            elementos.add(new Nav("trabajadores", "Candidatos", "♙"));
            elementos.add(new Nav("documentos", "Hojas de vida", "▤"));
        } else {
            elementos.add(new Nav("trabajadores", "Mi perfil", "♙"));
            elementos.add(new Nav("ofertas", "Ofertas disponibles", "▣"));
            elementos.add(new Nav("postulaciones", "Mis postulaciones", "◇"));
            elementos.add(new Nav("habilidades", "Mis habilidades", "✧"));
            elementos.add(new Nav("capacitaciones", "Capacitaciones", "⌂"));
            elementos.add(new Nav("documentos", "Mi hoja de vida", "▤"));
        }
        return elementos;
    }

    private void mostrarRuta(String ruta) {
        if (!etiquetasRutas.containsKey(ruta)) {
            mostrarEstado("Ese módulo no está disponible para tu perfil.");
            return;
        }
        if (etiquetaPagina != null) etiquetaPagina.setText(etiquetasRutas.getOrDefault(ruta, "Inicio"));
        botonesNavegacion.forEach((clave, boton) -> Theme.aplicarTipoBoton(boton,
                clave.equals(ruta) ? Theme.TipoBoton.NAVEGACION_SELECCIONADA : Theme.TipoBoton.NAVEGACION));
        JComponent pagina;
        if (ruta.equals("trabajadores")) {
            pagina = new TrabajadoresView(new TrabajadoresController(datos), this::mostrarEstado);
        } else if (ruta.equals("empresas")) {
            pagina = new EmpresasView(new EmpresasController(datos), this::mostrarEstado);
        } else if (ruta.equals("ofertas")) {
            pagina = new OfertasView(new OfertasController(datos), this::mostrarEstado);
        } else if (ruta.equals("postulaciones")) {
            pagina = new PostulacionesView(new PostulacionesController(datos), this::mostrarEstado);
        } else if (ruta.equals("habilidades")) {
            pagina = new HabilidadesView(new HabilidadesController(datos), this::mostrarEstado);
        } else if (ruta.equals("capacitaciones")) {
            pagina = new CapacitacionesView(new CapacitacionesController(datos), this::mostrarEstado);
        } else if (ruta.equals("documentos")) {
            pagina = new DocumentosView(new DocumentosController(datos), this::mostrarEstado);
        } else if (ruta.equals("estadisticas")) {
            pagina = new EstadisticasView(datos);
        } else {
            pagina = new DashboardView(datos, this::mostrarRuta, this::mostrarEstado);
        }
        contenido.removeAll();
        contenido.add(pagina, BorderLayout.CENTER);
        contenido.revalidate();
        contenido.repaint();
    }

    private void buscarModulo(String texto) {
        String consulta = texto.toLowerCase(Locale.ROOT);
        if (consulta.isBlank()) return;
        for (Map.Entry<String, String> ruta : etiquetasRutas.entrySet()) {
            if (ruta.getValue().toLowerCase(Locale.ROOT).contains(consulta)) {
                mostrarRuta(ruta.getKey());
                return;
            }
        }
        mostrarEstado("No encontré un módulo con ese nombre.");
    }

    private void cambiarContrasena() {
        JPasswordField actual = new JPasswordField(18);
        JPasswordField nueva = new JPasswordField(18);
        JPasswordField confirmacion = new JPasswordField(18);
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 9));
        formulario.setOpaque(true);
        formulario.setBackground(Theme.SURFACE);
        formulario.add(new JLabel("Contraseña actual"));
        formulario.add(actual);
        formulario.add(new JLabel("Nueva contraseña (mínimo 8 caracteres)"));
        formulario.add(nueva);
        formulario.add(new JLabel("Confirmar nueva contraseña"));
        formulario.add(confirmacion);
        javax.swing.JCheckBox mostrar = new javax.swing.JCheckBox("Mostrar contraseñas");
        mostrar.setOpaque(false);
        mostrar.setForeground(Theme.MUTED);
        mostrar.setFocusPainted(false);
        char ecoActual = actual.getEchoChar();
        char ecoNuevo = nueva.getEchoChar();
        char ecoConfirmacion = confirmacion.getEchoChar();
        mostrar.addActionListener(event -> {
            boolean visible = mostrar.isSelected();
            actual.setEchoChar(visible ? (char) 0 : ecoActual);
            nueva.setEchoChar(visible ? (char) 0 : ecoNuevo);
            confirmacion.setEchoChar(visible ? (char) 0 : ecoConfirmacion);
        });
        formulario.add(mostrar);
        try {
            while (true) {
                int resultado = JOptionPane.showConfirmDialog(this, formulario, "Cambiar contraseña",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (resultado != JOptionPane.OK_OPTION) return;

                char[] actualClave = actual.getPassword();
                char[] nuevaClave = nueva.getPassword();
                char[] confirmarClave = confirmacion.getPassword();
                try {
                    if (!Arrays.equals(nuevaClave, confirmarClave)) {
                        throw new IllegalArgumentException("Las contraseñas nuevas no coinciden.");
                    }
                    loginController.cambiarContrasena(actualClave, nuevaClave);
                    String mensaje = "Contraseña actualizada. Usa la nueva al volver a iniciar sesión.";
                    mostrarEstado(mensaje);
                    JOptionPane.showMessageDialog(this, mensaje, "Contraseña actualizada",
                            JOptionPane.INFORMATION_MESSAGE);
                    return;
                } catch (Exception ex) {
                    String mensaje = ex.getMessage() == null || ex.getMessage().isBlank()
                            ? "No se pudo cambiar la contraseña." : ex.getMessage();
                    mostrarEstado(mensaje);
                    JOptionPane.showMessageDialog(this, mensaje, "No se pudo cambiar la contraseña",
                            JOptionPane.ERROR_MESSAGE);
                } finally {
                    Arrays.fill(actualClave, '\0');
                    Arrays.fill(nuevaClave, '\0');
                    Arrays.fill(confirmarClave, '\0');
                }
            }
        } finally {
            actual.setText("");
            nueva.setText("");
            confirmacion.setText("");
        }
    }

    private void mostrarEstado(String mensaje) {
        if (etiquetaEstado == null) return;
        etiquetaEstado.setText("●  " + mensaje);
        String texto = mensaje.toLowerCase(Locale.ROOT);
        boolean error = texto.contains("no ") || texto.contains("debe")
                || texto.contains("error") || texto.contains("permiso");
        etiquetaEstado.setForeground(error ? new Color(0xB91C1C) : Theme.MUTED);
    }

    private void cerrarAplicacion() {
        try {
            datos.guardar();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al guardar", JOptionPane.ERROR_MESSAGE);
        }
        dispose();
        System.exit(0);
    }

    private static final class Nav {
        private final String ruta;
        private final String etiqueta;
        private final String icono;

        private Nav(String ruta, String etiqueta, String icono) {
            this.ruta = ruta;
            this.etiqueta = etiqueta;
            this.icono = icono;
        }
    }
}
