package vista;

import controlador.DashboardController;
import controlador.OfertasController;
import controlador.PostulacionesController;
import controlador.TrabajadoresController;
import modelo.Capacitacion;
import modelo.DatosAplicacion;
import modelo.Empresa;
import modelo.EstadoOferta;
import modelo.EstadoPostulacion;
import modelo.OfertaLaboral;
import modelo.Postulacion;
import modelo.Trabajador;
import utilidades.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;

/** Resumen inicial: los cálculos se comparten con la pantalla detallada de estadísticas. */
public final class DashboardView extends JPanel {
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd MMM yyyy");

    private final DatosAplicacion datos;
    private final DashboardController controlador;
    private final Consumer<String> navegar;

    public DashboardView(DatosAplicacion datos, Consumer<String> navegar, Consumer<String> mensajes) {
        this.datos = datos;
        this.controlador = new DashboardController(datos);
        this.navegar = navegar;
        setOpaque(true);
        setLayout(new BorderLayout());
        setBackground(Theme.CANVAS);
        setBorder(new EmptyBorder(20, 24, 22, 24));
        add(crearContenido(), BorderLayout.CENTER);
    }

    private JScrollPane crearContenido() {
        JPanel pagina = new PanelDesplazable();
        pagina.setLayout(new GridBagLayout());
        pagina.setOpaque(true);
        pagina.setBackground(Theme.CANVAS);
        pagina.setBorder(new EmptyBorder(0, 0, 12, 0));
        int fila = 0;
        agregarFila(pagina, crearEncabezado(), fila++, 0, 10);
        agregarFila(pagina, crearMetricas(), fila++, 0, 14);
        if (datos.esAdministrador()) {
            agregarFila(pagina, crearGraficosDeEstado(), fila++, 0, 14);
            agregarFila(pagina, crearActividadReciente(), fila, 1, 0);
        } else {
            agregarFila(pagina, crearTendencia(), fila++, 0, 14);
            agregarFila(pagina, crearOfertasDestacadas(), fila++, 0, 14);
            agregarFila(pagina, crearPostulacionesRecientes(), fila, 1, 0);
        }

        JScrollPane desplazamiento = Theme.scrollPane(pagina, Theme.CANVAS);
        desplazamiento.setBorder(null);
        desplazamiento.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return desplazamiento;
    }

    private void agregarFila(JPanel pagina, java.awt.Component componente, int fila,
            double pesoVertical, int espacioInferior) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = fila;
        c.weightx = 1;
        c.weighty = pesoVertical;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new java.awt.Insets(0, 0, espacioInferior, 0);
        pagina.add(componente, c);
    }

    private JPanel crearEncabezado() {
        JPanel encabezado = new JPanel(new BorderLayout(12, 8));
        encabezado.setOpaque(false);
        JPanel saludo = new JPanel();
        saludo.setOpaque(false);
        saludo.setLayout(new javax.swing.BoxLayout(saludo, javax.swing.BoxLayout.Y_AXIS));
        saludo.add(Theme.label(datos.esAdministrador() ? "PANEL DE CONTROL" : "CONECTAEMPLEO",
                11, true, Theme.GREEN));
        saludo.add(javax.swing.Box.createVerticalStrut(5));
        saludo.add(Theme.label("Hola, " + datos.getUsuarioActual().getNombre(), 26, true, Theme.TEXT));
        saludo.add(javax.swing.Box.createVerticalStrut(3));
        saludo.add(Theme.label("Bienvenido al panel de control de ConectaEmpleo.",
                13, false, Theme.MUTED));
        encabezado.add(saludo, BorderLayout.WEST);

        JPanel accesos = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 8, 3));
        accesos.setOpaque(false);
        JButton ofertas = Theme.button("Explorar ofertas", Theme.TipoBoton.CONSULTAR);
        ofertas.addActionListener(event -> navegar.accept("ofertas"));
        accesos.add(ofertas);
        if (datos.esAdministrador()) {
            JButton estadisticas = Theme.button("Estadísticas", Theme.TipoBoton.EDITAR);
            estadisticas.addActionListener(event -> navegar.accept("estadisticas"));
            accesos.add(estadisticas);
        }
        encabezado.add(accesos, BorderLayout.EAST);
        return encabezado;
    }

    private JPanel crearMetricas() {
        Map<String, Integer> totales = controlador.metricas();
        List<TarjetaMetrica> tarjetas = new ArrayList<>();
        if (datos.esAdministrador()) {
            tarjetas.add(new TarjetaMetrica("Total trabajadores", totales.get("Trabajadores"), "♙", Theme.GREEN));
            tarjetas.add(new TarjetaMetrica("Total empresas", totales.get("Empresas"), "▦", Theme.PETROL));
            tarjetas.add(new TarjetaMetrica("Total ofertas", totales.get("Ofertas"), "▣", Theme.TEAL));
            tarjetas.add(new TarjetaMetrica("Ofertas activas", totales.get("Ofertas activas"), "↗", Theme.GREEN_DARK));
            tarjetas.add(new TarjetaMetrica("Total postulaciones", totales.get("Postulaciones"), "◇", Theme.PETROL));
            tarjetas.add(new TarjetaMetrica("Postulaciones pendientes", totales.get("Postulaciones pendientes"), "…", Theme.AMBER));
        } else if (datos.getUsuarioActual() instanceof Empresa) {
            tarjetas.add(new TarjetaMetrica("Mis ofertas", controlador.ofertasDeEmpresa(), "▣", Theme.GREEN));
            tarjetas.add(new TarjetaMetrica("Postulaciones recibidas", controlador.postulacionesVisibles(), "◇", Theme.PETROL));
            tarjetas.add(new TarjetaMetrica("Candidatos", new TrabajadoresController(datos).rows().size(), "♙", Theme.TEAL));
        } else {
            int propias = new PostulacionesController(datos).rows().size();
            tarjetas.add(new TarjetaMetrica("Ofertas disponibles", totales.get("Ofertas activas"), "▣", Theme.GREEN));
            tarjetas.add(new TarjetaMetrica("Mis postulaciones", propias, "◇", Theme.PETROL));
            tarjetas.add(new TarjetaMetrica("Capacitaciones", totales.get("Capacitaciones"), "⌂", Theme.TEAL));
        }
        int columnas = datos.esAdministrador() ? 3 : tarjetas.size();
        JPanel panel = new JPanel(new GridLayout(datos.esAdministrador() ? 2 : 1, columnas, 12, 12));
        panel.setOpaque(false);
        for (TarjetaMetrica tarjeta : tarjetas) panel.add(tarjeta);
        return panel;
    }

    private JPanel crearGraficosDeEstado() {
        JPanel graficos = new JPanel(new GridLayout(1, 2, 14, 0));
        graficos.setOpaque(false);
        graficos.add(tarjetaGrafico("Estado de las ofertas laborales", datosOfertas()));
        graficos.add(tarjetaGrafico("Estado de las postulaciones", datosPostulaciones()));
        return graficos;
    }

    private List<GraficoBarras.Dato> datosOfertas() {
        Map<String, Integer> estados = controlador.estadosOfertas();
        List<GraficoBarras.Dato> datosGrafico = new ArrayList<>();
        datosGrafico.add(new GraficoBarras.Dato("Activas", estados.get("Activas"), Theme.GREEN));
        datosGrafico.add(new GraficoBarras.Dato("En pausa", estados.get("En pausa"), Theme.AMBER));
        datosGrafico.add(new GraficoBarras.Dato("Cerradas", estados.get("Cerradas"), Theme.PETROL));
        datosGrafico.add(new GraficoBarras.Dato("Total ofertas", datos.ofertas.size(), Theme.TEAL));
        return datosGrafico;
    }

    private List<GraficoBarras.Dato> datosPostulaciones() {
        Map<String, Integer> estados = controlador.estadosPostulaciones();
        List<GraficoBarras.Dato> datosGrafico = new ArrayList<>();
        datosGrafico.add(new GraficoBarras.Dato("Pendientes", estados.get("Pendientes"), Theme.AMBER));
        datosGrafico.add(new GraficoBarras.Dato("En revisión", estados.get("En revisión"), Theme.TEAL));
        datosGrafico.add(new GraficoBarras.Dato("Entrevista", estados.get("Entrevista"), Theme.PETROL));
        datosGrafico.add(new GraficoBarras.Dato("Seleccionadas", estados.get("Seleccionadas"), Theme.GREEN));
        datosGrafico.add(new GraficoBarras.Dato("Rechazadas", estados.get("Rechazadas"), Theme.RED));
        return datosGrafico;
    }

    private JPanel tarjetaGrafico(String titulo, List<GraficoBarras.Dato> datosGrafico) {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 8));
        tarjeta.add(Theme.label(titulo, 15, true, Theme.TEXT), BorderLayout.NORTH);
        tarjeta.add(new GraficoBarras(datosGrafico), BorderLayout.CENTER);
        return tarjeta;
    }

    private JPanel crearActividadReciente() {
        JPanel actividad = new JPanel(new GridLayout(1, 3, 12, 0));
        actividad.setOpaque(false);
        actividad.add(tarjetaTrabajadoresRecientes());
        actividad.add(tarjetaOfertasRecientes());
        actividad.add(tarjetaPostulacionesRecientes());
        return actividad;
    }

    private JPanel tarjetaTrabajadoresRecientes() {
        JPanel tarjeta = tarjetaActividad("Últimos trabajadores", "trabajadores");
        List<Trabajador> recientes = controlador.trabajadoresRecientes(4);
        if (recientes.isEmpty()) {
            agregarSinActividad(tarjeta, "Todavía no hay trabajadores registrados.");
        } else {
            for (Trabajador trabajador : recientes) {
                agregarActividad(tarjeta, trabajador.getNombre(),
                        "Registro #" + trabajador.getId() + " · " + trabajador.getUbicacion());
            }
        }
        return tarjeta;
    }

    private JPanel tarjetaOfertasRecientes() {
        JPanel tarjeta = tarjetaActividad("Últimas ofertas publicadas", "ofertas");
        List<OfertaLaboral> recientes = controlador.ofertasRecientes(4);
        if (recientes.isEmpty()) {
            agregarSinActividad(tarjeta, "Todavía no hay ofertas publicadas.");
        } else {
            for (OfertaLaboral oferta : recientes) {
                Empresa empresa = datos.empresas.stream()
                        .filter(item -> item.getId() == oferta.getEmpresaId()).findFirst().orElse(null);
                String fecha = oferta.getFechaPublicacion() == null
                        ? "Fecha no registrada" : oferta.getFechaPublicacion().format(FECHA);
                agregarActividad(tarjeta, oferta.getCargo(),
                        (empresa == null ? "Empresa no disponible" : empresa.getNombre()) + " · " + fecha);
            }
        }
        return tarjeta;
    }

    private JPanel tarjetaPostulacionesRecientes() {
        JPanel tarjeta = tarjetaActividad("Últimas postulaciones", "postulaciones");
        List<Postulacion> recientes = controlador.postulacionesRecientes(4);
        if (recientes.isEmpty()) {
            agregarSinActividad(tarjeta, "Todavía no hay postulaciones registradas.");
        } else {
            for (Postulacion postulacion : recientes) {
                Trabajador trabajador = datos.trabajadores.stream()
                        .filter(item -> item.getId() == postulacion.getTrabajadorId()).findFirst().orElse(null);
                OfertaLaboral oferta = datos.ofertas.stream()
                        .filter(item -> item.getId() == postulacion.getOfertaId()).findFirst().orElse(null);
                String nombre = trabajador == null ? "Perfil no disponible" : trabajador.getNombre();
                String cargo = oferta == null ? "Oferta no disponible" : oferta.getCargo();
                String fecha = postulacion.getFecha() == null
                        ? "Fecha no registrada" : postulacion.getFecha().format(FECHA);
                agregarActividad(tarjeta, nombre + " · " + cargo,
                        fecha + " · " + etiqueta(postulacion.getEstado()));
            }
        }
        return tarjeta;
    }

    private JPanel tarjetaActividad(String titulo, String ruta) {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new javax.swing.BoxLayout(tarjeta, javax.swing.BoxLayout.Y_AXIS));
        JPanel encabezado = new JPanel(new BorderLayout(6, 0));
        encabezado.setOpaque(false);
        encabezado.add(Theme.label(titulo, 14, true, Theme.TEXT), BorderLayout.WEST);
        JButton ver = Theme.button("Ver", Theme.TipoBoton.CONSULTAR);
        ver.addActionListener(event -> navegar.accept(ruta));
        encabezado.add(ver, BorderLayout.EAST);
        tarjeta.add(encabezado);
        tarjeta.add(javax.swing.Box.createVerticalStrut(8));
        return tarjeta;
    }

    private void agregarActividad(JPanel panel, String titulo, String detalle) {
        JPanel fila = new JPanel();
        fila.setOpaque(false);
        fila.setLayout(new javax.swing.BoxLayout(fila, javax.swing.BoxLayout.Y_AXIS));
        fila.add(Theme.label(titulo, 12, true, Theme.TEXT));
        fila.add(javax.swing.Box.createVerticalStrut(2));
        fila.add(Theme.label(detalle, 11, false, Theme.MUTED));
        fila.setBorder(new EmptyBorder(6, 0, 7, 0));
        panel.add(fila);
        panel.add(javax.swing.Box.createVerticalStrut(2));
    }

    private void agregarSinActividad(JPanel panel, String texto) {
        panel.add(Theme.label(texto, 12, false, Theme.MUTED));
        panel.add(javax.swing.Box.createVerticalGlue());
    }

    private JPanel crearTendencia() {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 8));
        tarjeta.add(Theme.label("Actividad de los últimos seis meses", 15, true, Theme.TEXT), BorderLayout.NORTH);
        tarjeta.add(new GraficoMensual(controlador.ofertasPorMes(), controlador.postulacionesPorMes(),
                controlador.meses()), BorderLayout.CENTER);
        JPanel leyenda = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 12, 0));
        leyenda.setOpaque(false);
        leyenda.add(Theme.label("● Ofertas", 11, true, Theme.GREEN));
        leyenda.add(Theme.label("● Postulaciones", 11, true, Theme.TEAL));
        tarjeta.add(leyenda, BorderLayout.SOUTH);
        return tarjeta;
    }

    private JPanel crearOfertasDestacadas() {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 10));
        tarjeta.add(tituloConAccion("Ofertas laborales", "Explorar", "ofertas"), BorderLayout.NORTH);
        DefaultTableModel modelo = modeloNoEditable(
                new String[]{"Cargo", "Empresa", "Ubicación", "Vacantes", "Fecha límite"});
        List<Object[]> ofertas = new OfertasController(datos).rows();
        int mostradas = 0;
        for (Object[] oferta : ofertas) {
            if (!EstadoOferta.ACTIVA.name().equals(String.valueOf(oferta[8]))) continue;
            if (oferta[7] instanceof LocalDate limite && limite.isBefore(LocalDate.now())) continue;
            modelo.addRow(new Object[]{oferta[1], oferta[2], oferta[4], oferta[3], oferta[7]});
            if (++mostradas == 5) break;
        }
        tarjeta.add(crearTabla(modelo, "No hay ofertas disponibles en este momento."), BorderLayout.CENTER);
        return tarjeta;
    }

    private JPanel crearPostulacionesRecientes() {
        JPanel tarjeta = Theme.card();
        tarjeta.setLayout(new BorderLayout(0, 10));
        tarjeta.add(tituloConAccion("Mis postulaciones", "Ver todas", "postulaciones"), BorderLayout.NORTH);
        DefaultTableModel modelo = modeloNoEditable(new String[]{"Fecha", "Trabajador", "Oferta", "Estado"});
        List<Object[]> postulaciones = new PostulacionesController(datos).rows();
        postulaciones.sort(Comparator.comparing(fila -> (LocalDate) fila[1],
                Comparator.nullsLast(Comparator.reverseOrder())));
        for (int i = 0; i < Math.min(5, postulaciones.size()); i++) {
            Object[] p = postulaciones.get(i);
            modelo.addRow(new Object[]{p[1] == null ? "—" : ((LocalDate) p[1]).format(FECHA),
                    p[2], p[3], p[5]});
        }
        tarjeta.add(crearTabla(modelo, "Todavía no hay postulaciones registradas."), BorderLayout.CENTER);
        return tarjeta;
    }

    private JPanel tituloConAccion(String titulo, String accion, String ruta) {
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setOpaque(false);
        encabezado.add(Theme.label(titulo, 15, true, Theme.TEXT), BorderLayout.WEST);
        JButton boton = Theme.button(accion + "  ›", Theme.TipoBoton.CONSULTAR);
        boton.addActionListener(event -> navegar.accept(ruta));
        encabezado.add(boton, BorderLayout.EAST);
        return encabezado;
    }

    private DefaultTableModel modeloNoEditable(String[] columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
    }

    private JScrollPane crearTabla(DefaultTableModel modelo, String mensajeVacio) {
        TablaConMensaje tabla = new TablaConMensaje(modelo);
        tabla.setMensajeVacio(mensajeVacio);
        Theme.styleTable(tabla);
        tabla.setRowHeight(36);
        return Theme.scrollPane(tabla, Theme.SURFACE);
    }

    private static String etiqueta(EstadoPostulacion estado) {
        return switch (estado) {
            case PENDIENTE -> "Pendiente";
            case EN_REVISION -> "En revisión";
            case ENTREVISTA -> "Entrevista";
            case SELECCIONADA -> "Seleccionada";
            case RECHAZADA -> "Rechazada";
        };
    }
}
