package utilidades;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordUtil {
    private static final int ITERATIONS=120_000;
    private static final int KEY_BITS=256;
    private static final SecureRandom RANDOM=new SecureRandom();
    private PasswordUtil() {}
    public static String hash(char[] password) {
        byte[] salt=new byte[16]; RANDOM.nextBytes(salt);
        byte[] derived=derive(password,salt,ITERATIONS);
        return "pbkdf2$"+ITERATIONS+"$"+Base64.getEncoder().encodeToString(salt)+"$"+Base64.getEncoder().encodeToString(derived);
    }
    public static boolean verify(char[] password,String encoded) {
        try {
            String[] parts=encoded.split("\\$",-1);
            if(parts.length!=4 || !parts[0].equals("pbkdf2")) return false;
            byte[] actual=derive(password,Base64.getDecoder().decode(parts[2]),Integer.parseInt(parts[1]));
            return java.security.MessageDigest.isEqual(actual,Base64.getDecoder().decode(parts[3]));
        } catch (RuntimeException ex) { return false; }
    }
    private static byte[] derive(char[] password,byte[] salt,int iterations) {
        PBEKeySpec spec=new PBEKeySpec(password,salt,iterations,KEY_BITS);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        catch (Exception ex) { throw new IllegalStateException("No está disponible PBKDF2-HMAC-SHA256.",ex); }
        finally { spec.clearPassword(); }
    }
}
