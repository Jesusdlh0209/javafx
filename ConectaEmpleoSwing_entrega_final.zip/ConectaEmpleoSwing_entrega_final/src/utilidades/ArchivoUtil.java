package utilidades;

import modelo.Administrador;
import modelo.Capacitacion;
import modelo.DatosAplicacion;
import modelo.Documento;
import modelo.Empresa;
import modelo.EstadoOferta;
import modelo.EstadoPostulacion;
import modelo.Habilidad;
import modelo.OfertaLaboral;
import modelo.Postulacion;
import modelo.Trabajador;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Guarda y recupera las listas en archivos de texto dentro de datos/. */
public final class ArchivoUtil {
    private ArchivoUtil() {
    }

    public static DatosAplicacion cargar(Path directorioBase) throws IOException {
        Path base = directorioBase.toAbsolutePath().normalize();
        File carpeta = base.resolve("datos").toFile();
        if (!carpeta.exists() && !carpeta.mkdirs()) {
            throw new IOException("No se pudo crear la carpeta datos.");
        }

        File[] archivosTexto = carpeta.listFiles((directorio, nombre) -> nombre.endsWith(".txt"));
        boolean primeraVez = archivosTexto == null || archivosTexto.length == 0;
        DatosAplicacion datos = new DatosAplicacion(base);
        datos.preparar(base, primeraVez);

        leerRegistros(new File(carpeta, "administradores.txt"), campos -> {
            exigirCampos(campos, 6);
            datos.administradores.add(new Administrador(entero(campos[0]), campos[1], campos[2],
                    campos[3], campos[4], campos[5]));
        });
        leerRegistros(new File(carpeta, "empresas.txt"), campos -> {
            exigirCampos(campos, 9);
            datos.empresas.add(new Empresa(entero(campos[0]), campos[1], campos[2], campos[3],
                    campos[4], campos[5], campos[6], campos[7], campos[8]));
        });
        leerRegistros(new File(carpeta, "trabajadores.txt"), campos -> {
            exigirCampos(campos, 13);
            Trabajador trabajador = new Trabajador(entero(campos[0]), campos[1], campos[2],
                    campos[3], campos[4], campos[5], campos[6], campos[7], campos[8],
                    campos[9], campos[10], leerLista(campos[11]));
            trabajador.setRutaHojaVida(campos[12]);
            datos.trabajadores.add(trabajador);
        });
        leerRegistros(new File(carpeta, "ofertas.txt"), campos -> {
            exigirCampos(campos, 13);
            datos.ofertas.add(new OfertaLaboral(entero(campos[0]), entero(campos[1]),
                    campos[2], campos[3], campos[4], leerLista(campos[5]), entero(campos[6]),
                    campos[7], campos[8], decimal(campos[9]), fecha(campos[10]), fecha(campos[11]),
                    EstadoOferta.valueOf(campos[12])));
        });
        leerRegistros(new File(carpeta, "postulaciones.txt"), campos -> {
            exigirCampos(campos, 5);
            datos.postulaciones.add(new Postulacion(entero(campos[0]), entero(campos[1]),
                    entero(campos[2]), fecha(campos[3]), EstadoPostulacion.valueOf(campos[4])));
        });
        leerRegistros(new File(carpeta, "habilidades.txt"), campos -> {
            exigirCampos(campos, 4);
            Habilidad habilidad = new Habilidad(entero(campos[0]), campos[1], campos[2]);
            habilidad.setTrabajadorIds(leerIds(campos[3]));
            datos.habilidades.add(habilidad);
        });
        leerRegistros(new File(carpeta, "capacitaciones.txt"), campos -> {
            exigirCampos(campos, 8);
            Capacitacion capacitacion = new Capacitacion(entero(campos[0]), campos[1], campos[2],
                    campos[3], fecha(campos[4]), fecha(campos[5]), entero(campos[6]));
            capacitacion.setParticipanteIds(leerIds(campos[7]));
            datos.capacitaciones.add(capacitacion);
        });
        leerRegistros(new File(carpeta, "documentos.txt"), campos -> {
            exigirCampos(campos, 6);
            datos.documentos.add(new Documento(entero(campos[0]), entero(campos[1]),
                    campos[2], campos[3], Long.parseLong(campos[4]), fechaHora(campos[5])));
        });
        return datos;
    }

    public static void guardar(DatosAplicacion datos) {
        File carpeta = datos.getCarpetaDatos().toFile();
        if (!carpeta.exists() && !carpeta.mkdirs()) {
            throw new IllegalStateException("No se pudo crear la carpeta datos.");
        }
        try {
            escribir(new File(carpeta, "administradores.txt"), lineasAdministradores(datos));
            escribir(new File(carpeta, "empresas.txt"), lineasEmpresas(datos));
            escribir(new File(carpeta, "trabajadores.txt"), lineasTrabajadores(datos));
            escribir(new File(carpeta, "ofertas.txt"), lineasOfertas(datos));
            escribir(new File(carpeta, "postulaciones.txt"), lineasPostulaciones(datos));
            escribir(new File(carpeta, "habilidades.txt"), lineasHabilidades(datos));
            escribir(new File(carpeta, "capacitaciones.txt"), lineasCapacitaciones(datos));
            escribir(new File(carpeta, "documentos.txt"), lineasDocumentos(datos));
        } catch (IOException ex) {
            throw new IllegalStateException("No se pudieron guardar los datos: " + ex.getMessage(), ex);
        }
    }

    private static List<String> lineasAdministradores(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Administrador usuario : datos.administradores) {
            lineas.add(fila(usuario.getId(), usuario.getNombre(), usuario.getUsuario(),
                    usuario.getCorreo(), usuario.getTelefono(), usuario.getPasswordHash()));
        }
        return lineas;
    }

    private static List<String> lineasEmpresas(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Empresa empresa : datos.empresas) {
            lineas.add(fila(empresa.getId(), empresa.getNombre(), empresa.getUsuario(),
                    empresa.getCorreo(), empresa.getTelefono(), empresa.getPasswordHash(),
                    empresa.getNit(), empresa.getSector(), empresa.getDireccion()));
        }
        return lineas;
    }

    private static List<String> lineasTrabajadores(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Trabajador trabajador : datos.trabajadores) {
            lineas.add(fila(trabajador.getId(), trabajador.getNombre(), trabajador.getUsuario(),
                    trabajador.getCorreo(), trabajador.getTelefono(), trabajador.getPasswordHash(),
                    trabajador.getDocumento(), trabajador.getUbicacion(), trabajador.getNivelEducativo(),
                    trabajador.getDisponibilidad(), trabajador.getExperiencia(),
                    String.join(",", trabajador.getHabilidades()), trabajador.getRutaHojaVida()));
        }
        return lineas;
    }

    private static List<String> lineasOfertas(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (OfertaLaboral oferta : datos.ofertas) {
            lineas.add(fila(oferta.getId(), oferta.getEmpresaId(), oferta.getCargo(),
                    oferta.getDescripcion(), oferta.getRequisitos(),
                    String.join(",", oferta.getHabilidades()), oferta.getVacantes(),
                    oferta.getUbicacion(), oferta.getTipoContrato(), oferta.getSalario(),
                    texto(oferta.getFechaPublicacion()), texto(oferta.getFechaLimite()), oferta.getEstado()));
        }
        return lineas;
    }

    private static List<String> lineasPostulaciones(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Postulacion postulacion : datos.postulaciones) {
            lineas.add(fila(postulacion.getId(), postulacion.getTrabajadorId(),
                    postulacion.getOfertaId(), texto(postulacion.getFecha()), postulacion.getEstado()));
        }
        return lineas;
    }

    private static List<String> lineasHabilidades(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Habilidad habilidad : datos.habilidades) {
            lineas.add(fila(habilidad.getId(), habilidad.getNombre(), habilidad.getCategoria(),
                    juntarIds(habilidad.getTrabajadorIds())));
        }
        return lineas;
    }

    private static List<String> lineasCapacitaciones(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Capacitacion capacitacion : datos.capacitaciones) {
            lineas.add(fila(capacitacion.getId(), capacitacion.getNombre(), capacitacion.getEntidad(),
                    capacitacion.getDescripcion(), texto(capacitacion.getFechaInicio()),
                    texto(capacitacion.getFechaFin()), capacitacion.getCupos(),
                    juntarIds(capacitacion.getParticipanteIds())));
        }
        return lineas;
    }

    private static List<String> lineasDocumentos(DatosAplicacion datos) {
        List<String> lineas = new ArrayList<>();
        for (Documento documento : datos.documentos) {
            lineas.add(fila(documento.getId(), documento.getTrabajadorId(), documento.getNombre(),
                    documento.getRutaRelativa(), documento.getBytes(), documento.getAgregado()));
        }
        return lineas;
    }

    private static String fila(Object... valores) {
        StringBuilder linea = new StringBuilder();
        for (int i = 0; i < valores.length; i++) {
            if (i > 0) linea.append('\t');
            linea.append(escapar(String.valueOf(valores[i])));
        }
        return linea.toString();
    }

    private static String escapar(String valor) {
        return valor.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private static String[] separar(String linea) {
        List<String> campos = new ArrayList<>();
        StringBuilder campo = new StringBuilder();
        boolean secuencia = false;
        for (int i = 0; i < linea.length(); i++) {
            char caracter = linea.charAt(i);
            if (secuencia) {
                switch (caracter) {
                    case 't' -> campo.append('\t');
                    case 'r' -> campo.append('\r');
                    case 'n' -> campo.append('\n');
                    default -> campo.append(caracter);
                }
                secuencia = false;
            } else if (caracter == '\\') {
                secuencia = true;
            } else if (caracter == '\t') {
                campos.add(campo.toString());
                campo.setLength(0);
            } else {
                campo.append(caracter);
            }
        }
        if (secuencia) campo.append('\\');
        campos.add(campo.toString());
        return campos.toArray(String[]::new);
    }

    private static void leerRegistros(File archivo, Consumer<String[]> procesar) throws IOException {
        if (!archivo.isFile()) return;
        try (BufferedReader lector = new BufferedReader(
                new FileReader(archivo, StandardCharsets.UTF_8))) {
            String linea;
            int numeroLinea = 0;
            while ((linea = lector.readLine()) != null) {
                numeroLinea++;
                if (linea.isBlank() || linea.startsWith("#")) continue;
                try {
                    procesar.accept(separar(linea));
                } catch (RuntimeException ex) {
                    throw new IOException("Error en " + archivo.getName() + ", línea "
                            + numeroLinea + ".", ex);
                }
            }
        }
    }

    private static void escribir(File archivo, List<String> lineas) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(
                new FileWriter(archivo, StandardCharsets.UTF_8))) {
            escritor.write("# ConectaEmpleo - formato de texto v1");
            escritor.newLine();
            for (String linea : lineas) {
                escritor.write(linea);
                escritor.newLine();
            }
        }
    }

    private static void exigirCampos(String[] campos, int cantidad) {
        if (campos.length != cantidad) {
            throw new IllegalArgumentException("La fila tiene " + campos.length
                    + " campos; se esperaban " + cantidad + ".");
        }
    }

    private static int entero(String valor) {
        return Integer.parseInt(valor);
    }

    private static double decimal(String valor) {
        return Double.parseDouble(valor);
    }

    private static String texto(Object valor) {
        return valor == null ? "" : valor.toString();
    }

    private static LocalDate fecha(String valor) {
        return valor.isBlank() ? null : LocalDate.parse(valor);
    }

    private static LocalDateTime fechaHora(String valor) {
        return valor.isBlank() ? null : LocalDateTime.parse(valor);
    }

    private static List<String> leerLista(String valor) {
        if (valor.isBlank()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(valor.split(",", -1)));
    }

    private static String juntarIds(Set<Integer> ids) {
        return ids.stream().map(String::valueOf).reduce((a, b) -> a + "," + b).orElse("");
    }

    private static Set<Integer> leerIds(String valor) {
        Set<Integer> ids = new LinkedHashSet<>();
        if (valor.isBlank()) return ids;
        for (String id : valor.split(",")) ids.add(entero(id));
        return ids;
    }
}
