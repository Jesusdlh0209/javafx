package utilidades;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** Convierte los valores de los formularios a tipos de Java y muestra errores claros. */
public final class FormularioUtil {
    private FormularioUtil() {
    }

    public static String valor(Map<String, String> valores, String clave) {
        return valores.getOrDefault(clave, "").trim();
    }

    public static List<String> separarLista(String texto) {
        if (texto == null || texto.isBlank()) {
            return new ArrayList<>();
        }
        return Arrays.stream(texto.split(","))
                .map(String::trim)
                .filter(valor -> !valor.isBlank())
                .distinct()
                .collect(Collectors.toCollection(ArrayList::new));
    }

    public static String unirLista(Collection<String> valores) {
        return String.join(", ", valores);
    }

    public static int entero(Map<String, String> valores, String clave, String etiqueta) {
        try {
            return Integer.parseInt(valor(valores, clave));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("«" + etiqueta + "» debe ser un número entero.");
        }
    }

    public static double decimal(Map<String, String> valores, String clave, String etiqueta) {
        String texto = valor(valores, clave);
        if (texto.isBlank()) {
            return 0;
        }
        try {
            return Double.parseDouble(texto.replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("«" + etiqueta + "» debe ser numérico.");
        }
    }

    public static LocalDate fecha(Map<String, String> valores, String clave, String etiqueta) {
        try {
            return LocalDate.parse(valor(valores, clave));
        } catch (RuntimeException ex) {
            throw new IllegalArgumentException("«" + etiqueta + "» debe tener formato AAAA-MM-DD.");
        }
    }
}
