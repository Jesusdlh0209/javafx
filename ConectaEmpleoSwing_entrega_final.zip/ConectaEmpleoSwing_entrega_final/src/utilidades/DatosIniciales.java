package utilidades;

import modelo.*;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Crea los registros iniciales una sola vez, cuando aún no hay datos guardados. */
public final class DatosIniciales {
    private DatosIniciales() {
    }

    public static void inicializar(DatosAplicacion datos) {
        if (datos.esPrimeraVez()) {
            cargarDemostracion(datos);
            datos.guardar();
            datos.preparar(datos.getDirectorioBase(), false);
            return;
        }

        // Compatibilidad con la primera compilación Swing, que usaba admin/admin.
        datos.administradores.stream()
                .filter(admin -> admin.getId() == 1 && admin.getUsuario().equalsIgnoreCase("admin"))
                .filter(admin -> PasswordUtil.verify("admin".toCharArray(), admin.getPasswordHash()))
                .findFirst()
                .ifPresent(admin -> {
                    admin.setPasswordHash(PasswordUtil.hash("admin123".toCharArray()));
                    datos.guardar();
                });
    }

    private static void cargarDemostracion(DatosAplicacion datos) {
        datos.administradores.add(new Administrador(1, "Administración ConectaEmpleo", "admin",
                "admin@conectaempleo.local", "+57 605 0000000",
                PasswordUtil.hash("admin123".toCharArray())));

        String[][] empresas = {
            {"Recicla Caribe SAS", "recicaribe", "900123456-1", "Gestión de residuos",
                "Cartagena - Mamonal", "recicla@demo.co"},
            {"EcoEmpaques del Norte", "ecoempaques", "900234567-2", "Manufactura verde",
                "Cartagena - Zona Franca", "contacto@ecoempaques.co"},
            {"Logística Circular", "logisticac", "900345678-3", "Logística inversa",
                "Cartagena - El Bosque", "talento@logisticac.co"},
            {"BioConstrucciones Bolívar", "bioconstruye", "900456789-4", "Bio-construcción",
                "Turbaco, Bolívar", "empleo@bioconstruye.co"},
            {"Fundación Renacer Verde", "renacer", "900567890-5", "Economía circular",
                "Cartagena - Centro", "equipo@renacer.co"}
        };
        for (int i = 0; i < empresas.length; i++) {
            String[] e = empresas[i];
            datos.empresas.add(new Empresa(i + 1, e[0], e[1], e[5], "+57 300 555 0101",
                    PasswordUtil.hash("empresa123".toCharArray()), e[2], e[3], e[4]));
        }

        String[][] trabajadores = {
            {"Andrea Mercado", "andrea", "CC 1045123401", "Cartagena", "Tecnólogo", "Disponible", "Atención al cliente, Excel"},
            {"Jhonatan Morales", "trabajador2", "CC 1045123402", "Mamonal", "Bachiller", "Disponible", "Logística, Inventarios"},
            {"Yenifer Polo", "trabajador3", "CC 1045123403", "Bocagrande", "Técnico", "Disponible", "Gestión ambiental, Reciclaje"},
            {"Carlos Torres", "trabajador4", "CC 1045123404", "El Bosque", "Tecnólogo", "En búsqueda", "Soldadura, Mantenimiento"},
            {"María Pérez", "trabajador5", "CC 1045123405", "Turbaco", "Profesional", "Disponible", "Administración, Excel"},
            {"Luis Herrera", "trabajador6", "CC 1045123406", "Olaya Herrera", "Bachiller", "Disponible", "Conducción, Bodega"},
            {"Paola Benítez", "trabajador7", "CC 1045123407", "Cartagena Centro", "Técnico", "No disponible", "Cocina, Manipulación de alimentos"},
            {"Miguel Arroyo", "trabajador8", "CC 1045123408", "Pasacaballos", "Tecnólogo", "Disponible", "Electricidad, Mantenimiento"},
            {"Lina Contreras", "trabajador9", "CC 1045123409", "La Boquilla", "Profesional", "Disponible", "Marketing digital, Comunicación"},
            {"Óscar Díaz", "trabajador10", "CC 1045123410", "Cartagena", "Bachiller", "En búsqueda", "Reciclaje, Trabajo en equipo"}
        };
        for (int i = 0; i < trabajadores.length; i++) {
            String[] t = trabajadores[i];
            datos.trabajadores.add(new Trabajador(i + 1, t[0], t[1], t[1] + "@demo.co",
                    "+57 300 555 02" + String.format("%02d", i),
                    PasswordUtil.hash("trabajador123".toCharArray()), t[2], t[3], t[4], t[5],
                    "Experiencia en iniciativas locales y trabajo colaborativo.",
                    List.of(t[6].split(", "))));
        }

        String[] cargos = {"Operario de clasificación de materiales", "Auxiliar de logística inversa",
            "Técnico de mantenimiento industrial", "Coordinador de aprovechamiento",
            "Auxiliar administrativo", "Promotor de cultura ambiental",
            "Conductor de recolección", "Operario de bio-construcción"};
        String[] habilidadesOferta = {"Reciclaje, Trabajo en equipo", "Logística, Inventarios",
            "Mantenimiento, Electricidad", "Gestión ambiental, Reciclaje", "Administración, Excel",
            "Comunicación, Gestión ambiental", "Conducción, Bodega", "Soldadura, Mantenimiento"};
        String[] ciudades = {"Mamonal", "El Bosque", "Cartagena", "Cartagena", "Zona Franca",
            "La Boquilla", "Cartagena", "Turbaco"};
        LocalDate hoy = LocalDate.now();
        for (int i = 0; i < cargos.length; i++) {
            datos.ofertas.add(new OfertaLaboral(i + 1, i % empresas.length + 1, cargos[i],
                    "Aporta a operaciones sostenibles y al crecimiento de la economía circular en Cartagena.",
                    "Experiencia relacionada y disponibilidad para trabajo en equipo.",
                    List.of(habilidadesOferta[i].split(", ")), i % 3 + 1, ciudades[i],
                    i % 2 == 0 ? "Término fijo" : "Indefinido", 1800000 + i * 100000,
                    hoy.minusDays(i), hoy.plusDays(25 + i), EstadoOferta.ACTIVA));
        }
        for (int i = 0; i < 12; i++) {
            datos.postulaciones.add(new Postulacion(i + 1, i % 10 + 1, i % 8 + 1,
                    hoy.minusDays(i % 9), i % 5 == 0
                    ? EstadoPostulacion.ENTREVISTA : EstadoPostulacion.PENDIENTE));
        }

        String[][] habilidades = {
            {"Reciclaje", "Economía circular"}, {"Gestión ambiental", "Sostenibilidad"},
            {"Logística", "Operaciones"}, {"Inventarios", "Operaciones"},
            {"Excel", "Administración"}, {"Atención al cliente", "Servicio"},
            {"Mantenimiento", "Técnica"}, {"Electricidad", "Técnica"}, {"Soldadura", "Técnica"},
            {"Comunicación", "Habilidades blandas"}, {"Marketing digital", "Comercial"},
            {"Trabajo en equipo", "Habilidades blandas"}, {"Administración", "Administración"},
            {"Cocina", "Servicio"}, {"Manipulación de alimentos", "Servicio"},
            {"Conducción", "Logística"}, {"Bodega", "Logística"}
        };
        for (int i = 0; i < habilidades.length; i++) {
            Habilidad habilidad = new Habilidad(i + 1, habilidades[i][0], habilidades[i][1]);
            Set<Integer> ids = new LinkedHashSet<>();
            for (Trabajador trabajador : datos.trabajadores) {
                if (trabajador.getHabilidades().contains(habilidad.getNombre())) {
                    ids.add(trabajador.getId());
                }
            }
            habilidad.setTrabajadorIds(ids);
            datos.habilidades.add(habilidad);
        }

        agregarCapacitacion(datos, 1, "Excel para la empleabilidad", "SENA",
                "Herramientas ofimáticas y análisis de datos básicos.", 7, 21, 25);
        agregarCapacitacion(datos, 2, "Gestión integral de residuos", "SENA",
                "Separación en la fuente y aprovechamiento de materiales.", 10, 24, 30);
        agregarCapacitacion(datos, 3, "Logística inversa", "Tecnológico Comfenalco",
                "Trazabilidad y retorno de materiales en cadenas productivas.", 14, 28, 20);
        agregarCapacitacion(datos, 4, "Mantenimiento electromecánico", "SENA",
                "Buenas prácticas de mantenimiento en entornos industriales.", 18, 42, 18);
        agregarCapacitacion(datos, 5, "Emprendimiento circular", "Fundación Renacer Verde",
                "Diseño de iniciativas productivas sostenibles.", 25, 39, 22);
        datos.capacitaciones.get(0).setParticipanteIds(java.util.Set.of(1, 5));
        datos.capacitaciones.get(1).setParticipanteIds(java.util.Set.of(3, 10));

    }

    private static void agregarCapacitacion(DatosAplicacion datos, int id, String nombre,
            String entidad, String descripcion, int diasInicio, int diasFin, int cupos) {
        LocalDate hoy = LocalDate.now();
        datos.capacitaciones.add(new Capacitacion(id, nombre, entidad, descripcion,
                hoy.plusDays(diasInicio), hoy.plusDays(diasFin), cupos));
    }
}
