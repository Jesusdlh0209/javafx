package utilidades;

import java.util.regex.Pattern;

/** Validaciones simples reutilizadas por los controladores. */
public final class Validaciones {
    private static final Pattern CORREO = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    private Validaciones() {
    }

    public static void requerido(String valor, String etiqueta) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("El campo «" + etiqueta + "» es obligatorio.");
        }
    }

    public static void correo(String valor) {
        requerido(valor, "correo");
        if (!CORREO.matcher(valor.trim()).matches()) {
            throw new IllegalArgumentException("Escribe un correo válido.");
        }
    }

    public static void telefono(String valor) {
        if (valor != null && !valor.isBlank() && !valor.matches("[+0-9() .-]{7,20}")) {
            throw new IllegalArgumentException("El teléfono contiene caracteres inválidos.");
        }
    }

    public static void documento(String valor) {
        requerido(valor, "documento");
        if (!valor.trim().matches("[\\p{L}\\p{N} .#-]{5,30}")) {
            throw new IllegalArgumentException("El documento debe tener entre 5 y 30 caracteres válidos.");
        }
    }

    public static void nit(String valor) {
        requerido(valor, "NIT");
        if (!valor.trim().matches("\\d{6,15}(-\\d)?")) {
            throw new IllegalArgumentException("Escribe un NIT válido, con dígito de verificación opcional.");
        }
    }
}
