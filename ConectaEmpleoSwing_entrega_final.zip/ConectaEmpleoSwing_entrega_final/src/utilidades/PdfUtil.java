package utilidades;

import modelo.DatosAplicacion;
import java.awt.Desktop;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;

/** Operaciones locales para validar, copiar y abrir hojas de vida PDF. */
public final class PdfUtil {
    private PdfUtil() {
    }

    public static String inspeccionar(Path archivo) throws IOException {
        if (archivo == null || !Files.isRegularFile(archivo)
                || !archivo.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            throw new IOException("Selecciona un archivo PDF existente.");
        }
        if (Files.size(archivo) < 8) {
            throw new IOException("El archivo PDF está vacío o incompleto.");
        }

        byte[] cabecera = new byte[5];
        try (java.io.InputStream entrada = Files.newInputStream(archivo)) {
            if (entrada.read(cabecera) != cabecera.length
                    || !Arrays.equals(cabecera, new byte[]{'%', 'P', 'D', 'F', '-'})) {
                throw new IOException("El archivo no tiene una cabecera PDF válida.");
            }
        }

        try (PDDocument documento = Loader.loadPDF(archivo.toFile())) {
            if (documento.isEncrypted()) {
                throw new IOException("El PDF está protegido con contraseña.");
            }
            if (documento.getNumberOfPages() < 1) {
                throw new IOException("El PDF no contiene páginas.");
            }
            return documento.getNumberOfPages() + " página(s)";
        } catch (IOException ex) {
            throw new IOException("El PDF está dañado o no se puede leer: " + ex.getMessage(), ex);
        }
    }

    public static String copiar(DatosAplicacion datos, Path origen, int trabajadorId)
            throws IOException {
        inspeccionar(origen);
        Path carpeta = datos.getCarpetaDatos().resolve("documentos").resolve("hojas-vida");
        Files.createDirectories(carpeta);
        String nombre = "trabajador-" + trabajadorId + "-" + UUID.randomUUID() + ".pdf";
        Path destino = carpeta.resolve(nombre);
        Files.copy(origen, destino, StandardCopyOption.REPLACE_EXISTING);
        return datos.getDirectorioBase().relativize(destino).toString();
    }

    public static Path resolver(DatosAplicacion datos, String rutaRelativa) throws IOException {
        Path base = datos.getDirectorioBase().toAbsolutePath().normalize();
        Path archivo = base.resolve(rutaRelativa).normalize();
        if (!archivo.startsWith(base)) {
            throw new IOException("La ruta del documento sale de la carpeta del proyecto.");
        }
        return archivo;
    }

    public static void eliminar(DatosAplicacion datos, String rutaRelativa) throws IOException {
        if (rutaRelativa != null && !rutaRelativa.isBlank()) {
            Files.deleteIfExists(resolver(datos, rutaRelativa));
        }
    }

    public static void abrir(DatosAplicacion datos, String rutaRelativa) throws IOException {
        if (!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
            throw new IOException("Este sistema no permite abrir archivos desde el escritorio.");
        }
        Desktop.getDesktop().open(resolver(datos, rutaRelativa).toFile());
    }
}
