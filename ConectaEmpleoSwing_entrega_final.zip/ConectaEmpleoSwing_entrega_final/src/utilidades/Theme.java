package utilidades;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.event.ChangeListener;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;

/** Colores y estilos Swing compartidos. Los componentes se pintan desde su creación. */
public final class Theme {
    public static final Color GREEN = new Color(0x087F5B);
    public static final Color GREEN_DARK = new Color(0x006446);
    public static final Color PETROL = new Color(0x164E63);
    public static final Color NAV_BUTTON = new Color(0x1D647C);
    public static final Color TEAL = new Color(0x0D9488);
    public static final Color CANVAS = new Color(0xF8FAFC);
    public static final Color SURFACE = Color.WHITE;
    public static final Color BORDER = new Color(0xE2E8F0);
    public static final Color TEXT = new Color(0x1E293B);
    public static final Color MUTED = new Color(0x64748B);
    public static final Color AMBER = new Color(0xF59E0B);
    public static final Color MINT = new Color(0xA7F3D0);
    public static final Color PALE_GREEN = new Color(0xD1FAE5);
    public static final Color RED = new Color(0xC2413B);
    public static final Color PALE_GRAY = new Color(0xF1F5F9);

    public enum TipoBoton {
        PRINCIPAL, EDITAR, CONSULTAR, ELIMINAR, CANCELAR, NAVEGACION, NAVEGACION_SELECCIONADA
    }

    private record ColoresBoton(Color fondo, Color texto, Color encima, Color presionado,
            Color deshabilitado, Color textoDeshabilitado, Color borde) { }

    private Theme() {
    }

    /** Pinta el fondo propio para que el Look and Feel no lo deje transparente. */
    private static final class BotonConFondo extends JButton {
        private BotonConFondo(String texto) {
            super(texto);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D fondo = (Graphics2D) graphics.create();
            fondo.setColor(getBackground());
            fondo.fillRect(0, 0, getWidth(), getHeight());
            fondo.dispose();
            super.paintComponent(graphics);
        }
    }

    public static void install() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Swing conserva su apariencia predeterminada si el tema del sistema falla.
        }

        UIManager.put("Panel.background", SURFACE);
        UIManager.put("TextField.background", SURFACE);
        UIManager.put("TextField.foreground", TEXT);
        UIManager.put("TextField.caretForeground", GREEN);
        UIManager.put("TextField.selectionBackground", PALE_GREEN);
        UIManager.put("TextField.selectionForeground", TEXT);
        UIManager.put("PasswordField.background", SURFACE);
        UIManager.put("PasswordField.foreground", TEXT);
        UIManager.put("ComboBox.background", SURFACE);
        UIManager.put("ComboBox.foreground", TEXT);
        UIManager.put("Table.background", SURFACE);
        UIManager.put("Table.foreground", TEXT);
        UIManager.put("Table.selectionBackground", PALE_GREEN);
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("TableHeader.background", CANVAS);
        UIManager.put("TableHeader.foreground", TEXT);
        UIManager.put("ScrollPane.background", SURFACE);
        UIManager.put("Viewport.background", SURFACE);
        UIManager.put("OptionPane.background", SURFACE);
        UIManager.put("OptionPane.messageArea.background", SURFACE);
        UIManager.put("Button.background", SURFACE);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("Table.rowHeight", 34);
        UIManager.put("ScrollBar.width", 10);
        UIManager.put("defaultFont", new Font("Segoe UI", Font.PLAIN, 13));
    }

    public static JPanel card() {
        JPanel panel = new JPanel();
        panel.setOpaque(true);
        panel.setBackground(SURFACE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(16, 16, 16, 16)));
        return panel;
    }

    public static JButton button(String text, TipoBoton tipo) {
        JButton button = new BotonConFondo(text);
        // El fondo lo pinta BotonConFondo. Evita que el Look and Feel del sistema
        // vuelva a pintar encima con el color predeterminado (blanco).
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(true);
        button.setFocusPainted(false);
        button.setFont(button.getFont().deriveFont(Font.BOLD, 13f));
        button.putClientProperty("conectaempleo.tipoBoton", tipo);
        aplicarColoresBoton(button, tipo);
        ChangeListener estados = event -> actualizarEstadoBoton(button,
                (TipoBoton) button.getClientProperty("conectaempleo.tipoBoton"));
        button.getModel().addChangeListener(estados);
        return button;
    }

    /** Aplica una identidad por acción y conserva estados de cursor, pulsado y deshabilitado. */
    public static void aplicarTipoBoton(JButton button, TipoBoton tipo) {
        button.putClientProperty("conectaempleo.tipoBoton", tipo);
        aplicarColoresBoton(button, tipo);
    }

    private static ColoresBoton colores(TipoBoton tipo) {
        return switch (tipo) {
            case PRINCIPAL -> new ColoresBoton(GREEN, Color.WHITE, new Color(0x09916A), GREEN_DARK,
                    PALE_GRAY, MUTED, GREEN_DARK);
            case EDITAR -> new ColoresBoton(PETROL, Color.WHITE, new Color(0x1D647C), new Color(0x103E50),
                    PALE_GRAY, MUTED, PETROL);
            case CONSULTAR -> new ColoresBoton(SURFACE, TEAL, new Color(0xE6FFFB), new Color(0xCCFBF1),
                    PALE_GRAY, MUTED, TEAL);
            case ELIMINAR -> new ColoresBoton(RED, Color.WHITE, new Color(0xD14F48), new Color(0xA9322C),
                    PALE_GRAY, MUTED, RED);
            case CANCELAR -> new ColoresBoton(PALE_GRAY, TEXT, new Color(0xE2E8F0), new Color(0xCBD5E1),
                    PALE_GRAY, MUTED, BORDER);
            case NAVEGACION -> new ColoresBoton(NAV_BUTTON, Color.WHITE,
                    new Color(0x09916A), new Color(0x006446),
                    new Color(0x547581), new Color(0xD5E2E7), PETROL);
            case NAVEGACION_SELECCIONADA -> new ColoresBoton(GREEN, Color.WHITE,
                    new Color(0x09916A), GREEN_DARK, new Color(0x547581), Color.WHITE, GREEN);
        };
    }

    private static void aplicarColoresBoton(JButton button, TipoBoton tipo) {
        button.setFont(button.getFont().deriveFont(Font.BOLD, tipo == TipoBoton.NAVEGACION
                || tipo == TipoBoton.NAVEGACION_SELECCIONADA ? 13f : 12.5f));
        button.setHorizontalAlignment(tipo == TipoBoton.NAVEGACION
                || tipo == TipoBoton.NAVEGACION_SELECCIONADA ? javax.swing.SwingConstants.LEFT
                        : javax.swing.SwingConstants.CENTER);
        button.setBorder(tipo == TipoBoton.NAVEGACION || tipo == TipoBoton.NAVEGACION_SELECCIONADA
                ? new EmptyBorder(11, 11, 11, 8)
                : BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(colores(tipo).borde),
                        new EmptyBorder(8, 13, 8, 13)));
        actualizarEstadoBoton(button, tipo);
    }

    private static void actualizarEstadoBoton(JButton button, TipoBoton tipo) {
        ColoresBoton paleta = colores(tipo);
        if (!button.isEnabled()) {
            button.setBackground(paleta.deshabilitado);
            button.setForeground(paleta.textoDeshabilitado);
        } else if (button.getModel().isPressed()) {
            button.setBackground(paleta.presionado);
            button.setForeground(paleta.texto);
        } else if (button.getModel().isRollover()) {
            button.setBackground(paleta.encima);
            button.setForeground(paleta.texto);
        } else {
            button.setBackground(paleta.fondo);
            button.setForeground(paleta.texto);
        }
    }

    public static JTextField textField(String value, int columns) {
        JTextField field = new JTextField(value, columns);
        field.setOpaque(true);
        field.setBackground(SURFACE);
        field.setForeground(TEXT);
        field.setCaretColor(GREEN);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), new EmptyBorder(6, 8, 6, 8)));
        return field;
    }

    public static JComboBox<String> comboBox(String[] values) {
        JComboBox<String> combo = new JComboBox<>(values);
        combo.setOpaque(true);
        combo.setBackground(SURFACE);
        combo.setForeground(TEXT);
        return combo;
    }

    public static void styleTable(JTable table) {
        table.setOpaque(true);
        table.setBackground(SURFACE);
        table.setForeground(TEXT);
        table.setSelectionBackground(PALE_GREEN);
        table.setSelectionForeground(TEXT);
        table.setGridColor(BORDER);
        table.setFillsViewportHeight(true);
        table.setRowMargin(0);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new java.awt.Dimension(0, 1));
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable owner, Object value,
                    boolean selected, boolean focused, int row, int column) {
                java.awt.Component component = super.getTableCellRendererComponent(
                        owner, value, selected, focused, row, column);
                if (!selected) {
                    component.setBackground(row % 2 == 0 ? SURFACE : CANVAS);
                    component.setForeground(TEXT);
                }
                setHorizontalAlignment(column == 0 ? javax.swing.SwingConstants.CENTER
                        : javax.swing.SwingConstants.LEFT);
                setBorder(new EmptyBorder(0, 9, 0, 9));
                return component;
            }
        });
        table.getTableHeader().setOpaque(true);
        table.getTableHeader().setBackground(CANVAS);
        table.getTableHeader().setForeground(TEXT);
        table.getTableHeader().setFont(table.getTableHeader().getFont().deriveFont(Font.BOLD, 12f));
        table.getTableHeader().setPreferredSize(new java.awt.Dimension(0, 38));
    }

    public static JScrollPane scrollPane(java.awt.Component content, Color background) {
        JScrollPane scroll = new JScrollPane(content);
        scroll.setOpaque(true);
        scroll.setBackground(background);
        scroll.getViewport().setOpaque(true);
        scroll.getViewport().setBackground(background);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER));
        return scroll;
    }

    public static javax.swing.JLabel label(String text, int size, boolean bold, Color color) {
        javax.swing.JLabel label = new javax.swing.JLabel(text);
        label.setFont(label.getFont().deriveFont(bold ? Font.BOLD : Font.PLAIN, (float) size));
        label.setForeground(color);
        label.setOpaque(false);
        return label;
    }
}
