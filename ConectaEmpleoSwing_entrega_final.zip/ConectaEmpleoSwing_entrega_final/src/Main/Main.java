package Main;

import modelo.DatosAplicacion;
import utilidades.ArchivoUtil;
import utilidades.DatosIniciales;
import utilidades.Theme;
import vista.MainFrame;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/** Punto de entrada. Carga los archivos y crea la ventana en el hilo de Swing. */
public final class Main {
    private Main() {
    }

    public static void main(String[] args) {
        try {
            Path ubicacionCodigo = Path.of(
                    Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            DatosAplicacion datos = ArchivoUtil.cargar(resolverDirectorioDatos(ubicacionCodigo));
            DatosIniciales.inicializar(datos);
            SwingUtilities.invokeLater(() -> {
                Theme.install();
                MainFrame ventana = new MainFrame(datos);
                ventana.setVisible(true);
            });
        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null,
                    "No se pudo iniciar ConectaEmpleo:\n" + ex.getMessage(),
                    "Error de inicio", JOptionPane.ERROR_MESSAGE));
            ex.printStackTrace();
        }
    }

    public static Path resolverDirectorioDatos(Path ubicacionCodigo) {
        Path ubicacion = ubicacionCodigo.toAbsolutePath().normalize();
        Path directorio = Files.isDirectory(ubicacion) ? ubicacion : ubicacion.getParent();
        if (directorio == null) return Path.of(".").toAbsolutePath().normalize();

        Path nombre = directorio.getFileName();
        if (nombre == null) return directorio;
        if (nombre.toString().equalsIgnoreCase("dist") && directorio.getParent() != null) {
            return directorio.getParent();
        }
        if (nombre.toString().equalsIgnoreCase("classes")) {
            Path build = directorio.getParent();
            if (build != null && build.getFileName() != null
                    && build.getFileName().toString().equalsIgnoreCase("build")
                    && build.getParent() != null) {
                return build.getParent();
            }
        }
        return directorio;
    }
}
