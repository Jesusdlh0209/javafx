package controlador;

import modelo.*;
import utilidades.FormularioUtil;
import utilidades.PasswordUtil;
import utilidades.Validaciones;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/** Muestra perfiles y ejecuta el CRUD permitido para cada usuario. */
public final class TrabajadoresController implements TableController {
    private final DatosAplicacion datos;

    public TrabajadoresController(DatosAplicacion datos) {
        this.datos = datos;
    }

    @Override
    public String title() {
        if (datos.esAdministrador()) return "Gestión de trabajadores";
        if (datos.esEmpresa()) return "Candidatos postulados";
        return "Mi perfil laboral";
    }

    @Override
    public List<String> columns() {
        return List.of("ID", "Nombre", "Documento", "Correo", "Teléfono", "Ubicación",
                "Nivel educativo", "Habilidades", "Disponibilidad", "Experiencia");
    }

    @Override
    public List<Object[]> rows() {
        List<Object[]> filas = new ArrayList<>();
        for (Trabajador trabajador : trabajadoresVisibles()) {
            filas.add(new Object[]{trabajador.getId(), trabajador.getNombre(),
                trabajador.getDocumento(), trabajador.getCorreo(), trabajador.getTelefono(),
                trabajador.getUbicacion(), trabajador.getNivelEducativo(),
                FormularioUtil.unirLista(trabajador.getHabilidades()),
                trabajador.getDisponibilidad(), trabajador.getExperiencia()});
        }
        return filas;
    }

    @Override
    public List<FormField> fields(Integer id) {
        Trabajador trabajador = id == null ? null : buscarVisible(id);
        if (id == null && !canCreate()) {
            throw new SecurityException("Solo el administrador puede registrar trabajadores.");
        }
        List<FormField> campos = new ArrayList<>();
        campos.add(FormField.text("nombre", "Nombre completo",
                trabajador == null ? "" : trabajador.getNombre()));
        campos.add(FormField.text("documento", "Documento",
                trabajador == null ? "" : trabajador.getDocumento()));
        campos.add(FormField.text("correo", "Correo",
                trabajador == null ? "" : trabajador.getCorreo()));
        campos.add(FormField.text("telefono", "Teléfono",
                trabajador == null ? "" : trabajador.getTelefono()));
        campos.add(FormField.text("ubicacion", "Ubicación",
                trabajador == null ? "Cartagena" : trabajador.getUbicacion()));
        campos.add(FormField.text("nivel", "Nivel educativo",
                trabajador == null ? "" : trabajador.getNivelEducativo()));
        campos.add(FormField.choice("disponibilidad", "Disponibilidad",
                trabajador == null ? "Disponible" : trabajador.getDisponibilidad(),
                List.of("Disponible", "En búsqueda", "No disponible")));
        campos.add(FormField.area("experiencia", "Experiencia",
                trabajador == null ? "" : trabajador.getExperiencia()));
        campos.add(FormField.text("habilidades", "Habilidades (separadas por coma)",
                trabajador == null ? "" : FormularioUtil.unirLista(trabajador.getHabilidades())));
        if (trabajador == null) {
            campos.add(FormField.text("usuario", "Usuario", ""));
            campos.add(FormField.text("password", "Contraseña (mínimo 8 caracteres)", ""));
        } else if (datos.esAdministrador()) {
            campos.add(FormField.text("password", "Nueva contraseña (opcional)", ""));
        }
        return campos;
    }

    @Override
    public void save(Integer id, Map<String, String> valores) {
        if (id == null) {
            crear(valores);
        } else {
            actualizar(id, valores);
        }
    }

    private void crear(Map<String, String> valores) {
        exigirAdministrador();
        String contrasena = FormularioUtil.valor(valores, "password");
        if (contrasena.length() < 8) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres.");
        }
        String usuario = FormularioUtil.valor(valores, "usuario");
        Validaciones.requerido(usuario, "usuario");
        validarUsuarioUnico(usuario, null);
        Trabajador trabajador = new Trabajador(siguienteId(),
                FormularioUtil.valor(valores, "nombre"), usuario,
                FormularioUtil.valor(valores, "correo"), FormularioUtil.valor(valores, "telefono"),
                PasswordUtil.hash(contrasena.toCharArray()),
                FormularioUtil.valor(valores, "documento"), FormularioUtil.valor(valores, "ubicacion"),
                FormularioUtil.valor(valores, "nivel"), FormularioUtil.valor(valores, "disponibilidad"),
                FormularioUtil.valor(valores, "experiencia"),
                FormularioUtil.separarLista(valores.get("habilidades")));
        validarDatos(trabajador, null);
        datos.trabajadores.add(trabajador);
        sincronizarHabilidades(trabajador);
        datos.guardar();
    }

    private void actualizar(int id, Map<String, String> valores) {
        Trabajador trabajador = buscarVisible(id);
        if (!datos.esAdministrador() && datos.getUsuarioActual() != trabajador) {
            throw new SecurityException("Solo puedes editar tu propio perfil.");
        }
        String nombre = FormularioUtil.valor(valores, "nombre");
        String documento = FormularioUtil.valor(valores, "documento");
        String correo = FormularioUtil.valor(valores, "correo");
        String telefono = FormularioUtil.valor(valores, "telefono");
        String ubicacion = FormularioUtil.valor(valores, "ubicacion");
        String nivel = FormularioUtil.valor(valores, "nivel");
        String disponibilidad = FormularioUtil.valor(valores, "disponibilidad");
        String experiencia = FormularioUtil.valor(valores, "experiencia");
        List<String> habilidades = FormularioUtil.separarLista(valores.get("habilidades"));
        String contrasena = FormularioUtil.valor(valores, "password");
        if (!contrasena.isBlank()) {
            if (!datos.esAdministrador()) {
                throw new SecurityException("Cambia tu contraseña desde el menú de cuenta.");
            }
            validarContrasena(contrasena);
        }
        Trabajador candidato = new Trabajador(trabajador.getId(), nombre, trabajador.getUsuario(),
                correo, telefono, trabajador.getPasswordHash(), documento, ubicacion, nivel,
                disponibilidad, experiencia, habilidades);
        validarDatos(candidato, trabajador.getId());
        trabajador.setNombre(nombre);
        trabajador.setDocumento(documento);
        trabajador.setCorreo(correo);
        trabajador.setTelefono(telefono);
        trabajador.setUbicacion(ubicacion);
        trabajador.setNivelEducativo(nivel);
        trabajador.setDisponibilidad(disponibilidad);
        trabajador.setExperiencia(experiencia);
        trabajador.setHabilidades(habilidades);
        if (!contrasena.isBlank()) {
            trabajador.setPasswordHash(PasswordUtil.hash(contrasena.toCharArray()));
        }
        sincronizarHabilidades(trabajador);
        datos.guardar();
    }

    @Override
    public void delete(int id) {
        exigirAdministrador();
        Trabajador trabajador = buscar(id);
        if (datos.postulaciones.stream().anyMatch(p -> p.getTrabajadorId() == id)) {
            throw new IllegalArgumentException("No se puede eliminar: el trabajador tiene postulaciones relacionadas.");
        }
        if (datos.documentos.stream().anyMatch(d -> d.getTrabajadorId() == id)) {
            throw new IllegalArgumentException("No se puede eliminar: primero elimina su hoja de vida.");
        }
        if (datos.capacitaciones.stream().anyMatch(c -> c.getParticipanteIds().contains(id))) {
            throw new IllegalArgumentException("No se puede eliminar: el trabajador está inscrito en una capacitación.");
        }
        for (Habilidad habilidad : datos.habilidades) {
            Set<Integer> ids = new HashSet<>(habilidad.getTrabajadorIds());
            ids.remove(id);
            habilidad.setTrabajadorIds(ids);
        }
        datos.trabajadores.remove(trabajador);
        datos.guardar();
    }

    @Override
    public boolean canCreate() {
        return datos.esAdministrador();
    }

    @Override
    public boolean canEdit() {
        return datos.esAdministrador() || datos.esTrabajador();
    }

    @Override
    public boolean canDelete() {
        return datos.esAdministrador();
    }

    @Override
    public boolean canShowDetails() {
        return true;
    }

    @Override
    public String details(int id) {
        Trabajador trabajador = buscarVisible(id);
        return "Nombre: " + trabajador.getNombre()
                + "\nUbicación: " + trabajador.getUbicacion()
                + "\nNivel educativo: " + trabajador.getNivelEducativo()
                + "\nDisponibilidad: " + trabajador.getDisponibilidad()
                + "\nHabilidades: " + FormularioUtil.unirLista(trabajador.getHabilidades())
                + "\n\nExperiencia\n" + trabajador.getExperiencia();
    }

    private List<Trabajador> trabajadoresVisibles() {
        if (datos.esAdministrador()) {
            return datos.trabajadores;
        }
        if (datos.getUsuarioActual() instanceof Trabajador) {
            return List.of((Trabajador) datos.getUsuarioActual());
        }
        if (datos.getUsuarioActual() instanceof Empresa) {
            int empresaId = ((Empresa) datos.getUsuarioActual()).getId();
            Set<Integer> ofertasPropias = new HashSet<>();
            for (OfertaLaboral oferta : datos.ofertas) {
                if (oferta.getEmpresaId() == empresaId) ofertasPropias.add(oferta.getId());
            }
            Set<Integer> candidatos = new HashSet<>();
            for (Postulacion postulacion : datos.postulaciones) {
                if (ofertasPropias.contains(postulacion.getOfertaId())) {
                    candidatos.add(postulacion.getTrabajadorId());
                }
            }
            List<Trabajador> visibles = new ArrayList<>();
            for (Trabajador trabajador : datos.trabajadores) {
                if (candidatos.contains(trabajador.getId())) visibles.add(trabajador);
            }
            return visibles;
        }
        throw new SecurityException("Inicia sesión para consultar trabajadores.");
    }

    private Trabajador buscarVisible(int id) {
        for (Trabajador trabajador : trabajadoresVisibles()) {
            if (trabajador.getId() == id) return trabajador;
        }
        throw new SecurityException("No tienes permiso para consultar ese perfil.");
    }

    private Trabajador buscar(int id) {
        return datos.trabajadores.stream().filter(t -> t.getId() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("El trabajador ya no existe."));
    }

    private void validarDatos(Trabajador trabajador, Integer excluirId) {
        Validaciones.requerido(trabajador.getNombre(), "nombre");
        Validaciones.documento(trabajador.getDocumento());
        Validaciones.correo(trabajador.getCorreo());
        Validaciones.telefono(trabajador.getTelefono());
        for (Trabajador otro : datos.trabajadores) {
            if ((excluirId == null || otro.getId() != excluirId)
                    && otro.getDocumento().equalsIgnoreCase(trabajador.getDocumento())) {
                throw new IllegalArgumentException("El documento ya está registrado.");
            }
        }
    }

    private void validarUsuarioUnico(String usuario, Integer excluirId) {
        boolean existe = datos.administradores.stream().anyMatch(u -> u.getUsuario().equalsIgnoreCase(usuario))
                || datos.empresas.stream().anyMatch(u -> u.getUsuario().equalsIgnoreCase(usuario))
                || datos.trabajadores.stream().anyMatch(u -> (excluirId == null || u.getId() != excluirId)
                        && u.getUsuario().equalsIgnoreCase(usuario));
        if (existe) throw new IllegalArgumentException("El nombre de usuario ya está registrado.");
    }

    private void sincronizarHabilidades(Trabajador trabajador) {
        Set<String> nombres = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        nombres.addAll(trabajador.getHabilidades());
        for (Habilidad habilidad : new ArrayList<>(datos.habilidades)) {
            Set<Integer> ids = new HashSet<>(habilidad.getTrabajadorIds());
            if (nombres.stream().anyMatch(n -> n.equalsIgnoreCase(habilidad.getNombre()))) {
                ids.add(trabajador.getId());
            } else {
                ids.remove(trabajador.getId());
            }
            habilidad.setTrabajadorIds(ids);
        }
        for (String nombre : nombres) {
            boolean existe = datos.habilidades.stream()
                    .anyMatch(h -> h.getNombre().equalsIgnoreCase(nombre));
            if (!existe) {
                Habilidad habilidad = new Habilidad(siguienteIdHabilidad(), nombre, "General");
                habilidad.setTrabajadorIds(Set.of(trabajador.getId()));
                datos.habilidades.add(habilidad);
            }
        }
    }

    private int siguienteId() {
        return datos.trabajadores.stream().mapToInt(Trabajador::getId).max().orElse(0) + 1;
    }

    private int siguienteIdHabilidad() {
        return datos.habilidades.stream().mapToInt(Habilidad::getId).max().orElse(0) + 1;
    }

    private void validarContrasena(String contrasena) {
        if (contrasena.length() < 8) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres.");
        }
    }

    private void exigirAdministrador() {
        if (!datos.esAdministrador()) {
            throw new SecurityException("Esta operación requiere permisos de administrador.");
        }
    }
}
