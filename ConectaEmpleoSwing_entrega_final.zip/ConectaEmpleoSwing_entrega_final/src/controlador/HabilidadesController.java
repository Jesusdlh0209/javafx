package controlador;

import modelo.DatosAplicacion;
import modelo.Habilidad;
import modelo.Trabajador;
import utilidades.FormularioUtil;
import utilidades.Validaciones;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Administra el catálogo y permite a cada trabajador asociar sus habilidades. */
public final class HabilidadesController implements TableController {
    private final DatosAplicacion datos;

    public HabilidadesController(DatosAplicacion datos) {
        this.datos = datos;
    }

    @Override
    public String title() {
        return datos.esTrabajador() ? "Mis habilidades" : "Habilidades y competencias";
    }

    @Override
    public List<String> columns() {
        return List.of("ID", "Habilidad", "Categoría", "Trabajadores asociados");
    }

    @Override
    public List<Object[]> rows() {
        exigirSesion();
        List<Object[]> filas = new ArrayList<>();
        for (Habilidad habilidad : datos.habilidades) {
            if (!datos.esTrabajador() || trabajadorActual().getHabilidades().stream()
                    .anyMatch(nombre -> nombre.equalsIgnoreCase(habilidad.getNombre()))) {
                filas.add(new Object[]{habilidad.getId(), habilidad.getNombre(), habilidad.getCategoria(),
                    habilidad.getTrabajadorIds().size()});
            }
        }
        return filas;
    }

    @Override
    public List<FormField> fields(Integer id) {
        if (datos.esTrabajador() && id != null) {
            throw new SecurityException("Selecciona Nuevo para añadir una habilidad a tu perfil.");
        }
        if (!datos.esAdministrador() && !datos.esTrabajador()) exigirAdministrador();
        Habilidad habilidad = id == null ? null : buscar(id);
        List<FormField> campos = new ArrayList<>();
        campos.add(FormField.text("nombre", "Nombre de la habilidad",
                habilidad == null ? "" : habilidad.getNombre()));
        if (datos.esAdministrador()) {
            campos.add(FormField.text("categoria", "Categoría",
                    habilidad == null ? "General" : habilidad.getCategoria()));
        }
        return campos;
    }

    @Override
    public void save(Integer id, Map<String, String> valores) {
        if (datos.esTrabajador()) {
            if (id != null) throw new SecurityException("No puedes editar el catálogo de habilidades.");
            asociarAperfil(FormularioUtil.valor(valores, "nombre"));
            return;
        }
        exigirAdministrador();
        String nombre = FormularioUtil.valor(valores, "nombre");
        String categoria = FormularioUtil.valor(valores, "categoria");
        Validaciones.requerido(nombre, "habilidad");
        validarUnica(nombre, id);
        if (id == null) {
            datos.habilidades.add(new Habilidad(siguienteId(), nombre, categoria));
        } else {
            Habilidad habilidad = buscar(id);
            String anterior = habilidad.getNombre();
            habilidad.setNombre(nombre);
            habilidad.setCategoria(categoria);
            actualizarNombreEnTrabajadores(anterior, nombre);
        }
        datos.guardar();
    }

    private void asociarAperfil(String nombre) {
        Validaciones.requerido(nombre, "habilidad");
        Trabajador trabajador = trabajadorActual();
        List<String> propias = new ArrayList<>(trabajador.getHabilidades());
        if (propias.stream().anyMatch(actual -> actual.equalsIgnoreCase(nombre))) {
            throw new IllegalArgumentException("Esa habilidad ya está en tu perfil.");
        }

        Habilidad habilidad = datos.habilidades.stream()
                .filter(h -> h.getNombre().equalsIgnoreCase(nombre)).findFirst().orElse(null);
        if (habilidad == null) {
            habilidad = new Habilidad(siguienteId(), nombre, "General");
            datos.habilidades.add(habilidad);
        }
        propias.add(habilidad.getNombre());
        trabajador.setHabilidades(propias);
        Set<Integer> trabajadores = new HashSet<>(habilidad.getTrabajadorIds());
        trabajadores.add(trabajador.getId());
        habilidad.setTrabajadorIds(trabajadores);
        datos.guardar();
    }

    @Override
    public void delete(int id) {
        exigirAdministrador();
        Habilidad habilidad = buscar(id);
        boolean asociada = !habilidad.getTrabajadorIds().isEmpty()
                || datos.trabajadores.stream().anyMatch(t -> t.getHabilidades().stream()
                        .anyMatch(nombre -> nombre.equalsIgnoreCase(habilidad.getNombre())));
        if (asociada) {
            throw new IllegalArgumentException("No se puede eliminar: primero quita la habilidad de los perfiles relacionados.");
        }
        datos.habilidades.remove(habilidad);
        datos.guardar();
    }

    @Override
    public boolean canCreate() {
        return datos.esAdministrador() || datos.esTrabajador();
    }

    @Override
    public boolean canEdit() {
        return datos.esAdministrador();
    }

    @Override
    public boolean canDelete() {
        return datos.esAdministrador();
    }

    @Override
    public String actionLabel() {
        return "Quitar de mi perfil";
    }

    @Override
    public boolean canRunAction() {
        return datos.esTrabajador();
    }

    @Override
    public void runAction(int id) {
        if (!datos.esTrabajador()) exigirAdministrador();
        Trabajador trabajador = trabajadorActual();
        Habilidad habilidad = buscar(id);
        List<String> propias = new ArrayList<>(trabajador.getHabilidades());
        boolean cambio = propias.removeIf(nombre -> nombre.equalsIgnoreCase(habilidad.getNombre()));
        if (!cambio) throw new IllegalArgumentException("La habilidad ya no está en tu perfil.");
        trabajador.setHabilidades(propias);
        Set<Integer> trabajadores = new HashSet<>(habilidad.getTrabajadorIds());
        trabajadores.remove(trabajador.getId());
        habilidad.setTrabajadorIds(trabajadores);
        datos.guardar();
    }

    private void actualizarNombreEnTrabajadores(String nombreAnterior, String nuevoNombre) {
        for (Trabajador trabajador : datos.trabajadores) {
            List<String> nombres = new ArrayList<>(trabajador.getHabilidades());
            for (int i = 0; i < nombres.size(); i++) {
                if (nombres.get(i).equalsIgnoreCase(nombreAnterior)) nombres.set(i, nuevoNombre);
            }
            trabajador.setHabilidades(nombres);
        }
    }

    private Habilidad buscar(int id) {
        return datos.habilidades.stream().filter(h -> h.getId() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("La habilidad ya no existe."));
    }

    private int siguienteId() {
        return datos.habilidades.stream().mapToInt(Habilidad::getId).max().orElse(0) + 1;
    }

    private void validarUnica(String nombre, Integer excluirId) {
        boolean repetida = datos.habilidades.stream()
                .anyMatch(h -> (excluirId == null || h.getId() != excluirId)
                        && h.getNombre().equalsIgnoreCase(nombre));
        if (repetida) throw new IllegalArgumentException("La habilidad ya existe.");
    }

    private Trabajador trabajadorActual() {
        if (datos.getUsuarioActual() instanceof Trabajador) {
            return (Trabajador) datos.getUsuarioActual();
        }
        throw new SecurityException("Esta acción requiere una cuenta de trabajador.");
    }

    private void exigirSesion() {
        if (datos.getUsuarioActual() == null) throw new SecurityException("Inicia sesión para continuar.");
    }

    private void exigirAdministrador() {
        if (!datos.esAdministrador()) {
            throw new SecurityException("Esta operación requiere permisos de administrador.");
        }
    }
}
