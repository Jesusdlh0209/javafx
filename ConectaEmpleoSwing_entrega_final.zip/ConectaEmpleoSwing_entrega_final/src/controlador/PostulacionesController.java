package controlador;

import modelo.DatosAplicacion;
import modelo.Empresa;
import modelo.EstadoOferta;
import modelo.EstadoPostulacion;
import modelo.OfertaLaboral;
import modelo.Postulacion;
import modelo.Trabajador;
import utilidades.Validaciones;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** Postulaciones: el trabajador aplica o retira; empresa y admin actualizan el estado. */
public final class PostulacionesController implements TableController {
    private final DatosAplicacion datos;

    public PostulacionesController(DatosAplicacion datos) {
        this.datos = datos;
    }

    @Override
    public String title() {
        return datos.esEmpresa() ? "Postulaciones recibidas" : "Postulaciones";
    }

    @Override
    public List<String> columns() {
        return List.of("ID", "Fecha", "Trabajador", "Oferta", "Empresa", "Estado");
    }

    @Override
    public List<Object[]> rows() {
        exigirSesion();
        List<Object[]> filas = new ArrayList<>();
        for (Postulacion postulacion : postulacionesVisibles()) {
            Trabajador trabajador = buscarTrabajador(postulacion.getTrabajadorId());
            OfertaLaboral oferta = buscarOferta(postulacion.getOfertaId());
            Empresa empresa = oferta == null ? null : buscarEmpresa(oferta.getEmpresaId());
            filas.add(new Object[]{postulacion.getId(), postulacion.getFecha(),
                trabajador == null ? "Perfil eliminado" : trabajador.getNombre(),
                oferta == null ? "Oferta eliminada" : oferta.getCargo(),
                empresa == null ? "—" : empresa.getNombre(), postulacion.getEstado()});
        }
        return filas;
    }

    @Override
    public List<FormField> fields(Integer id) {
        exigirPuedeGestionarEstados();
        Postulacion postulacion = buscarVisible(id);
        List<String> estados = new ArrayList<>();
        for (EstadoPostulacion estado : EstadoPostulacion.values()) estados.add(estado.name());
        return List.of(FormField.choice("estado", "Estado del proceso",
                postulacion.getEstado().name(), estados));
    }

    @Override
    public void save(Integer id, java.util.Map<String, String> valores) {
        exigirPuedeGestionarEstados();
        if (id == null) throw new IllegalArgumentException("Selecciona una postulación.");
        Postulacion postulacion = buscarVisible(id);
        EstadoPostulacion estado;
        try {
            estado = EstadoPostulacion.valueOf(valores.get("estado"));
        } catch (RuntimeException ex) {
            throw new IllegalArgumentException("Selecciona un estado válido.");
        }
        postulacion.setEstado(estado);
        datos.guardar();
    }

    public void postular(int ofertaId) {
        if (!(datos.getUsuarioActual() instanceof Trabajador)) {
            throw new SecurityException("Solo un trabajador puede postularse.");
        }
        Trabajador trabajador = (Trabajador) datos.getUsuarioActual();
        OfertaLaboral oferta = buscarOferta(ofertaId);
        if (oferta == null) throw new IllegalArgumentException("La oferta ya no existe.");
        if (oferta.getEstado() != EstadoOferta.ACTIVA || !oferta.estaDisponible()) {
            throw new IllegalArgumentException("La oferta está cerrada o vencida.");
        }
        boolean repetida = datos.postulaciones.stream().anyMatch(p ->
                p.getTrabajadorId() == trabajador.getId() && p.getOfertaId() == ofertaId);
        if (repetida) throw new IllegalArgumentException("Ya te postulaste a esta oferta.");
        datos.postulaciones.add(new Postulacion(siguienteId(), trabajador.getId(), ofertaId,
                LocalDate.now(), EstadoPostulacion.PENDIENTE));
        datos.guardar();
    }

    @Override
    public void delete(int id) {
        Postulacion postulacion = buscarVisible(id);
        boolean esPropia = datos.getUsuarioActual() instanceof Trabajador
                && postulacion.getTrabajadorId() == datos.getUsuarioActual().getId();
        if (!datos.esAdministrador() && !esPropia) {
            throw new SecurityException("Solo puedes retirar tu propia postulación.");
        }
        datos.postulaciones.remove(postulacion);
        datos.guardar();
    }

    @Override
    public boolean canCreate() {
        return false;
    }

    @Override
    public boolean canEdit() {
        return datos.esAdministrador() || datos.esEmpresa();
    }

    @Override
    public boolean canDelete() {
        return datos.esAdministrador() || datos.esTrabajador();
    }

    @Override
    public boolean canShowDetails() {
        return true;
    }

    @Override
    public String details(int id) {
        Postulacion postulacion = buscarVisible(id);
        Trabajador trabajador = buscarTrabajador(postulacion.getTrabajadorId());
        OfertaLaboral oferta = buscarOferta(postulacion.getOfertaId());
        return "Fecha: " + postulacion.getFecha()
                + "\nTrabajador: " + (trabajador == null ? "Perfil eliminado" : trabajador.getNombre())
                + "\nOferta: " + (oferta == null ? "Oferta eliminada" : oferta.getCargo())
                + "\nEstado: " + postulacion.getEstado();
    }

    private List<Postulacion> postulacionesVisibles() {
        if (datos.esAdministrador()) return datos.postulaciones;
        if (datos.getUsuarioActual() instanceof Trabajador) {
            int trabajadorId = datos.getUsuarioActual().getId();
            return datos.postulaciones.stream()
                    .filter(p -> p.getTrabajadorId() == trabajadorId).collect(Collectors.toList());
        }
        if (datos.getUsuarioActual() instanceof Empresa) {
            int empresaId = datos.getUsuarioActual().getId();
            Set<Integer> ofertas = datos.ofertas.stream()
                    .filter(o -> o.getEmpresaId() == empresaId)
                    .map(OfertaLaboral::getId).collect(Collectors.toSet());
            return datos.postulaciones.stream()
                    .filter(p -> ofertas.contains(p.getOfertaId())).collect(Collectors.toList());
        }
        throw new SecurityException("Inicia sesión para continuar.");
    }

    private Postulacion buscarVisible(int id) {
        return postulacionesVisibles().stream().filter(p -> p.getId() == id).findFirst()
                .orElseThrow(() -> new SecurityException("No tienes permiso para consultar esa postulación."));
    }

    private Trabajador buscarTrabajador(int id) {
        return datos.trabajadores.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
    }

    private OfertaLaboral buscarOferta(int id) {
        return datos.ofertas.stream().filter(o -> o.getId() == id).findFirst().orElse(null);
    }

    private Empresa buscarEmpresa(int id) {
        return datos.empresas.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    private int siguienteId() {
        return datos.postulaciones.stream().mapToInt(Postulacion::getId).max().orElse(0) + 1;
    }

    private void exigirSesion() {
        if (datos.getUsuarioActual() == null) throw new SecurityException("Inicia sesión para continuar.");
    }

    private void exigirPuedeGestionarEstados() {
        if (!datos.esAdministrador() && !datos.esEmpresa()) {
            throw new SecurityException("Solo una empresa o el administrador pueden actualizar el proceso.");
        }
    }
}
