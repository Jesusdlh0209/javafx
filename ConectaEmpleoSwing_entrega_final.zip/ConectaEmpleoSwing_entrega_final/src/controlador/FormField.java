package controlador;

import java.util.List;

/** Describe un único campo de formulario para la ventana Swing compartida. */
public final class FormField {
    private final String key;
    private final String label;
    private final String value;
    private final List<String> options;
    private final boolean multiline;

    public FormField(String key, String label, String value) {
        this(key, label, value, List.of(), false);
    }

    public FormField(String key, String label, String value, List<String> options) {
        this(key, label, value, options, false);
    }

    public FormField(String key, String label, String value, List<String> options, boolean multiline) {
        this.key = key;
        this.label = label;
        this.value = value;
        this.options = options == null ? List.of() : List.copyOf(options);
        this.multiline = multiline;
    }

    public String key() {
        return key;
    }

    public String label() {
        return label;
    }

    public String value() {
        return value;
    }

    public List<String> options() {
        return options;
    }

    public boolean multiline() {
        return multiline;
    }

    public static FormField text(String key, String label, String value) {
        return new FormField(key, label, value);
    }

    public static FormField area(String key, String label, String value) {
        return new FormField(key, label, value, List.of(), true);
    }

    public static FormField choice(String key, String label, String value, List<String> options) {
        return new FormField(key, label, value, options, false);
    }
}
