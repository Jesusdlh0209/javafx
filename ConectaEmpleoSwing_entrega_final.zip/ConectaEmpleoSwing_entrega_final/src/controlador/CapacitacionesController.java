package controlador;

import modelo.Capacitacion;
import modelo.DatosAplicacion;
import modelo.Trabajador;
import utilidades.FormularioUtil;
import utilidades.Validaciones;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** CRUD de cursos y control de inscripciones de trabajadores. */
public final class CapacitacionesController implements TableController {
    private final DatosAplicacion datos;

    public CapacitacionesController(DatosAplicacion datos) {
        this.datos = datos;
    }

    @Override
    public String title() {
        return "Capacitaciones y cursos";
    }

    @Override
    public List<String> columns() {
        return List.of("ID", "Capacitación", "Entidad", "Inicio", "Finalización", "Cupos", "Inscritos");
    }

    @Override
    public List<Object[]> rows() {
        exigirSesion();
        List<Object[]> filas = new ArrayList<>();
        for (Capacitacion curso : datos.capacitaciones) {
            filas.add(new Object[]{curso.getId(), curso.getNombre(), curso.getEntidad(),
                curso.getFechaInicio(), curso.getFechaFin(), curso.getCupos(),
                curso.getParticipanteIds().size()});
        }
        return filas;
    }

    @Override
    public List<FormField> fields(Integer id) {
        exigirAdministrador();
        Capacitacion curso = id == null ? null : buscar(id);
        return List.of(
                FormField.text("nombre", "Nombre del curso", curso == null ? "" : curso.getNombre()),
                FormField.text("entidad", "Entidad formadora", curso == null ? "SENA" : curso.getEntidad()),
                FormField.area("descripcion", "Descripción", curso == null ? "" : curso.getDescripcion()),
                FormField.text("inicio", "Fecha de inicio (AAAA-MM-DD)", curso == null
                        ? LocalDate.now().plusDays(7).toString() : curso.getFechaInicio().toString()),
                FormField.text("fin", "Fecha de finalización (AAAA-MM-DD)", curso == null
                        ? LocalDate.now().plusDays(21).toString() : curso.getFechaFin().toString()),
                FormField.text("cupos", "Cupos", curso == null ? "20" : String.valueOf(curso.getCupos())));
    }

    @Override
    public void save(Integer id, Map<String, String> valores) {
        exigirAdministrador();
        String nombre = FormularioUtil.valor(valores, "nombre");
        String entidad = FormularioUtil.valor(valores, "entidad");
        String descripcion = FormularioUtil.valor(valores, "descripcion");
        LocalDate inicio = FormularioUtil.fecha(valores, "inicio", "fecha de inicio");
        LocalDate fin = FormularioUtil.fecha(valores, "fin", "fecha de finalización");
        int cupos = FormularioUtil.entero(valores, "cupos", "cupos");
        validar(nombre, inicio, fin, cupos, id == null ? 0 : buscar(id).getParticipanteIds().size());

        if (id == null) {
            datos.capacitaciones.add(new Capacitacion(siguienteId(), nombre, entidad,
                    descripcion, inicio, fin, cupos));
        } else {
            Capacitacion curso = buscar(id);
            curso.setNombre(nombre);
            curso.setEntidad(entidad);
            curso.setDescripcion(descripcion);
            curso.setFechaInicio(inicio);
            curso.setFechaFin(fin);
            curso.setCupos(cupos);
        }
        datos.guardar();
    }

    @Override
    public void delete(int id) {
        exigirAdministrador();
        Capacitacion curso = buscar(id);
        if (!curso.getParticipanteIds().isEmpty()) {
            throw new IllegalArgumentException("No se puede eliminar: primero retira las inscripciones del curso.");
        }
        datos.capacitaciones.remove(curso);
        datos.guardar();
    }

    @Override
    public boolean canCreate() {
        return datos.esAdministrador();
    }

    @Override
    public boolean canEdit() {
        return datos.esAdministrador();
    }

    @Override
    public boolean canDelete() {
        return datos.esAdministrador();
    }

    @Override
    public String actionLabel() {
        return "Inscribirme / retirar";
    }

    @Override
    public boolean canRunAction() {
        return datos.esTrabajador();
    }

    @Override
    public void runAction(int id) {
        if (!(datos.getUsuarioActual() instanceof Trabajador)) {
            throw new SecurityException("Solo los trabajadores pueden gestionar sus inscripciones.");
        }
        Trabajador trabajador = (Trabajador) datos.getUsuarioActual();
        Capacitacion curso = buscar(id);
        Set<Integer> participantes = new LinkedHashSet<>(curso.getParticipanteIds());
        if (participantes.remove(trabajador.getId())) {
            curso.setParticipanteIds(participantes);
            datos.guardar();
            return;
        }
        if (participantes.size() >= curso.getCupos()) {
            throw new IllegalArgumentException("No quedan cupos disponibles.");
        }
        participantes.add(trabajador.getId());
        curso.setParticipanteIds(participantes);
        datos.guardar();
    }

    @Override
    public boolean canShowDetails() {
        return true;
    }

    @Override
    public String details(int id) {
        Capacitacion curso = buscar(id);
        return curso.getNombre() + "\nEntidad: " + curso.getEntidad()
                + "\nFechas: " + curso.getFechaInicio() + " a " + curso.getFechaFin()
                + "\nCupos: " + curso.getParticipanteIds().size() + " de " + curso.getCupos()
                + "\n\n" + curso.getDescripcion();
    }

    @Override
    public String searchableText(int id) {
        Capacitacion curso = buscar(id);
        return curso.getNombre() + " " + curso.getEntidad() + " " + curso.getDescripcion();
    }

    private Capacitacion buscar(int id) {
        return datos.capacitaciones.stream().filter(c -> c.getId() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("La capacitación ya no existe."));
    }

    private int siguienteId() {
        return datos.capacitaciones.stream().mapToInt(Capacitacion::getId).max().orElse(0) + 1;
    }

    private void validar(String nombre, LocalDate inicio, LocalDate fin, int cupos, int inscritos) {
        Validaciones.requerido(nombre, "nombre del curso");
        if (cupos < 1) throw new IllegalArgumentException("Los cupos deben ser positivos.");
        if (cupos < inscritos) {
            throw new IllegalArgumentException("Los cupos no pueden quedar por debajo de las personas inscritas.");
        }
        if (fin.isBefore(inicio)) {
            throw new IllegalArgumentException("La fecha final no puede preceder la inicial.");
        }
    }

    private void exigirSesion() {
        if (datos.getUsuarioActual() == null) throw new SecurityException("Inicia sesión para continuar.");
    }

    private void exigirAdministrador() {
        if (!datos.esAdministrador()) {
            throw new SecurityException("Esta operación requiere permisos de administrador.");
        }
    }
}
