package controlador;

import modelo.DatosAplicacion;
import modelo.Empresa;
import modelo.EstadoOferta;
import modelo.OfertaLaboral;
import modelo.Postulacion;
import modelo.Trabajador;
import utilidades.FormularioUtil;
import utilidades.Validaciones;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Publica vacantes, aplica permisos por empresa y permite postular al trabajador. */
public final class OfertasController implements TableController {
    private final DatosAplicacion datos;

    public OfertasController(DatosAplicacion datos) {
        this.datos = datos;
    }

    @Override
    public String title() {
        return "Ofertas laborales";
    }

    @Override
    public List<String> columns() {
        List<String> columnas = new ArrayList<>(List.of("ID", "Cargo", "Empresa", "Vacantes",
                "Ubicación", "Contrato", "Salario", "Fecha límite", "Estado"));
        if (datos.esTrabajador()) columnas.add("Coincidencia");
        return columnas;
    }

    @Override
    public List<Object[]> rows() {
        exigirSesion();
        List<OfertaLaboral> ofertas = ofertasVisibles();
        if (datos.esTrabajador()) {
            Trabajador trabajador = (Trabajador) datos.getUsuarioActual();
            ofertas.sort(Comparator.comparingInt((OfertaLaboral oferta) ->
                    compatibilidad(oferta, trabajador)).reversed());
        }

        List<Object[]> filas = new ArrayList<>();
        for (OfertaLaboral oferta : ofertas) {
            Object[] fila = {oferta.getId(), oferta.getCargo(), nombreEmpresa(oferta.getEmpresaId()),
                oferta.getVacantes(), oferta.getUbicacion(), oferta.getTipoContrato(),
                oferta.getSalario() > 0
                        ? String.format(Locale.forLanguageTag("es-CO"), "$%,.0f", oferta.getSalario())
                        : "A convenir",
                oferta.getFechaLimite(), oferta.getEstado()};
            if (datos.esTrabajador()) {
                Object[] conCompatibilidad = java.util.Arrays.copyOf(fila, fila.length + 1);
                conCompatibilidad[fila.length] = compatibilidad(oferta,
                        (Trabajador) datos.getUsuarioActual()) + "%";
                fila = conCompatibilidad;
            }
            filas.add(fila);
        }
        return filas;
    }

    @Override
    public List<FormField> fields(Integer id) {
        OfertaLaboral oferta = id == null ? null : buscarVisible(id);
        if (id == null && !canCreate()) {
            throw new SecurityException("No tienes permiso para publicar ofertas.");
        }
        List<FormField> campos = new ArrayList<>();
        if (datos.esAdministrador() && oferta == null) {
            List<String> empresas = new ArrayList<>();
            for (Empresa empresa : datos.empresas) {
                empresas.add(empresa.getId() + " - " + empresa.getNombre());
            }
            if (empresas.isEmpty()) {
                throw new IllegalArgumentException("Registra una empresa antes de crear una oferta.");
            }
            campos.add(FormField.choice("empresa", "Empresa", empresas.get(0), empresas));
        }
        campos.add(FormField.text("cargo", "Cargo", oferta == null ? "" : oferta.getCargo()));
        campos.add(FormField.area("descripcion", "Descripción", oferta == null ? "" : oferta.getDescripcion()));
        campos.add(FormField.area("requisitos", "Requisitos", oferta == null ? "" : oferta.getRequisitos()));
        campos.add(FormField.text("habilidades", "Habilidades (separadas por coma)",
                oferta == null ? "" : FormularioUtil.unirLista(oferta.getHabilidades())));
        campos.add(FormField.text("vacantes", "Vacantes", oferta == null ? "1" : String.valueOf(oferta.getVacantes())));
        campos.add(FormField.text("ubicacion", "Ubicación", oferta == null ? "Cartagena" : oferta.getUbicacion()));
        campos.add(FormField.choice("contrato", "Tipo de contrato",
                oferta == null ? "Término fijo" : oferta.getTipoContrato(),
                List.of("Término fijo", "Indefinido", "Obra o labor", "Aprendizaje", "Prestación de servicios")));
        campos.add(FormField.text("salario", "Salario mensual (COP, opcional)",
                oferta == null || oferta.getSalario() == 0 ? "" : String.valueOf(oferta.getSalario())));
        campos.add(FormField.text("publicacion", "Fecha de publicación (AAAA-MM-DD)",
                oferta == null ? LocalDate.now().toString() : oferta.getFechaPublicacion().toString()));
        campos.add(FormField.text("limite", "Fecha límite (AAAA-MM-DD)",
                oferta == null ? LocalDate.now().plusDays(30).toString() : oferta.getFechaLimite().toString()));
        campos.add(FormField.choice("estado", "Estado",
                oferta == null ? EstadoOferta.ACTIVA.name() : oferta.getEstado().name(),
                List.of("ACTIVA", "PAUSADA", "CERRADA")));
        return campos;
    }

    @Override
    public void save(Integer id, Map<String, String> valores) {
        if (!datos.esAdministrador() && !datos.esEmpresa()) {
            throw new SecurityException("Solo las empresas y el administrador pueden gestionar ofertas.");
        }
        OfertaLaboral anterior = id == null ? null : buscarVisible(id);
        int empresaId = anterior == null ? empresaIdSeleccionada(valores) : anterior.getEmpresaId();
        if (datos.esEmpresa()) empresaId = datos.getUsuarioActual().getId();
        validarEmpresa(empresaId);

        String cargo = FormularioUtil.valor(valores, "cargo");
        String descripcion = FormularioUtil.valor(valores, "descripcion");
        String requisitos = FormularioUtil.valor(valores, "requisitos");
        List<String> habilidades = FormularioUtil.separarLista(valores.get("habilidades"));
        int vacantes = FormularioUtil.entero(valores, "vacantes", "vacantes");
        String ubicacion = FormularioUtil.valor(valores, "ubicacion");
        String contrato = FormularioUtil.valor(valores, "contrato");
        double salario = FormularioUtil.decimal(valores, "salario", "salario");
        LocalDate publicacion = FormularioUtil.fecha(valores, "publicacion", "fecha de publicación");
        LocalDate limite = FormularioUtil.fecha(valores, "limite", "fecha límite");
        EstadoOferta estado;
        try {
            estado = EstadoOferta.valueOf(FormularioUtil.valor(valores, "estado"));
        } catch (RuntimeException ex) {
            throw new IllegalArgumentException("Selecciona un estado válido.");
        }
        validar(cargo, descripcion, vacantes, salario, publicacion, limite);

        if (anterior == null) {
            datos.ofertas.add(new OfertaLaboral(siguienteId(), empresaId, cargo, descripcion,
                    requisitos, habilidades, vacantes, ubicacion, contrato, salario,
                    publicacion, limite, estado));
        } else {
            anterior.setCargo(cargo);
            anterior.setDescripcion(descripcion);
            anterior.setRequisitos(requisitos);
            anterior.setHabilidades(habilidades);
            anterior.setVacantes(vacantes);
            anterior.setUbicacion(ubicacion);
            anterior.setTipoContrato(contrato);
            anterior.setSalario(salario);
            anterior.setFechaPublicacion(publicacion);
            anterior.setFechaLimite(limite);
            anterior.setEstado(estado);
        }
        datos.guardar();
    }

    @Override
    public void delete(int id) {
        OfertaLaboral oferta = buscarVisible(id);
        exigirPuedeGestionar(oferta);
        boolean tienePostulaciones = datos.postulaciones.stream()
                .anyMatch(postulacion -> postulacion.getOfertaId() == id);
        if (tienePostulaciones) {
            throw new IllegalArgumentException("No se puede eliminar: la oferta tiene postulaciones relacionadas.");
        }
        datos.ofertas.remove(oferta);
        datos.guardar();
    }

    @Override
    public boolean canCreate() {
        return datos.esAdministrador() || datos.esEmpresa();
    }

    @Override
    public boolean canEdit() {
        return canCreate();
    }

    @Override
    public boolean canDelete() {
        return canCreate();
    }

    @Override
    public String actionLabel() {
        return "Postularme";
    }

    @Override
    public boolean canRunAction() {
        return datos.esTrabajador();
    }

    @Override
    public void runAction(int id) {
        new PostulacionesController(datos).postular(id);
    }

    @Override
    public boolean canShowDetails() {
        return true;
    }

    @Override
    public String details(int id) {
        OfertaLaboral oferta = buscarVisible(id);
        String compatibilidad = "";
        if (datos.esTrabajador()) {
            compatibilidad = "\nCoincidencia con tu perfil: "
                    + compatibilidad(oferta, (Trabajador) datos.getUsuarioActual()) + "%";
        }
        String salario = oferta.getSalario() > 0
                ? String.format(Locale.forLanguageTag("es-CO"), "$%,.0f COP", oferta.getSalario())
                : "No especificado";
        return "Cargo: " + oferta.getCargo()
                + "\nEmpresa: " + nombreEmpresa(oferta.getEmpresaId())
                + "\nUbicación: " + oferta.getUbicacion()
                + "\nContrato: " + oferta.getTipoContrato()
                + "\nSalario: " + salario
                + "\nVacantes: " + oferta.getVacantes()
                + "\nHabilidades: " + FormularioUtil.unirLista(oferta.getHabilidades())
                + "\nFecha límite: " + oferta.getFechaLimite() + compatibilidad
                + "\n\nDescripción\n" + oferta.getDescripcion()
                + "\n\nRequisitos\n" + oferta.getRequisitos();
    }

    @Override
    public String searchableText(int id) {
        OfertaLaboral oferta = buscarVisible(id);
        return oferta.getCargo() + " " + nombreEmpresa(oferta.getEmpresaId()) + " "
                + oferta.getDescripcion() + " " + oferta.getRequisitos() + " "
                + FormularioUtil.unirLista(oferta.getHabilidades()) + " "
                + oferta.getUbicacion() + " " + oferta.getEstado();
    }

    private List<OfertaLaboral> ofertasVisibles() {
        if (datos.esAdministrador()) return new ArrayList<>(datos.ofertas);
        if (datos.getUsuarioActual() instanceof Empresa) {
            int empresaId = datos.getUsuarioActual().getId();
            List<OfertaLaboral> propias = new ArrayList<>();
            for (OfertaLaboral oferta : datos.ofertas) {
                if (oferta.getEmpresaId() == empresaId) propias.add(oferta);
            }
            return propias;
        }
        if (datos.esTrabajador()) {
            List<OfertaLaboral> disponibles = new ArrayList<>();
            for (OfertaLaboral oferta : datos.ofertas) {
                if (oferta.estaDisponible()) disponibles.add(oferta);
            }
            return disponibles;
        }
        throw new SecurityException("Inicia sesión para consultar ofertas.");
    }

    private OfertaLaboral buscarVisible(int id) {
        for (OfertaLaboral oferta : ofertasVisibles()) {
            if (oferta.getId() == id) return oferta;
        }
        throw new SecurityException("No tienes permiso para consultar esa oferta.");
    }

    private String nombreEmpresa(int empresaId) {
        return datos.empresas.stream().filter(e -> e.getId() == empresaId)
                .map(Empresa::getNombre).findFirst().orElse("Empresa eliminada");
    }

    private int empresaIdSeleccionada(Map<String, String> valores) {
        if (datos.esEmpresa()) return datos.getUsuarioActual().getId();
        try {
            return Integer.parseInt(FormularioUtil.valor(valores, "empresa").split(" - ")[0]);
        } catch (RuntimeException ex) {
            throw new IllegalArgumentException("Selecciona una empresa.");
        }
    }

    private void validarEmpresa(int empresaId) {
        boolean existe = datos.empresas.stream().anyMatch(e -> e.getId() == empresaId);
        if (!existe) throw new IllegalArgumentException("Selecciona una empresa registrada.");
    }

    private void exigirPuedeGestionar(OfertaLaboral oferta) {
        if (datos.esAdministrador()) return;
        if (datos.getUsuarioActual() instanceof Empresa
                && oferta.getEmpresaId() == datos.getUsuarioActual().getId()) return;
        throw new SecurityException("Solo puedes gestionar las ofertas de tu empresa.");
    }

    private int siguienteId() {
        return datos.ofertas.stream().mapToInt(OfertaLaboral::getId).max().orElse(0) + 1;
    }

    private int compatibilidad(OfertaLaboral oferta, Trabajador trabajador) {
        if (oferta.getHabilidades().isEmpty()) return 0;
        long coincidencias = oferta.getHabilidades().stream().filter(requerida ->
                trabajador.getHabilidades().stream()
                        .anyMatch(habilidad -> habilidad.equalsIgnoreCase(requerida))).count();
        return (int) Math.round(coincidencias * 100.0 / oferta.getHabilidades().size());
    }

    private void validar(String cargo, String descripcion, int vacantes, double salario,
            LocalDate publicacion, LocalDate limite) {
        Validaciones.requerido(cargo, "cargo");
        Validaciones.requerido(descripcion, "descripción");
        if (vacantes < 1) throw new IllegalArgumentException("Las vacantes deben ser al menos una.");
        if (!Double.isFinite(salario) || salario < 0) {
            throw new IllegalArgumentException("El salario no puede ser negativo.");
        }
        if (limite.isBefore(publicacion)) {
            throw new IllegalArgumentException("La fecha límite no puede preceder la publicación.");
        }
    }

    private void exigirSesion() {
        if (datos.getUsuarioActual() == null) throw new SecurityException("Inicia sesión para continuar.");
    }
}
