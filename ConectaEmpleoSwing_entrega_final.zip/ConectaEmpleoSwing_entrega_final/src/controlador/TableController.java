package controlador;

import java.util.List;
import java.util.Map;

/** Acciones que la vista de tabla necesita de cada controlador de módulo. */
public interface TableController {
    String title();

    List<String> columns();

    List<Object[]> rows();

    List<FormField> fields(Integer id);

    void save(Integer id, Map<String, String> values);

    void delete(int id);

    default boolean canCreate() {
        return true;
    }

    default boolean canEdit() {
        return true;
    }

    default boolean canDelete() {
        return true;
    }

    default String actionLabel() {
        return null;
    }

    default boolean canRunAction() {
        return false;
    }

    default void runAction(int id) {
        throw new UnsupportedOperationException();
    }

    default boolean canShowDetails() {
        return false;
    }

    default String details(int id) {
        return "";
    }

    default String searchableText(int id) {
        return rows().stream()
                .filter(row -> ((Number) row[0]).intValue() == id)
                .findFirst()
                .map(java.util.Arrays::toString)
                .orElse("");
    }
}
