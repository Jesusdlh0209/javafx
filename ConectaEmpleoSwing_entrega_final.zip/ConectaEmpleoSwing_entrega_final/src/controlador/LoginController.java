package controlador;

import modelo.DatosAplicacion;
import modelo.Usuario;
import utilidades.PasswordUtil;
import java.util.ArrayList;
import java.util.List;

/** Comprueba las credenciales y mantiene la sesión actual. */
public final class LoginController {
    private final DatosAplicacion datos;

    public LoginController(DatosAplicacion datos) {
        this.datos = datos;
    }

    public boolean iniciar(String nombreUsuario, char[] contrasena) {
        String usuario = nombreUsuario == null ? "" : nombreUsuario.trim();
        for (Usuario candidato : todosLosUsuarios()) {
            if (candidato.getUsuario().equalsIgnoreCase(usuario)
                    && PasswordUtil.verify(contrasena, candidato.getPasswordHash())) {
                datos.setUsuarioActual(candidato);
                return true;
            }
        }
        return false;
    }

    public void cerrar() {
        datos.setUsuarioActual(null);
        datos.guardar();
    }

    public void cambiarContrasena(char[] actual, char[] nueva) {
        if (datos.getUsuarioActual() == null) {
            throw new SecurityException("Inicia sesión para continuar.");
        }
        if (nueva == null || nueva.length < 8) {
            throw new IllegalArgumentException("La nueva contraseña debe tener al menos 8 caracteres.");
        }
        Usuario usuario = datos.getUsuarioActual();
        if (!PasswordUtil.verify(actual, usuario.getPasswordHash())) {
            throw new IllegalArgumentException("La contraseña actual no coincide.");
        }
        usuario.setPasswordHash(PasswordUtil.hash(nueva));
        datos.guardar();
    }

    private List<Usuario> todosLosUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        usuarios.addAll(datos.administradores);
        usuarios.addAll(datos.empresas);
        usuarios.addAll(datos.trabajadores);
        return usuarios;
    }
}
