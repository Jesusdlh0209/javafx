package controlador;

import modelo.DatosAplicacion;
import modelo.Documento;
import modelo.Empresa;
import modelo.OfertaLaboral;
import modelo.Postulacion;
import modelo.Trabajador;
import utilidades.PdfUtil;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Gestiona las hojas de vida y comprueba los permisos antes de abrir cada archivo. */
public final class DocumentosController {
    private final DatosAplicacion datos;

    public DocumentosController(DatosAplicacion datos) {
        this.datos = datos;
    }

    public List<String> trabajadores() {
        exigirSesion();
        List<String> opciones = new ArrayList<>();
        for (Trabajador trabajador : datos.trabajadores) {
            opciones.add(trabajador.getId() + " - " + trabajador.getNombre());
        }
        return opciones;
    }

    public List<Object[]> rows() {
        exigirSesion();
        List<Object[]> filas = new ArrayList<>();
        for (Documento documento : documentosVisibles()) {
            Trabajador trabajador = buscarTrabajador(documento.getTrabajadorId());
            filas.add(new Object[]{documento.getId(),
                trabajador == null ? "—" : trabajador.getNombre(),
                documento.getNombre(),
                String.format(Locale.forLanguageTag("es-CO"), "%.1f KB", documento.getBytes() / 1024.0),
                documento.getAgregado()});
        }
        return filas;
    }

    public String inspect(Path archivo) throws IOException {
        return PdfUtil.inspeccionar(archivo);
    }

    public void importPdf(int trabajadorId, Path archivo, boolean reemplazar) throws IOException {
        Trabajador trabajador = buscarTrabajador(trabajadorId);
        exigirPuedeModificar(trabajador);
        PdfUtil.inspeccionar(archivo);
        String rutaAnterior = trabajador.getRutaHojaVida();
        String rutaNueva = PdfUtil.copiar(datos, archivo, trabajadorId);
        Documento documento = new Documento(siguienteId(), trabajadorId,
                archivo.getFileName().toString(), rutaNueva, Files.size(archivo), LocalDateTime.now());
        List<Documento> documentosAnteriores = new ArrayList<>(datos.documentos);
        if (reemplazar && rutaAnterior != null && !rutaAnterior.isBlank()) {
            datos.documentos.removeIf(d -> d.getTrabajadorId() == trabajadorId
                    && d.getRutaRelativa().equals(rutaAnterior));
        }
        datos.documentos.add(documento);
        trabajador.setRutaHojaVida(rutaNueva);
        try {
            datos.guardar();
        } catch (RuntimeException ex) {
            datos.documentos.clear();
            datos.documentos.addAll(documentosAnteriores);
            trabajador.setRutaHojaVida(rutaAnterior);
            PdfUtil.eliminar(datos, rutaNueva);
            throw ex;
        }
        if (reemplazar && rutaAnterior != null && !rutaAnterior.isBlank()
                && !rutaAnterior.equals(rutaNueva)) {
            PdfUtil.eliminar(datos, rutaAnterior);
        }
    }

    public void open(int id) throws IOException {
        Documento documento = buscarVisible(id);
        if (!puedeVer(documento)) {
            throw new SecurityException("No tienes permiso para abrir esta hoja de vida.");
        }
        PdfUtil.abrir(datos, documento.getRutaRelativa());
    }

    public void delete(int id) throws IOException {
        Documento documento = buscarVisible(id);
        Trabajador trabajador = buscarTrabajador(documento.getTrabajadorId());
        if (trabajador == null) throw new IOException("El trabajador asociado ya no existe.");
        exigirPuedeModificar(trabajador);
        PdfUtil.eliminar(datos, documento.getRutaRelativa());
        datos.documentos.remove(documento);
        if (documento.getRutaRelativa().equals(trabajador.getRutaHojaVida())) {
            trabajador.setRutaHojaVida("");
        }
        datos.guardar();
    }

    public boolean isAdmin() {
        return datos.esAdministrador();
    }

    public boolean canModify() {
        return datos.esAdministrador() || datos.esTrabajador();
    }

    public int currentWorkerId() {
        return datos.getUsuarioActual() instanceof Trabajador
                ? datos.getUsuarioActual().getId() : -1;
    }

    public boolean hasCv(int trabajadorId) {
        Trabajador trabajador = buscarTrabajador(trabajadorId);
        return trabajador != null && !trabajador.getRutaHojaVida().isBlank();
    }

    private List<Documento> documentosVisibles() {
        if (datos.esAdministrador()) return datos.documentos;
        if (datos.getUsuarioActual() instanceof Trabajador) {
            int trabajadorId = datos.getUsuarioActual().getId();
            List<Documento> propios = new ArrayList<>();
            for (Documento documento : datos.documentos) {
                if (documento.getTrabajadorId() == trabajadorId) propios.add(documento);
            }
            return propios;
        }
        if (datos.getUsuarioActual() instanceof Empresa) {
            int empresaId = datos.getUsuarioActual().getId();
            Set<Integer> ofertas = new HashSet<>();
            for (OfertaLaboral oferta : datos.ofertas) {
                if (oferta.getEmpresaId() == empresaId) ofertas.add(oferta.getId());
            }
            Set<Integer> candidatos = new HashSet<>();
            for (Postulacion postulacion : datos.postulaciones) {
                if (ofertas.contains(postulacion.getOfertaId())) {
                    candidatos.add(postulacion.getTrabajadorId());
                }
            }
            List<Documento> visibles = new ArrayList<>();
            for (Documento documento : datos.documentos) {
                if (candidatos.contains(documento.getTrabajadorId())) visibles.add(documento);
            }
            return visibles;
        }
        throw new SecurityException("Inicia sesión para consultar documentos.");
    }

    private Documento buscarVisible(int id) {
        return documentosVisibles().stream().filter(d -> d.getId() == id).findFirst()
                .orElseThrow(() -> new SecurityException("No tienes permiso para consultar ese documento."));
    }

    private boolean puedeVer(Documento documento) {
        if (datos.esAdministrador()) return true;
        if (datos.getUsuarioActual() instanceof Trabajador) {
            return documento.getTrabajadorId() == datos.getUsuarioActual().getId();
        }
        if (datos.getUsuarioActual() instanceof Empresa) {
            int empresaId = datos.getUsuarioActual().getId();
            for (Postulacion postulacion : datos.postulaciones) {
                if (postulacion.getTrabajadorId() != documento.getTrabajadorId()) continue;
                OfertaLaboral oferta = buscarOferta(postulacion.getOfertaId());
                if (oferta != null && oferta.getEmpresaId() == empresaId) return true;
            }
        }
        return false;
    }

    private void exigirPuedeModificar(Trabajador trabajador) {
        if (datos.esAdministrador()) return;
        if (datos.getUsuarioActual() instanceof Trabajador
                && datos.getUsuarioActual().getId() == trabajador.getId()) return;
        throw new SecurityException("No puedes gestionar documentos de otra persona.");
    }

    private Trabajador buscarTrabajador(int id) {
        return datos.trabajadores.stream().filter(t -> t.getId() == id).findFirst().orElse(null);
    }

    private OfertaLaboral buscarOferta(int id) {
        return datos.ofertas.stream().filter(o -> o.getId() == id).findFirst().orElse(null);
    }

    private int siguienteId() {
        return datos.documentos.stream().mapToInt(Documento::getId).max().orElse(0) + 1;
    }

    private void exigirSesion() {
        if (datos.getUsuarioActual() == null) throw new SecurityException("Inicia sesión para continuar.");
    }
}
