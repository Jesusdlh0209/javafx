package controlador;

import modelo.DatosAplicacion;
import modelo.Empresa;
import modelo.OfertaLaboral;
import utilidades.FormularioUtil;
import utilidades.PasswordUtil;
import utilidades.Validaciones;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** CRUD de empresas. Una empresa solo puede modificar su propio perfil. */
public final class EmpresasController implements TableController {
    private final DatosAplicacion datos;

    public EmpresasController(DatosAplicacion datos) {
        this.datos = datos;
    }

    @Override
    public String title() {
        return datos.esAdministrador() ? "Gestión de empresas" : "Perfil empresarial";
    }

    @Override
    public List<String> columns() {
        return List.of("ID", "Empresa", "NIT", "Sector", "Correo", "Teléfono", "Dirección", "Ofertas");
    }

    @Override
    public List<Object[]> rows() {
        List<Object[]> filas = new ArrayList<>();
        for (Empresa empresa : empresasVisibles()) {
            long ofertas = datos.ofertas.stream()
                    .filter(oferta -> oferta.getEmpresaId() == empresa.getId()).count();
            filas.add(new Object[]{empresa.getId(), empresa.getNombre(), empresa.getNit(),
                empresa.getSector(), empresa.getCorreo(), empresa.getTelefono(),
                empresa.getDireccion(), ofertas});
        }
        return filas;
    }

    @Override
    public List<FormField> fields(Integer id) {
        Empresa empresa = id == null ? null : buscarVisible(id);
        if (id == null && !datos.esAdministrador()) {
            throw new SecurityException("Solo el administrador puede registrar empresas.");
        }
        List<FormField> campos = new ArrayList<>();
        campos.add(FormField.text("nombre", "Nombre comercial",
                empresa == null ? "" : empresa.getNombre()));
        campos.add(FormField.text("nit", "NIT", empresa == null ? "" : empresa.getNit()));
        campos.add(FormField.text("sector", "Sector", empresa == null ? "" : empresa.getSector()));
        campos.add(FormField.text("correo", "Correo", empresa == null ? "" : empresa.getCorreo()));
        campos.add(FormField.text("telefono", "Teléfono", empresa == null ? "" : empresa.getTelefono()));
        campos.add(FormField.text("direccion", "Dirección",
                empresa == null ? "Cartagena" : empresa.getDireccion()));
        if (empresa == null) {
            campos.add(FormField.text("usuario", "Usuario", ""));
            campos.add(FormField.text("password", "Contraseña (mínimo 8 caracteres)", ""));
        } else if (datos.esAdministrador()) {
            campos.add(FormField.text("password", "Nueva contraseña (opcional)", ""));
        }
        return campos;
    }

    @Override
    public void save(Integer id, Map<String, String> valores) {
        if (id == null) {
            crear(valores);
        } else {
            actualizar(id, valores);
        }
    }

    private void crear(Map<String, String> valores) {
        exigirAdministrador();
        String usuario = FormularioUtil.valor(valores, "usuario");
        String contrasena = FormularioUtil.valor(valores, "password");
        Validaciones.requerido(usuario, "usuario");
        validarUsuarioUnico(usuario, null);
        validarContrasena(contrasena);

        Empresa empresa = new Empresa(siguienteId(), FormularioUtil.valor(valores, "nombre"),
                usuario, FormularioUtil.valor(valores, "correo"),
                FormularioUtil.valor(valores, "telefono"), PasswordUtil.hash(contrasena.toCharArray()),
                FormularioUtil.valor(valores, "nit"), FormularioUtil.valor(valores, "sector"),
                FormularioUtil.valor(valores, "direccion"));
        validarDatos(empresa, null);
        datos.empresas.add(empresa);
        datos.guardar();
    }

    private void actualizar(int id, Map<String, String> valores) {
        Empresa empresa = buscarVisible(id);
        if (!datos.esAdministrador() && datos.getUsuarioActual() != empresa) {
            throw new SecurityException("Solo puedes editar el perfil de tu empresa.");
        }

        String nombre = FormularioUtil.valor(valores, "nombre");
        String nit = FormularioUtil.valor(valores, "nit");
        String sector = FormularioUtil.valor(valores, "sector");
        String correo = FormularioUtil.valor(valores, "correo");
        String telefono = FormularioUtil.valor(valores, "telefono");
        String direccion = FormularioUtil.valor(valores, "direccion");
        Validaciones.requerido(nombre, "nombre comercial");
        Validaciones.nit(nit);
        Validaciones.correo(correo);
        Validaciones.telefono(telefono);
        validarNitUnico(nit, id);

        String contrasena = FormularioUtil.valor(valores, "password");
        if (!contrasena.isBlank()) {
            if (!datos.esAdministrador()) {
                throw new SecurityException("Cambia tu contraseña desde el menú de cuenta.");
            }
            validarContrasena(contrasena);
            empresa.setPasswordHash(PasswordUtil.hash(contrasena.toCharArray()));
        }
        empresa.setNombre(nombre);
        empresa.setNit(nit);
        empresa.setSector(sector);
        empresa.setCorreo(correo);
        empresa.setTelefono(telefono);
        empresa.setDireccion(direccion);
        datos.guardar();
    }

    @Override
    public void delete(int id) {
        exigirAdministrador();
        Empresa empresa = buscar(id);
        boolean tieneOfertas = datos.ofertas.stream()
                .anyMatch(oferta -> oferta.getEmpresaId() == id);
        if (tieneOfertas) {
            throw new IllegalArgumentException("No se puede eliminar: la empresa tiene ofertas relacionadas.");
        }
        datos.empresas.remove(empresa);
        datos.guardar();
    }

    @Override
    public boolean canCreate() {
        return datos.esAdministrador();
    }

    @Override
    public boolean canEdit() {
        return datos.esAdministrador() || datos.esEmpresa();
    }

    @Override
    public boolean canDelete() {
        return datos.esAdministrador();
    }

    private List<Empresa> empresasVisibles() {
        if (datos.esAdministrador()) return datos.empresas;
        if (datos.getUsuarioActual() instanceof Empresa) {
            return List.of((Empresa) datos.getUsuarioActual());
        }
        throw new SecurityException("No tienes permiso para consultar empresas.");
    }

    private Empresa buscarVisible(int id) {
        for (Empresa empresa : empresasVisibles()) {
            if (empresa.getId() == id) return empresa;
        }
        throw new SecurityException("No tienes permiso para editar esa empresa.");
    }

    private Empresa buscar(int id) {
        return datos.empresas.stream().filter(e -> e.getId() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("La empresa ya no existe."));
    }

    private void validarDatos(Empresa empresa, Integer excluirId) {
        Validaciones.requerido(empresa.getNombre(), "nombre comercial");
        Validaciones.nit(empresa.getNit());
        Validaciones.correo(empresa.getCorreo());
        Validaciones.telefono(empresa.getTelefono());
        validarNitUnico(empresa.getNit(), excluirId);
    }

    private void validarNitUnico(String nit, Integer excluirId) {
        boolean repetido = datos.empresas.stream()
                .anyMatch(otra -> (excluirId == null || otra.getId() != excluirId)
                        && otra.getNit().equalsIgnoreCase(nit));
        if (repetido) throw new IllegalArgumentException("El NIT ya está registrado.");
    }

    private void validarUsuarioUnico(String usuario, Integer excluirId) {
        boolean repetido = datos.administradores.stream().anyMatch(u -> u.getUsuario().equalsIgnoreCase(usuario))
                || datos.empresas.stream().anyMatch(u -> (excluirId == null || u.getId() != excluirId)
                        && u.getUsuario().equalsIgnoreCase(usuario))
                || datos.trabajadores.stream().anyMatch(u -> u.getUsuario().equalsIgnoreCase(usuario));
        if (repetido) throw new IllegalArgumentException("El nombre de usuario ya está registrado.");
    }

    private int siguienteId() {
        return datos.empresas.stream().mapToInt(Empresa::getId).max().orElse(0) + 1;
    }

    private void validarContrasena(String contrasena) {
        if (contrasena.length() < 8) {
            throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres.");
        }
    }

    private void exigirAdministrador() {
        if (!datos.esAdministrador()) {
            throw new SecurityException("Esta operación requiere permisos de administrador.");
        }
    }
}
