package controlador;

import modelo.DatosAplicacion;
import modelo.EstadoOferta;
import modelo.Empresa;
import modelo.EstadoPostulacion;
import modelo.OfertaLaboral;
import modelo.Postulacion;
import modelo.Trabajador;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Calcula las estadísticas del inicio a partir de las listas guardadas. */
public final class DashboardController {
    private final DatosAplicacion datos;

    public DashboardController(DatosAplicacion datos) {
        this.datos = datos;
    }

    public Map<String, Integer> metricas() {
        Map<String, Integer> resultados = new LinkedHashMap<>();
        if (datos.esAdministrador()) {
            resultados.put("Trabajadores", datos.trabajadores.size());
            resultados.put("Empresas", datos.empresas.size());
            resultados.put("Ofertas", datos.ofertas.size());
            resultados.put("Postulaciones", datos.postulaciones.size());
            resultados.put("Ofertas activas", contarOfertasActivas());
            resultados.put("Postulaciones pendientes", contarPostulacionesPendientes());
        } else if (datos.esEmpresa()) {
            int empresaId = datos.getUsuarioActual().getId();
            Set<Integer> ofertasEmpresa = datos.ofertas.stream()
                    .filter(oferta -> oferta.getEmpresaId() == empresaId)
                    .map(OfertaLaboral::getId).collect(java.util.stream.Collectors.toSet());
            int postulacionesEmpresa = 0;
            int pendientesEmpresa = 0;
            for (Postulacion postulacion : datos.postulaciones) {
                if (!ofertasEmpresa.contains(postulacion.getOfertaId())) continue;
                postulacionesEmpresa++;
                if (postulacion.getEstado() == EstadoPostulacion.PENDIENTE) pendientesEmpresa++;
            }
            resultados.put("Trabajadores", (int) new TrabajadoresController(datos).rows().size());
            resultados.put("Empresas", 1);
            resultados.put("Ofertas", ofertasEmpresa.size());
            resultados.put("Postulaciones", postulacionesEmpresa);
            resultados.put("Ofertas activas", (int) datos.ofertas.stream()
                    .filter(oferta -> ofertasEmpresa.contains(oferta.getId()) && oferta.estaDisponible()).count());
            resultados.put("Postulaciones pendientes", pendientesEmpresa);
        } else if (datos.esTrabajador()) {
            int trabajadorId = datos.getUsuarioActual().getId();
            int propias = 0;
            int pendientes = 0;
            for (Postulacion postulacion : datos.postulaciones) {
                if (postulacion.getTrabajadorId() != trabajadorId) continue;
                propias++;
                if (postulacion.getEstado() == EstadoPostulacion.PENDIENTE) pendientes++;
            }
            resultados.put("Trabajadores", 1);
            resultados.put("Empresas", 0);
            resultados.put("Ofertas", datos.ofertas.size());
            resultados.put("Postulaciones", propias);
            resultados.put("Ofertas activas", contarOfertasActivas());
            resultados.put("Postulaciones pendientes", pendientes);
        } else {
            resultados.put("Trabajadores", 0);
            resultados.put("Empresas", 0);
            resultados.put("Ofertas", 0);
            resultados.put("Postulaciones", 0);
            resultados.put("Ofertas activas", 0);
            resultados.put("Postulaciones pendientes", 0);
        }
        resultados.put("Capacitaciones", datos.capacitaciones.size());
        return resultados;
    }

    public void validarAccesoEstadisticas() {
        exigirAdministrador();
    }

    public Map<String, Integer> estadosOfertas() {
        exigirAdministrador();
        Map<String, Integer> conteos = new LinkedHashMap<>();
        conteos.put("Activas", 0);
        conteos.put("En pausa", 0);
        conteos.put("Cerradas", 0);
        for (OfertaLaboral oferta : datos.ofertas) {
            String etiqueta = switch (oferta.getEstado()) {
                case ACTIVA -> "Activas";
                case PAUSADA -> "En pausa";
                case CERRADA -> "Cerradas";
            };
            conteos.merge(etiqueta, 1, Integer::sum);
        }
        return conteos;
    }

    public Map<String, Integer> estadosPostulaciones() {
        exigirAdministrador();
        Map<String, Integer> conteos = new LinkedHashMap<>();
        for (EstadoPostulacion estado : EstadoPostulacion.values()) {
            conteos.put(etiqueta(estado), 0);
        }
        for (Postulacion postulacion : datos.postulaciones) {
            conteos.merge(etiqueta(postulacion.getEstado()), 1, Integer::sum);
        }
        return conteos;
    }

    public java.util.List<Trabajador> trabajadoresRecientes(int limite) {
        exigirAdministrador();
        return datos.trabajadores.stream()
                .sorted(Comparator.comparingInt(Trabajador::getId).reversed())
                .limit(Math.max(0, limite)).toList();
    }

    public java.util.List<OfertaLaboral> ofertasRecientes(int limite) {
        exigirAdministrador();
        return datos.ofertas.stream()
                .sorted(Comparator.comparing(OfertaLaboral::getFechaPublicacion,
                        Comparator.nullsLast(Comparator.reverseOrder()))
                        .thenComparing(Comparator.comparingInt(OfertaLaboral::getId).reversed()))
                .limit(Math.max(0, limite)).toList();
    }

    public java.util.List<Postulacion> postulacionesRecientes(int limite) {
        exigirAdministrador();
        return datos.postulaciones.stream()
                .sorted(Comparator.comparing(Postulacion::getFecha,
                        Comparator.nullsLast(Comparator.reverseOrder()))
                        .thenComparing(Comparator.comparingInt(Postulacion::getId).reversed()))
                .limit(Math.max(0, limite)).toList();
    }

    private String etiqueta(EstadoPostulacion estado) {
        return switch (estado) {
            case PENDIENTE -> "Pendientes";
            case EN_REVISION -> "En revisión";
            case ENTREVISTA -> "Entrevista";
            case SELECCIONADA -> "Seleccionadas";
            case RECHAZADA -> "Rechazadas";
        };
    }

    public Map<String, Integer> sectores() {
        exigirAdministrador();
        Map<String, Integer> resultados = new LinkedHashMap<>();
        for (Empresa empresa : datos.empresas) {
            resultados.merge(empresa.getSector(), 1, Integer::sum);
        }
        return resultados;
    }

    public int ofertasDeEmpresa() {
        if (!(datos.getUsuarioActual() instanceof Empresa)) return contarOfertasActivas();
        int empresaId = datos.getUsuarioActual().getId();
        return (int) datos.ofertas.stream().filter(o -> o.getEmpresaId() == empresaId).count();
    }

    public int postulacionesVisibles() {
        return new PostulacionesController(datos).rows().size();
    }

    public String[] meses() {
        String[] nombres = new String[6];
        for (int i = 0; i < nombres.length; i++) {
            nombres[i] = YearMonth.now().minusMonths(nombres.length - 1 - i)
                    .getMonth().getDisplayName(TextStyle.SHORT, Locale.forLanguageTag("es-CO"));
        }
        return nombres;
    }

    public int[] ofertasPorMes() {
        int[] cantidades = new int[6];
        Integer empresaId = datos.getUsuarioActual() instanceof Empresa
                ? datos.getUsuarioActual().getId() : null;
        for (OfertaLaboral oferta : datos.ofertas) {
            if (empresaId != null && oferta.getEmpresaId() != empresaId) continue;
            if (oferta.getFechaPublicacion() == null) continue;
            int indice = indiceMes(YearMonth.from(oferta.getFechaPublicacion()));
            if (indice >= 0) cantidades[indice]++;
        }
        return cantidades;
    }

    public int[] postulacionesPorMes() {
        int[] cantidades = new int[6];
        Set<Integer> ofertasDeEmpresa = new HashSet<>();
        if (datos.getUsuarioActual() instanceof Empresa) {
            int empresaId = datos.getUsuarioActual().getId();
            for (OfertaLaboral oferta : datos.ofertas) {
                if (oferta.getEmpresaId() == empresaId) ofertasDeEmpresa.add(oferta.getId());
            }
        }
        Integer trabajadorId = datos.getUsuarioActual() instanceof Trabajador
                ? datos.getUsuarioActual().getId() : null;
        for (Postulacion postulacion : datos.postulaciones) {
            if (trabajadorId != null && postulacion.getTrabajadorId() != trabajadorId) continue;
            if (datos.esEmpresa() && !ofertasDeEmpresa.contains(postulacion.getOfertaId())) continue;
            int indice = indiceMes(YearMonth.from(postulacion.getFecha()));
            if (indice >= 0) cantidades[indice]++;
        }
        return cantidades;
    }

    private int contarOfertasActivas() {
        return (int) datos.ofertas.stream().filter(OfertaLaboral::estaDisponible).count();
    }

    private int contarPostulacionesPendientes() {
        return (int) datos.postulaciones.stream()
                .filter(p -> p.getEstado() == EstadoPostulacion.PENDIENTE).count();
    }

    private int indiceMes(YearMonth mes) {
        YearMonth primero = YearMonth.now().minusMonths(5);
        long distancia = java.time.temporal.ChronoUnit.MONTHS.between(primero, mes);
        return distancia >= 0 && distancia < 6 ? (int) distancia : -1;
    }

    private void exigirAdministrador() {
        if (!datos.esAdministrador()) {
            throw new SecurityException("Esta operación requiere permisos de administrador.");
        }
    }
}
