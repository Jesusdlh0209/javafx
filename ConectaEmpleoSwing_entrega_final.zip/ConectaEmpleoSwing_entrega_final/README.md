# ConectaEmpleo Swing

Aplicación de escritorio en Java 21 y Swing, organizada como **Java with Ant > Java Application**. No usa Maven ni bases de datos.

## Abrir y ejecutar en NetBeans

1. Descomprime `ConectaEmpleoSwing` en una ubicación permanente.
2. En NetBeans, selecciona **File > Open Project** y elige la carpeta del proyecto.
3. En **Project Properties > Libraries > Java Platform**, selecciona JDK 21.
4. La biblioteca PDFBox 3.0.7 está en `lib/pdfbox-app-3.0.7.jar` y Ant la referencia con ruta relativa.
5. Pulsa **Run Project**. Desde una terminal abierta en la raíz:

```powershell
ant clean test
ant run
```

Para crear y ejecutar el JAR:

```powershell
ant jar
java -jar dist\ConectaEmpleoSwing.jar
```

## Persistencia y datos

Las colecciones se cargan en listas `ArrayList` y se guardan en ocho archivos de texto UTF-8 dentro de `datos/`: `administradores.txt`, `empresas.txt`, `trabajadores.txt`, `ofertas.txt`, `postulaciones.txt`, `habilidades.txt`, `capacitaciones.txt` y `documentos.txt`. Los PDF se guardan en `datos/documentos/hojas-vida/`.

Al iniciar, la aplicación conserva y carga los TXT existentes. Solo crea registros iniciales cuando `datos/` no contiene archivos de texto. No hay una acción para reemplazar los datos guardados por registros de demostración.

## Módulos

- Inicio con indicadores, estados de ofertas y postulaciones y actividad reciente.
- Trabajadores, empresas, ofertas laborales, postulaciones, habilidades, capacitaciones y hojas de vida PDF.
- Estadísticas detalladas disponibles para administración.

Cada rol ve los módulos permitidos y mantiene la misma identidad visual. Los permisos también se verifican en los controladores.

## Estructura

- `src/Main.java`: punto de entrada.
- `src/modelo`, `src/vista`, `src/controlador`, `src/utilidades`: organización sencilla MVC.
- `test`: pruebas funcionales ejecutables con `ant test`, sin JUnit.
- `lib`: PDFBox 3.0.7.
- `datos`: registros de texto actuales y documentos locales.

Los gráficos se dibujan con Java2D y Swing. La compilación no descarga dependencias.
