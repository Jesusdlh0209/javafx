# Alcance de la mejora

La mejora se aplica al proyecto ConectaEmpleo Swing existente. Se conserva su estructura Java Swing con Ant, las colecciones `ArrayList`, los archivos de texto, PDFBox 3.0.7 y las reglas de acceso por perfil.

La referencia visual se usa para orientar la distribución y la jerarquía de la interfaz. No se copiaron arquitecturas ni módulos de otros prototipos.

El menú administrativo conserva Inicio, Trabajadores, Empresas, Ofertas laborales, Postulaciones, Habilidades, Capacitaciones, Documentos y Estadísticas. Empresa y Trabajador mantienen sus menús propios con la misma paleta y estilo. El módulo de Materiales reciclables se retiró de la aplicación.
