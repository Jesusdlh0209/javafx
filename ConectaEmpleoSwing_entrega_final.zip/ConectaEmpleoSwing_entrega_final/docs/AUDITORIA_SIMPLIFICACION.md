# Informe de auditoría y mejora de ConectaEmpleo

Fecha: 9 de noviembre de 2026

## Cambios realizados

- Se unificó la navegación lateral para administrador, empresa y trabajador. `Theme` dibuja explícitamente el fondo de cada botón además de establecer su color de estado; el Look and Feel del sistema no puede dejarlo transparente. La ventana cabe en el área disponible y el contenido largo se desplaza verticalmente.
- El inicio de sesión permite mostrar la contraseña; el diálogo de cambio de clave permite mostrar los tres campos.
- El dashboard de administración muestra seis indicadores reales, gráficos Java2D con todos los estados y actividad reciente.
- Se agregó una pantalla independiente de estadísticas, protegida para administración, con cantidades, tendencias mensuales y sectores. Los cálculos se comparten desde `DashboardController`.
- Se mejoraron la búsqueda de módulos y los estados vacíos y visuales de las tablas.
- Se eliminó Materiales reciclables: clases, rutas, controlador, datos y referencias de producción.
- Se conservaron los módulos laborales, los permisos por perfil y los documentos PDFBox 3.0.7.

## Archivos principales

Modificados: `DashboardController`, `DatosAplicacion`, `ArchivoUtil`, `DatosIniciales`, `Theme`, `DashboardView`, `MainFrame`, `LoginView`, `DocumentosView`, `ModuleTableView`, `nbproject/project.properties`, `README.md`, `docs/ANALISIS_REFERENCIAS.md` y `test/DomainRulesTest.java`.

Nuevas clases: `EstadisticasView`, `GraficoBarras`, `GraficoMensual`, `PanelDesplazable`, `TablaConMensaje` y `TarjetaMetrica`.

Eliminadas: `MaterialesController`, `MaterialReciclable` y `MaterialesView`.

## Datos, respaldo y limpieza

Los ocho TXT actuales coinciden exactamente con la copia completa creada justo antes de limpiar: `outputs/backup_limpieza_20261109/ConectaEmpleoSwing`. Dos TXT ya diferían de la copia inicial de la mejora; conservé los valores actuales y no los revertí. El proyecto limpio conserva fuentes, pruebas, configuración Ant/NetBeans, datos, PDFBox y un único JAR de aplicación en `dist/`. Se quitaron compilaciones intermedias, JAR duplicados y carpetas antiguas que solo tenían `.gitkeep`.

## Compilación y comprobaciones

- Compilación limpia con Java 21 y Ant: `ant clean test jar` — `BUILD SUCCESSFUL`.
- 112 comprobaciones funcionales: acceso y permisos de los tres perfiles, cambio y persistencia de contraseña, rechazo de claves inválidas, reglas CRUD, persistencia TXT, pintura opaca de botones en reposo/hover/selección, gráficos vacíos y operaciones PDFBox.
- Se abrió el JAR de `dist/` y se verificó el login y los colores de los botones al entrar al perfil administrador.

La revisión visual manual se concentró en la sesión de administración; los accesos de empresa y trabajador se comprobaron en la suite funcional.
