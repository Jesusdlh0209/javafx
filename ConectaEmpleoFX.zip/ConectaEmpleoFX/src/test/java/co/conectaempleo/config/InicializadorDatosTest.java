package co.conectaempleo.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import co.conectaempleo.model.Administrador;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.repository.RepositorioLocal;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.services.DocumentoService;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class InicializadorDatosTest {

    @TempDir Path temporal;

    @Test
    void siembraUnaSolaVezYRestaurarConservaRegistrosReales() throws Exception {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        InicializadorDatos.cargarSiEsNecesario(repositorio);
        assertEquals(10, repositorio.listarTrabajadores().size());
        assertEquals(5, repositorio.listarEmpresas().size());
        assertEquals(8, repositorio.listarOfertas().size());
        assertEquals(8, repositorio.listarPostulaciones().size());
        assertTrue(repositorio.listarTrabajadores().stream().allMatch(Trabajador::isDemo));
        assertTrue(repositorio.listarEmpresas().stream().allMatch(Empresa::isDemo));
        assertTrue(repositorio.listarUsuarios().stream().filter(x -> x.getNombreUsuario().equals("admin"))
                .findFirst().orElseThrow() instanceof Administrador);

        repositorio.guardarTrabajador(new Trabajador("T-REAL", "Persona real", "persona", "clave-segura",
                "100-REAL", new ArrayList<>()));
        InicializadorDatos.cargarSiEsNecesario(repositorio);
        assertEquals(11, repositorio.listarTrabajadores().size(), "No debe resembrar tras borrar registros demo.");

        ServicioConectaEmpleo servicio = new ServicioConectaEmpleo(repositorio);
        Trabajador demo = repositorio.listarTrabajadores().stream().filter(Trabajador::isDemo).findFirst().orElseThrow();
        Path pdf = temporal.resolve("demo.pdf");
        try (PDDocument documento = new PDDocument()) {
            PDPage pagina = new PDPage(); documento.addPage(pagina);
            try (PDPageContentStream stream = new PDPageContentStream(documento, pagina)) {
                stream.beginText(); stream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                stream.newLineAtOffset(50, 700); stream.showText("contenido demo"); stream.endText();
            }
            documento.save(pdf.toFile());
        }
        DocumentoService documentoService = new DocumentoService(repositorio);
        var documentoDemo = documentoService.guardarHojaVida(pdf, demo);
        Path pdfGuardado = documentoService.resolverRuta(documentoDemo);
        InicializadorDatos.restaurarDemostracion(repositorio);
        assertEquals(1, servicio.contarTrabajadores());
        assertEquals(10, servicio.contarTrabajadoresDemo());
        assertFalse(Files.exists(pdfGuardado));
        assertTrue(servicio.autenticacion().autenticar("admin", "admin", RolUsuario.ADMINISTRADOR).isPresent());
    }
}
