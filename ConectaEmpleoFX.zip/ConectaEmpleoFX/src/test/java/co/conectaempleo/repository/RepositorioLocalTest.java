package co.conectaempleo.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.Trabajador;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class RepositorioLocalTest {

    @TempDir Path temporal;

    @Test
    void guardaYRecuperaDatosEntreInstancias() {
        Path archivo = temporal.resolve("data/conectaempleo.dat");
        RepositorioLocal primero = new RepositorioLocal(archivo);
        primero.guardarTrabajador(new Trabajador("T-1", "Ana Demo", "ana", "clave",
                "100", new ArrayList<>(List.of("Cartón"))));

        RepositorioLocal recargado = new RepositorioLocal(archivo);

        assertEquals(1, recargado.listarTrabajadores().size());
        assertEquals("Ana Demo", recargado.listarTrabajadores().get(0).getNombre());
    }

    @Test
    void alGuardarConservaRespaldoYRecuperaElUltimoValido() throws Exception {
        Path archivo = temporal.resolve("data/conectaempleo.dat");
        RepositorioLocal repositorio = new RepositorioLocal(archivo);
        repositorio.guardarTrabajador(new Trabajador("T-1", "Ana Demo", "ana", "clave",
                "100", new ArrayList<>()));
        repositorio.guardarEmpresa(new Empresa("E-1", "Eco Demo", "eco", "clave", "9001", "Reciclaje"));
        assertTrue(Files.isDirectory(repositorio.getDirectorioRespaldos()));

        Files.writeString(archivo, "contenido dañado");
        RepositorioLocal recuperado = new RepositorioLocal(archivo);

        assertTrue(recuperado.isRecuperadoDesdeRespaldo());
        assertEquals(1, recuperado.listarTrabajadores().size());
        assertEquals("Ana Demo", recuperado.listarTrabajadores().get(0).getNombre());
    }
}
