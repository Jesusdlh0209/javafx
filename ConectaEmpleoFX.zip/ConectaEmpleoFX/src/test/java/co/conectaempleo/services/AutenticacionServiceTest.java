package co.conectaempleo.services;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.repository.RepositorioLocal;
import java.nio.file.Path;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class AutenticacionServiceTest {

    @TempDir Path temporal;

    @Test
    void autenticaConClaveHashYValidaElRolElegido() {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        repositorio.guardarTrabajador(new Trabajador("T-1", "Ana", "ana", "clave-segura",
                "100", new ArrayList<>()));
        AutenticacionService autenticacion = new AutenticacionService(repositorio);

        assertTrue(autenticacion.autenticar(" ANA ", "clave-segura", RolUsuario.TRABAJADOR).isPresent());
        assertTrue(autenticacion.autenticar("ana", "clave-segura", RolUsuario.ADMINISTRADOR).isEmpty());
        assertFalse(autenticacion.autenticar("ana", "incorrecta", RolUsuario.TRABAJADOR).isPresent());
    }

    @Test
    void cambiarClaveRequiereClaveActualYActualizaElAcceso() {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        Trabajador trabajador = new Trabajador("T-1", "Ana", "ana", "clave-anterior",
                "100", new ArrayList<>());
        repositorio.guardarTrabajador(trabajador);
        AutenticacionService autenticacion = new AutenticacionService(repositorio);

        autenticacion.cambiarClave(trabajador, "clave-anterior", "clave-nueva-segura");

        assertTrue(repositorio.buscarUsuario("T-1").validarClave("clave-nueva-segura"));
        assertFalse(repositorio.buscarUsuario("T-1").validarClave("clave-anterior"));
    }
}
