package co.conectaempleo.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import co.conectaempleo.model.Documento;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.repository.RepositorioLocal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class DocumentoServiceTest {
    @TempDir Path temporal;

    @Test
    void guardaReemplazaYEliminaPdfConRutasRelativas() throws Exception {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        Trabajador trabajador = new Trabajador("T-1", "Ana", "ana", "clave-segura", "100", new ArrayList<>());
        repositorio.guardarTrabajador(trabajador);
        DocumentoService servicio = new DocumentoService(repositorio);
        Path primero = crearPdf("hoja.pdf", "Java Excel logistica");

        Documento guardado = servicio.guardarHojaVida(primero, trabajador);
        Path rutaPrimera = servicio.resolverRuta(guardado);
        assertTrue(Files.isRegularFile(rutaPrimera));
        assertFalse(Path.of(guardado.getRutaRelativa()).isAbsolute());
        assertEquals("hoja.pdf", guardado.getNombreOriginal());

        Path segundo = crearPdf("hoja-nueva.pdf", "Ventas servicio al cliente");
        Documento reemplazo = servicio.guardarHojaVida(segundo, trabajador);
        assertEquals("hoja-nueva.pdf", reemplazo.getNombreOriginal());
        assertFalse(Files.exists(rutaPrimera));
        assertTrue(Files.isRegularFile(servicio.resolverRuta(reemplazo)));

        servicio.eliminar(trabajador.getId(), trabajador);
        assertFalse(servicio.tieneDocumento(trabajador.getId()));
        assertFalse(Files.exists(servicio.resolverRuta(reemplazo)));
    }

    @Test
    void rechazaPdfInvalidoYAccesoDeOtraCuenta() throws Exception {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        Trabajador trabajador = new Trabajador("T-1", "Ana", "ana", "clave-segura", "100", new ArrayList<>());
        Empresa empresa = new Empresa("E-1", "Eco", "eco", "clave-segura", "900", "Reciclaje");
        repositorio.guardarTrabajador(trabajador);
        repositorio.guardarEmpresa(empresa);
        DocumentoService servicio = new DocumentoService(repositorio);
        Path falsoPdf = temporal.resolve("falso.pdf");
        Files.writeString(falsoPdf, "NO ES PDF");
        assertThrows(IllegalArgumentException.class, () -> servicio.guardarHojaVida(falsoPdf, trabajador));

        Path pdf = crearPdf("real.pdf", "contenido real");
        Documento documento = servicio.guardarHojaVida(pdf, trabajador);
        assertThrows(IllegalArgumentException.class, () -> servicio.eliminar(trabajador.getId(), empresa));
        assertThrows(IllegalArgumentException.class, () -> servicio.resolverRuta(
                new Documento("CV-T-2", "T-2", "x.pdf", "..\\escape.pdf", 10, java.time.LocalDateTime.now())));
        assertTrue(Files.exists(servicio.resolverRuta(documento)));

        Path danado = temporal.resolve("danado.pdf");
        Files.writeString(danado, "%PDF-1.4\narchivo incompleto sin trailer PDF");
        assertThrows(java.io.IOException.class, () -> servicio.guardarHojaVida(danado, trabajador));
    }

    @Test
    void migraRutaAbsolutaAntiguaSinEliminarElOriginal() throws Exception {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        Trabajador trabajador = new Trabajador("T-1", "Ana", "ana", "clave-segura", "100", new ArrayList<>());
        Path pdfAnterior = crearPdf("cv-antiguo.pdf", "archivo anterior");
        trabajador.setRutaHojaVida(pdfAnterior.toString());
        repositorio.guardarTrabajador(trabajador);
        DocumentoService servicio = new DocumentoService(repositorio);

        Documento migrado = servicio.migrarRutaLegada(trabajador);

        assertEquals("cv-antiguo.pdf", migrado.getNombreOriginal());
        assertTrue(Files.isRegularFile(servicio.resolverRuta(migrado)));
        assertTrue(Files.exists(pdfAnterior), "La importación conserva el archivo original.");
    }

    @Test
    void analizaPaginasTextoYHabilidadesConPdfBox() throws Exception {
        Path pdf = crearPdf("analizable.pdf", "Java Excel logistica");
        AnalisisHojaVida resultado = new AnalizadorPDFService().analizar(pdf);
        assertEquals(1, resultado.paginas());
        assertTrue(resultado.caracteresExtraidos() > 0);
        assertTrue(resultado.habilidadesSugeridas().containsAll(java.util.List.of("Java", "Excel", "Logística")));
    }

    private Path crearPdf(String nombre, String contenido) throws Exception {
        Path archivo = temporal.resolve(nombre);
        try (PDDocument documento = new PDDocument()) {
            PDPage pagina = new PDPage();
            documento.addPage(pagina);
            try (PDPageContentStream stream = new PDPageContentStream(documento, pagina)) {
                stream.beginText();
                stream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
                stream.newLineAtOffset(50, 700);
                stream.showText(contenido);
                stream.endText();
            }
            documento.save(archivo.toFile());
        }
        return archivo;
    }
}
