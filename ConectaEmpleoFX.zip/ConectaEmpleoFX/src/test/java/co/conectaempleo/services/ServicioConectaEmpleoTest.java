package co.conectaempleo.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.repository.RepositorioLocal;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ServicioConectaEmpleoTest {
    @TempDir Path temporal;

    @Test
    void administraPerfilesOfertasPostulacionesYCapacitaciones() throws Exception {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        ServicioConectaEmpleo servicio = new ServicioConectaEmpleo(repositorio);
        var admin = repositorio.listarUsuarios().stream().filter(x -> x.getRol() == RolUsuario.ADMINISTRADOR).findFirst().orElseThrow();

        servicio.crear(ModuloGestion.EMPRESAS, List.of("9001", "Eco Prueba", "eco", "empresa123",
                "Reciclaje", "Mamonal", "000-1234", "eco@example.test", "Clasificación de material."), admin);
        Empresa empresa = repositorio.listarEmpresas().get(0);
        servicio.crear(ModuloGestion.TRABAJADORES, List.of("1001", "Ana Prueba", "ana", "trabajador123",
                "ana@example.test", "000-4567", "Cartagena", "Operaria de reciclaje", "Clasificación, Seguridad", "Disponible"), admin);
        Trabajador trabajador = repositorio.listarTrabajadores().get(0);

        servicio.actualizar(ModuloGestion.TRABAJADORES, trabajador.getId(), List.of("1001", "Ana Actualizada", "ana",
                "", "ana2@example.test", "000-4567", "Cartagena", "Perfil actualizado", "Clasificación", "Medio tiempo"), admin);
        assertEquals("ana2@example.test", repositorio.buscarTrabajador(trabajador.getId()).getCorreo());
        assertEquals("Medio tiempo", repositorio.buscarTrabajador(trabajador.getId()).getDisponibilidad());

        servicio.crear(ModuloGestion.OFERTAS, List.of(empresa.getId(), "Auxiliar", "Apoyo en clasificación",
                "Experiencia deseable", "Clasificación, Seguridad", "Mamonal", "Tiempo completo", "1500000",
                "2030-12-31", "2"), empresa);
        var oferta = repositorio.listarOfertas().get(0);
        servicio.postularse(oferta.getId(), trabajador);
        assertEquals(1, repositorio.listarPostulaciones().size());
        assertThrows(IllegalArgumentException.class, () -> servicio.postularse(oferta.getId(), trabajador));
        servicio.eliminar(ModuloGestion.OFERTAS, oferta.getId(), admin);
        assertEquals(1, repositorio.listarPostulaciones().size(), "Cerrar una oferta conserva el historial de postulaciones.");
        assertEquals(false, repositorio.buscarOferta(oferta.getId()).isActiva());
        assertThrows(IllegalArgumentException.class, () -> servicio.eliminar(ModuloGestion.TRABAJADORES, trabajador.getId(), admin));
        assertThrows(IllegalArgumentException.class, () -> servicio.eliminar(ModuloGestion.EMPRESAS, empresa.getId(), admin));

        servicio.crear(ModuloGestion.CAPACITACIONES,
                List.of("Seguridad en reciclaje", "Seguridad", "Centro formador", "Curso de seguridad",
                        "8", "2030-02-10", "20", "Disponible"), admin);
        var curso = repositorio.listarCapacitaciones().get(0);
        servicio.inscribirseCapacitacion(curso.getId(), trabajador);
        assertTrue(repositorio.listarCapacitaciones().get(0).getParticipantes().contains(trabajador.getId()));
        servicio.eliminar(ModuloGestion.CAPACITACIONES, curso.getId(), admin);
        assertEquals(1, repositorio.listarCapacitaciones().get(0).getParticipantes().size(), "El cierre conserva las inscripciones.");

        assertEquals(ModuloGestion.TRABAJADORES.getColumnas().size(),
                servicio.listar(ModuloGestion.TRABAJADORES, admin, "").get(0).cantidadCeldas());
    }

    @Test
    void bloqueaAccionesFueraDelRolYValidaCampos() {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        ServicioConectaEmpleo servicio = new ServicioConectaEmpleo(repositorio);
        var admin = repositorio.listarUsuarios().stream().filter(x -> x.getRol() == RolUsuario.ADMINISTRADOR).findFirst().orElseThrow();
        assertThrows(IllegalArgumentException.class, () -> servicio.crear(ModuloGestion.TRABAJADORES,
                List.of("100", "Ana", "ana", "short", "", "", "", "", "", "Disponible"), admin));
        Empresa empresa = new Empresa("E-1", "Eco", "eco", "clave-segura", "900", "Reciclaje");
        assertThrows(IllegalArgumentException.class, () -> servicio.listar(ModuloGestion.MATERIALES, empresa, ""));
    }
}
