package co.conectaempleo.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class DominioConectaEmpleoTest {

    @Test
    void trabajadorProtegeSuColeccionDeHabilidades() {
        ArrayList<String> iniciales = new ArrayList<>(List.of("Clasificación PET"));
        Trabajador trabajador = new Trabajador("T-1", "Ana Demo", "ana", "clave",
                "100", iniciales);
        iniciales.add("Dato externo");
        ArrayList<String> copia = trabajador.getHabilidades();
        copia.clear();

        assertEquals(List.of("Clasificación PET"), trabajador.getHabilidades());
    }

    @Test
    void subtiposCompartenUsuarioAbstractoYConservanElRol() {
        Usuario administrador = new Administrador("A-1", "Admin", "admin", "clave");
        Empresa empresa = new Empresa("E-1", "Eco Demo", "eco", "clave", "9001", "Reciclaje");
        Trabajador trabajador = new Trabajador("T-1", "Ana Demo", "ana", "clave", "100", new ArrayList<>());

        assertEquals(RolUsuario.ADMINISTRADOR, administrador.getRol());
        assertEquals(RolUsuario.EMPRESA, empresa.getRol());
        assertEquals(RolUsuario.TRABAJADOR, trabajador.getRol());
        assertTrue(administrador.getResumenPerfil().contains("Administración"));
        assertFalse(trabajador.getResumenPerfil().isBlank());
    }

    @Test
    void ofertaVencidaNoSeConsideraActiva() {
        OfertaLaboral oferta = new OfertaLaboral("O-1", "E-1", "Eco Demo", "Auxiliar",
                "Clasificar materiales", "Experiencia deseable", List.of("PET"),
                "Cartagena", "Tiempo completo", null, LocalDate.now().minusDays(4),
                LocalDate.now().minusDays(1), 2, true);

        assertEquals(EstadoOferta.VENCIDA, oferta.getEstado());
        assertFalse(oferta.isActiva());
    }

    @Test
    void postulacionRegistraElHistorialDeEstados() {
        Postulacion postulacion = new Postulacion("P-1", "T-1", "Ana Demo", "O-1", "Auxiliar", "E-1");
        postulacion.setEstado(EstadoPostulacion.EN_REVISION.getEtiqueta());

        assertEquals(EstadoPostulacion.EN_REVISION, postulacion.getEstadoEnum());
        assertEquals(2, postulacion.getHistorialEstados().size());
    }
}
