package co.conectaempleo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import co.conectaempleo.model.Administrador;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.repository.RepositorioLocal;
import co.conectaempleo.services.ServicioConectaEmpleo;
import java.net.URL;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.nio.file.Path;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class FXMLLoadSmokeTest {
    @TempDir Path temporal;
    private static final List<String> VISTAS = List.of("login-view.fxml", "shell-view.fxml", "dashboard-view.fxml",
            "trabajadores-view.fxml", "empresas-view.fxml", "ofertas-view.fxml", "postulaciones-view.fxml",
            "habilidades-view.fxml", "capacitaciones-view.fxml", "materiales-view.fxml", "documentos-view.fxml");

    @BeforeAll
    static void iniciarJavaFx() throws Exception {
        CompletableFuture<Void> inicio = new CompletableFuture<>();
        try { Platform.startup(() -> inicio.complete(null)); }
        catch (IllegalStateException yaIniciado) { inicio.complete(null); }
        inicio.get(10, TimeUnit.SECONDS);
    }

    @AfterAll
    static void cerrarJavaFx() {
        Platform.exit();
    }

    @Test
    void todasLasVistasFXMLCarganConFXMLLoader() throws Exception {
        RepositorioLocal repositorio = new RepositorioLocal(temporal.resolve("data/conectaempleo.dat"));
        Administrador admin = (Administrador) repositorio.listarUsuarios().stream()
                .filter(x -> x instanceof Administrador).findFirst().orElseThrow();
        Trabajador trabajador = new Trabajador("TRA-FXML", "Trabajador Prueba", "worker.fxml", "clave-segura",
                "DOC-FXML", "worker@example.test", "000000", "Cartagena", "Perfil", new java.util.ArrayList<>(), "Disponible");
        Empresa empresa = new Empresa("EMP-FXML", "Empresa Prueba", "company.fxml", "clave-segura", "900-FXML",
                "Reciclaje", "Cartagena", "000001", "company@example.test", "Perfil de prueba");
        repositorio.guardarTrabajador(trabajador);
        repositorio.guardarEmpresa(empresa);
        ServicioConectaEmpleo servicio = new ServicioConectaEmpleo(repositorio);
        CompletableFuture<Integer> carga = new CompletableFuture<>();
        Platform.runLater(() -> {
            try {
                int cantidad = 0;
                for (String nombre : VISTAS) {
                    URL recurso = getClass().getResource("/fxml/" + nombre);
                    assertNotNull(recurso, "No existe el recurso " + nombre);
                    FXMLLoader loader = new FXMLLoader(recurso);
                    assertNotNull(loader.load(), "No cargó " + nombre);
                    Object controller = loader.getController();
                    switch (nombre) {
                        case "dashboard-view.fxml" -> {
                            var dashboard = (DashboardController) controller;
                            dashboard.configurar(servicio, admin, modulo -> { });
                            dashboard.configurar(servicio, empresa, modulo -> { });
                            dashboard.configurar(servicio, trabajador, modulo -> { });
                        }
                        case "trabajadores-view.fxml" -> {
                            var vista = (TrabajadoresController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, trabajador);
                        }
                        case "empresas-view.fxml" -> {
                            var vista = (EmpresasController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, empresa);
                        }
                        case "ofertas-view.fxml" -> {
                            var vista = (OfertasController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, empresa); vista.configurar(servicio, trabajador);
                        }
                        case "postulaciones-view.fxml" -> {
                            var vista = (PostulacionesController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, empresa); vista.configurar(servicio, trabajador);
                        }
                        case "habilidades-view.fxml" -> {
                            var vista = (HabilidadesController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, trabajador);
                        }
                        case "capacitaciones-view.fxml" -> {
                            var vista = (CapacitacionesController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, trabajador);
                        }
                        case "materiales-view.fxml" -> ((MaterialesController) controller).configurar(servicio, admin);
                        case "documentos-view.fxml" -> {
                            var vista = (DocumentosController) controller; vista.configurar(servicio, admin); vista.configurar(servicio, trabajador);
                        }
                    }
                    cantidad++;
                }
                carga.complete(cantidad);
            } catch (Throwable ex) {
                carga.completeExceptionally(ex);
            }
        });
        assertEquals(VISTAS.size(), carga.get(20, TimeUnit.SECONDS));
    }
}
