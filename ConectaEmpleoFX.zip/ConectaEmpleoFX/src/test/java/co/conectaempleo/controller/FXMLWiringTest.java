package co.conectaempleo.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Files;
import java.nio.file.Path;
import javax.xml.parsers.DocumentBuilderFactory;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

class FXMLWiringTest {
    @Test
    void todasLasAccionesFXMLApuntanAMetodosDeSuControlador() throws Exception {
        Path carpeta = Path.of("src/main/resources/fxml");
        try (var archivos = Files.list(carpeta)) {
            for (Path archivo : archivos.filter(p -> p.toString().endsWith(".fxml")).toList()) {
                var factory = DocumentBuilderFactory.newInstance();
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                Element raiz = factory.newDocumentBuilder().parse(archivo.toFile()).getDocumentElement();
                String nombreClase = raiz.getAttribute("fx:controller");
                Class<?> controlador = Class.forName(nombreClase);
                NodeList nodos = raiz.getElementsByTagName("*");
                for (int i = 0; i < nodos.getLength(); i++) {
                    Element nodo = (Element) nodos.item(i);
                    String accion = nodo.getAttribute("onAction");
                    if (!accion.startsWith("#")) continue;
                    String metodo = accion.substring(1);
                    assertTrue(existeMetodo(controlador, metodo), archivo.getFileName() + " apunta a #" + metodo + " sin handler en " + nombreClase);
                }
            }
        }
    }

    private static boolean existeMetodo(Class<?> tipo, String nombre) {
        for (Class<?> clase = tipo; clase != null; clase = clase.getSuperclass()) {
            for (var metodo : clase.getDeclaredMethods()) if (metodo.getName().equals(nombre)) return true;
        }
        return false;
    }
}
