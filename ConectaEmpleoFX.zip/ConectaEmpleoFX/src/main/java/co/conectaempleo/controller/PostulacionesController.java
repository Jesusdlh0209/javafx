package co.conectaempleo.controller;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.Postulacion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.io.IOException;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public final class PostulacionesController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private ChoiceBox<String> estadoFiltro, ofertaFiltro;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private Button estadoButton, retirarButton, cvButton;

    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.POSTULACIONES,
                "Candidato", "Oferta", "Empresa", "Fecha", "Estado", "Origen");
        boolean empresaOAdmin = actor.getRol() != RolUsuario.TRABAJADOR;
        estadoButton.setVisible(empresaOAdmin); cvButton.setVisible(empresaOAdmin);
        retirarButton.setVisible(actor.getRol() == RolUsuario.TRABAJADOR);
        estadoFiltro.getItems().setAll("Todos", "Pendiente", "En revisión", "Seleccionado", "No seleccionado", "Aceptada", "Rechazada", "Retirada");
        ofertaFiltro.getItems().setAll("Todas");
        servicio.listarOfertas().forEach(x -> { if (!ofertaFiltro.getItems().contains(x.getCargo())) ofertaFiltro.getItems().add(x.getCargo()); });
        estadoFiltro.getSelectionModel().selectFirst(); ofertaFiltro.getSelectionModel().selectFirst();
        estadoFiltro.getSelectionModel().selectedItemProperty().addListener((o,a,b) -> cargarTabla());
        ofertaFiltro.getSelectionModel().selectedItemProperty().addListener((o,a,b) -> cargarTabla());
        cargarTabla();
    }
    private void cargarTabla() {
        cargar(tabla, filtroField, resultadoLabel, ModuloGestion.POSTULACIONES);
        tabla.getItems().removeIf(x -> (!"Todos".equals(estadoFiltro.getValue()) && !x.getCelda(4).equals(estadoFiltro.getValue()))
                || (!"Todas".equals(ofertaFiltro.getValue()) && !x.getCelda(1).equals(ofertaFiltro.getValue())));
        resultadoLabel.setText(tabla.getItems().size() + " procesos");
    }
    @FXML private void actualizarTabla() { cargarTabla(); }

    @FXML private void verHistorial() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Postulacion p = servicio.buscarPostulacion(fila.getId());
        verDetalle("Proceso de " + p.getTrabajadorNombre(), "Oferta: " + p.getOfertaCargo() + "\nFecha: " + p.getFechaPostulacion()
                + "\nEstado actual: " + p.getEstado() + "\n\nHistorial de cambios:\n" + String.join("\n", p.getHistorialEstados()));
    }

    @FXML private void cambiarEstado() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        List<String> estados = List.of("Pendiente", "En revisión", "Seleccionado", "No seleccionado");
        ChoiceDialog<String> dialogo = new ChoiceDialog<>("En revisión", estados);
        dialogo.setTitle("Seguimiento de candidato"); dialogo.setHeaderText("Selecciona el nuevo estado");
        dialogo.showAndWait().ifPresent(estado -> ejecutar(() -> servicio.cambiarEstadoPostulacion(fila.getId(), estado, actor), this::cargarTabla, "El historial fue actualizado."));
    }

    @FXML private void abrirHojaVida() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try { servicio.abrirDocumento(servicio.buscarPostulacion(fila.getId()).getTrabajadorId(), actor); }
        catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }

    @FXML private void retirarPostulacion() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Retirar postulación", "Se conservará el proceso en el historial con estado Retirada.")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.POSTULACIONES, fila.getId(), actor); } catch (Exception ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "La postulación fue retirada.");
    }
}
