package co.conectaempleo.controller;

import co.conectaempleo.model.Capacitacion;
import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public final class CapacitacionesController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private Button nuevaButton, editarButton, eliminarButton, inscribirseButton, participantesButton;
    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.CAPACITACIONES,
                "Capacitación", "Habilidad", "Entidad", "Descripción", "Duración", "Fecha", "Cupos", "Participantes", "Estado", "Origen");
        boolean admin = actor.getRol() == RolUsuario.ADMINISTRADOR;
        nuevaButton.setVisible(admin); editarButton.setVisible(admin); eliminarButton.setVisible(admin);
        participantesButton.setVisible(admin);
        inscribirseButton.setVisible(actor.getRol() == RolUsuario.TRABAJADOR); cargarTabla();
    }
    private void cargarTabla() { cargar(tabla, filtroField, resultadoLabel, ModuloGestion.CAPACITACIONES); }
    @FXML private void actualizarTabla() { cargarTabla(); }
    @FXML private void registrarCapacitacion() {
        pedirDatos("Nueva capacitación", ModuloGestion.CAPACITACIONES.getCampos(), null, ModuloGestion.CAPACITACIONES)
                .ifPresent(datos -> ejecutar(() -> servicio.crear(ModuloGestion.CAPACITACIONES, datos, actor), this::cargarTabla, "La capacitación fue registrada."));
    }
    @FXML private void editarCapacitacion() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try { pedirDatos("Editar capacitación", ModuloGestion.CAPACITACIONES.getCampos(),
                servicio.obtenerCamposFormulario(ModuloGestion.CAPACITACIONES, fila.getId(), actor), ModuloGestion.CAPACITACIONES)
                .ifPresent(datos -> ejecutar(() -> servicio.actualizar(ModuloGestion.CAPACITACIONES, fila.getId(), datos, actor), this::cargarTabla, "La capacitación fue actualizada.")); }
        catch (RuntimeException ex) { error(ex.getMessage()); }
    }
    @FXML private void eliminarCapacitacion() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Eliminar capacitación", "Si tiene participantes se cerrará para conservar las inscripciones; si no, se eliminará.")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.CAPACITACIONES, fila.getId(), actor); } catch (Exception ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "Capacitación procesada según su historial.");
    }
    @FXML private void inscribirme() {
        FilaModulo fila = seleccionada(tabla); if (fila != null) ejecutar(() -> servicio.inscribirseCapacitacion(fila.getId(), actor), this::cargarTabla, "La inscripción fue registrada.");
    }
    @FXML private void verDetalles() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Capacitacion c = servicio.listarCapacitaciones().stream().filter(x -> x.getId().equals(fila.getId())).findFirst().orElse(null);
        if (c == null) return;
        verDetalle(c.getNombre(), "Habilidad: " + c.getHabilidad() + "\nEntidad: " + c.getEntidad()
                + "\nDuración: " + c.getDuracionHoras() + " horas\nFecha: " + c.getFechaInicio()
                + "\nCupos ocupados: " + c.getParticipantes().size() + "/" + c.getCupos()
                + "\nEstado: " + (c.isActiva() ? "Disponible" : "Cerrada") + "\n\n" + c.getDescripcion());
    }
    @FXML private void consultarParticipantes() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Capacitacion c = servicio.listarCapacitaciones().stream().filter(x -> x.getId().equals(fila.getId())).findFirst().orElse(null);
        if (c == null) return;
        String personas = c.getParticipantes().stream().map(id -> servicio.buscarTrabajador(id))
                .filter(java.util.Objects::nonNull).map(x -> "• " + x.getNombre() + " — " + x.getCorreo())
                .collect(java.util.stream.Collectors.joining("\n"));
        verDetalle("Participantes · " + c.getNombre(), personas.isBlank() ? "Aún no hay participantes." : personas);
    }
}
