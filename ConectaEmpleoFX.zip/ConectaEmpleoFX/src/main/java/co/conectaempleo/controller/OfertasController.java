package co.conectaempleo.controller;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public final class OfertasController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private ChoiceBox<String> empresaFiltro, ubicacionFiltro, contratoFiltro, estadoFiltro;
    @FXML private Button publicarButton, editarButton, eliminarButton, estadoButton, postularButton, postulacionesButton;

    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.OFERTAS,
                "Empresa", "Cargo", "Ubicación", "Contrato", "Salario", "Publicado", "Fecha límite", "Habilidades", "Vacantes", "Estado", "Origen");
        publicarButton.setVisible(actor.getRol() != RolUsuario.TRABAJADOR);
        editarButton.setVisible(actor.getRol() != RolUsuario.TRABAJADOR);
        eliminarButton.setVisible(actor.getRol() != RolUsuario.TRABAJADOR);
        estadoButton.setVisible(actor.getRol() != RolUsuario.TRABAJADOR);
        postularButton.setVisible(actor instanceof Trabajador);
        postulacionesButton.setVisible(actor.getRol() != RolUsuario.TRABAJADOR);
        poblarFiltros();
        for (ChoiceBox<String> filtro : List.of(empresaFiltro, ubicacionFiltro, contratoFiltro, estadoFiltro)) {
            filtro.getSelectionModel().selectedItemProperty().addListener((obs, antes, ahora) -> cargarTabla());
        }
        cargarTabla();
    }

    private void poblarFiltros() {
        empresaFiltro.getItems().setAll("Todas");
        servicio.listarEmpresas().forEach(x -> empresaFiltro.getItems().add(x.getNombre()));
        ubicacionFiltro.getItems().setAll("Todas"); contratoFiltro.getItems().setAll("Todos"); estadoFiltro.getItems().setAll("Todos");
        servicio.listarOfertas().forEach(x -> {
            if (!ubicacionFiltro.getItems().contains(x.getUbicacion())) ubicacionFiltro.getItems().add(x.getUbicacion());
            if (!contratoFiltro.getItems().contains(x.getTipoContrato())) contratoFiltro.getItems().add(x.getTipoContrato());
            String estado = x.isActiva() ? "Publicada" : x.estaVencida() ? "Vencida" : "Cerrada";
            if (!estadoFiltro.getItems().contains(estado)) estadoFiltro.getItems().add(estado);
        });
        empresaFiltro.getSelectionModel().selectFirst(); ubicacionFiltro.getSelectionModel().selectFirst();
        contratoFiltro.getSelectionModel().selectFirst(); estadoFiltro.getSelectionModel().selectFirst();
    }

    private void cargarTabla() {
        cargar(tabla, filtroField, resultadoLabel, ModuloGestion.OFERTAS);
        tabla.getItems().removeIf(f ->
                (!"Todas".equals(empresaFiltro.getValue()) && !f.getCelda(0).equals(empresaFiltro.getValue()))
                || (!"Todas".equals(ubicacionFiltro.getValue()) && !f.getCelda(2).equals(ubicacionFiltro.getValue()))
                || (!"Todos".equals(contratoFiltro.getValue()) && !f.getCelda(3).equals(contratoFiltro.getValue()))
                || (!"Todos".equals(estadoFiltro.getValue()) && !f.getCelda(9).equals(estadoFiltro.getValue())));
        resultadoLabel.setText(tabla.getItems().size() + " ofertas");
    }
    @FXML private void actualizarTabla() { cargarTabla(); }

    @FXML private void publicarOferta() {
        List<String> etiquetas = List.of("Empresa (ID o NIT)", "Cargo", "Descripción", "Requisitos", "Habilidades requeridas separadas por coma", "Ubicación", "Tipo de contrato", "Salario mensual (opcional)", "Fecha límite", "Vacantes");
        pedirDatos("Publicar oferta laboral", etiquetas, null, ModuloGestion.OFERTAS).ifPresent(datos -> ejecutar(
                () -> servicio.crear(ModuloGestion.OFERTAS, datos, actor), this::cargarTabla, "La oferta fue publicada."));
    }

    @FXML private void editarOferta() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try {
            List<String> etiquetas = List.of("Empresa (ID o NIT)", "Cargo", "Descripción", "Requisitos", "Habilidades requeridas separadas por coma", "Ubicación", "Tipo de contrato", "Salario mensual (opcional)", "Fecha límite", "Vacantes");
            pedirDatos("Editar oferta", etiquetas, servicio.obtenerCamposFormulario(ModuloGestion.OFERTAS, fila.getId(), actor), ModuloGestion.OFERTAS)
                    .ifPresent(datos -> ejecutar(() -> servicio.actualizar(ModuloGestion.OFERTAS, fila.getId(), datos, actor), this::cargarTabla, "La oferta fue actualizada."));
        } catch (RuntimeException ex) { error(ex.getMessage()); }
    }

    @FXML private void verDetalles() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        OfertaLaboral o = servicio.buscarOferta(fila.getId()); if (o == null) return;
        long postulaciones = servicio.listarPostulaciones().stream().filter(x -> x.getOfertaId().equals(o.getId())).count();
        verDetalle(o.getCargo(), "Empresa: " + o.getEmpresaNombre() + "\nUbicación: " + o.getUbicacion() + "\nContrato: " + o.getTipoContrato()
                + "\nSalario: " + (o.getSalario() == null ? "Por acordar" : o.getSalario()) + "\nVacantes: " + o.getVacantes()
                + "\nFecha límite: " + o.getFechaLimite() + "\nPostulaciones: " + postulaciones + "\n\nDescripción:\n" + o.getDescripcion()
                + "\n\nRequisitos:\n" + o.getRequisitos());
    }

    @FXML private void consultarPostulaciones() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        String lista = servicio.listarPostulaciones().stream().filter(p -> p.getOfertaId().equals(fila.getId()))
                .map(p -> "• " + p.getTrabajadorNombre() + " — " + p.getEstado() + " · " + p.getFechaPostulacion().toLocalDate())
                .collect(java.util.stream.Collectors.joining("\n"));
        verDetalle("Candidatos de la oferta", lista.isBlank() ? "Esta oferta todavía no tiene postulaciones." : lista);
    }

    @FXML private void cambiarEstado() {
        FilaModulo fila = seleccionada(tabla);
        if (fila != null) ejecutar(() -> servicio.alternarEstadoOferta(fila.getId(), actor), this::cargarTabla, "El estado de publicación fue actualizado.");
    }

    @FXML private void eliminarOferta() {
        FilaModulo fila = seleccionada(tabla);
        if (fila == null || !confirmar("Cerrar o eliminar oferta", "Si tiene postulaciones se cerrará para preservar su historial; si no, se eliminará.")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.OFERTAS, fila.getId(), actor); } catch (Exception ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "La oferta fue procesada.");
    }

    @FXML private void postularme() {
        FilaModulo fila = seleccionada(tabla); if (fila != null) ejecutar(() -> servicio.postularse(fila.getId(), actor), this::cargarTabla, "Tu postulación quedó registrada.");
    }
}
