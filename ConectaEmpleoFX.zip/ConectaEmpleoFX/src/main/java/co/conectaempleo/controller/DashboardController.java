package co.conectaempleo.controller;

import co.conectaempleo.model.Capacitacion;
import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.Postulacion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.Consumer;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;

/** Panel de inicio personalizado por rol; los valores salen de los registros locales. */
public final class DashboardController {
    @FXML private Label encabezadoLabel, saludoLabel, descripcionLabel;
    @FXML private Label stat1Titulo, stat1Valor, stat2Titulo, stat2Valor, stat3Titulo, stat3Valor;
    @FXML private Label stat4Titulo, stat4Valor, stat5Titulo, stat5Valor, stat6Titulo, stat6Valor;
    @FXML private Label actividadLabel, ofertasLabel, demoResumenLabel, archivoDatosLabel;
    @FXML private Button acceso1Button, acceso2Button, acceso3Button, restaurarDemoButton;
    @FXML private PieChart estadosChart;
    private ServicioConectaEmpleo servicio;
    private Usuario usuario;
    private Consumer<ModuloGestion> navegacion = modulo -> { };
    private final Map<Integer, ModuloGestion> destinos = new java.util.HashMap<>();

    public void configurar(ServicioConectaEmpleo servicio, Usuario usuario) {
        configurar(servicio, usuario, modulo -> { });
    }

    public void configurar(ServicioConectaEmpleo servicio, Usuario usuario, Consumer<ModuloGestion> navegacion) {
        this.servicio = servicio;
        this.usuario = usuario;
        this.navegacion = navegacion;
        encabezadoLabel.setText("ESPACIO DE " + usuario.getRol().getEtiqueta().toUpperCase(java.util.Locale.ROOT));
        restaurarDemoButton.setVisible(usuario.getRol() == RolUsuario.ADMINISTRADOR);
        restaurarDemoButton.setManaged(restaurarDemoButton.isVisible());
        configurarAccesos();
        refrescar();
    }

    private void configurarAccesos() {
        if (usuario.getRol() == RolUsuario.ADMINISTRADOR) {
            saludoLabel.setText("Resumen general");
            descripcionLabel.setText("Supervisa los perfiles, empresas, ofertas y procesos de selección.");
            acceso1Button.setText("Trabajadores"); destino(1, ModuloGestion.TRABAJADORES);
            acceso2Button.setText("Ofertas laborales"); destino(2, ModuloGestion.OFERTAS);
            acceso3Button.setText("Capacitaciones"); destino(3, ModuloGestion.CAPACITACIONES);
        } else if (usuario.getRol() == RolUsuario.EMPRESA) {
            saludoLabel.setText("Hola, " + usuario.getNombre());
            descripcionLabel.setText("Tu panel empresarial: publica oportunidades y da seguimiento a tus candidatos.");
            acceso1Button.setText("Mi empresa"); destino(1, ModuloGestion.EMPRESAS);
            acceso2Button.setText("Mis ofertas"); destino(2, ModuloGestion.OFERTAS);
            acceso3Button.setText("Candidatos"); destino(3, ModuloGestion.POSTULACIONES);
        } else {
            saludoLabel.setText("Hola, " + usuario.getNombre());
            descripcionLabel.setText("Consulta oportunidades, mejora tu perfil y revisa tus postulaciones.");
            acceso1Button.setText("Mi perfil"); destino(1, ModuloGestion.TRABAJADORES);
            acceso2Button.setText("Buscar ofertas"); destino(2, ModuloGestion.OFERTAS);
            acceso3Button.setText("Mis postulaciones"); destino(3, ModuloGestion.POSTULACIONES);
        }
    }

    private void destino(int indice, ModuloGestion modulo) { destinos.put(indice, modulo); }

    private void refrescar() {
        var trabajadores = servicio.listarTrabajadores();
        var empresas = servicio.listarEmpresas();
        var ofertas = servicio.listarOfertas();
        var cursos = servicio.listarCapacitaciones();
        var materiales = servicio.listarMateriales();
        var postulaciones = servicio.listarPostulaciones().stream()
                .filter(p -> usuario.getRol() == RolUsuario.ADMINISTRADOR
                        || usuario.getRol() == RolUsuario.EMPRESA && p.getEmpresaId().equals(usuario.getId())
                        || usuario.getRol() == RolUsuario.TRABAJADOR && p.getTrabajadorId().equals(usuario.getId()))
                .toList();

        if (usuario.getRol() == RolUsuario.ADMINISTRADOR) {
            tarjetas(new String[]{"TRABAJADORES", "EMPRESAS", "OFERTAS ACTIVAS", "PENDIENTES", "CAPACITACIONES", "MATERIALES"},
                    new int[]{trabajadores.size(), empresas.size(), (int) ofertas.stream().filter(OfertaLaboral::isActiva).count(),
                        (int) postulaciones.stream().filter(p -> "Pendiente".equals(p.getEstado())).count(), cursos.size(), materiales.size()});
        } else if (usuario.getRol() == RolUsuario.EMPRESA) {
            var misOfertas = ofertas.stream().filter(o -> o.getEmpresaId().equals(usuario.getId())).toList();
            tarjetas(new String[]{"MIS OFERTAS", "PUBLICADAS", "CANDIDATOS", "PENDIENTES", "EN REVISIÓN", "SELECCIONADOS"},
                    new int[]{misOfertas.size(), (int) misOfertas.stream().filter(OfertaLaboral::isActiva).count(), postulaciones.size(),
                        contar(postulaciones, "Pendiente"), contar(postulaciones, "En revisión"), contar(postulaciones, "Seleccionado")});
        } else {
            Trabajador trabajador = servicio.buscarTrabajador(usuario.getId());
            int habilidades = trabajador == null ? 0 : trabajador.getHabilidades().size();
            long misCursos = cursos.stream().filter(c -> c.getParticipantes().contains(usuario.getId())).count();
            tarjetas(new String[]{"OFERTAS DISPONIBLES", "MIS POSTULACIONES", "EN REVISIÓN", "MIS HABILIDADES", "MIS CURSOS", "HOJA DE VIDA"},
                    new int[]{(int) ofertas.stream().filter(OfertaLaboral::isActiva).count(), postulaciones.size(), contar(postulaciones, "En revisión"),
                        habilidades, (int) misCursos, servicio.tieneDocumento(usuario.getId()) ? 1 : 0});
            stat6Titulo.setText("HOJA DE VIDA"); stat6Valor.setText(servicio.tieneDocumento(usuario.getId()) ? "Lista" : "Pendiente");
        }
        mostrarActividad(postulaciones);
        mostrarOfertas(ofertas);
        actualizarGrafico(postulaciones);
        demoResumenLabel.setText("Demostración: " + servicio.contarTrabajadoresDemo() + " trabajadores · "
                + servicio.contarEmpresasDemo() + " empresas · " + servicio.contarOfertasDemo() + " ofertas · "
                + servicio.contarPostulacionesDemo() + " postulaciones.");
        archivoDatosLabel.setText(servicio.getArchivoDatos().toString());
    }

    private static int contar(java.util.List<Postulacion> postulaciones, String estado) {
        return (int) postulaciones.stream().filter(p -> estado.equals(p.getEstado())).count();
    }

    private void tarjetas(String[] titulos, int[] valores) {
        Label[] etiquetas = {stat1Titulo, stat2Titulo, stat3Titulo, stat4Titulo, stat5Titulo, stat6Titulo};
        Label[] numeros = {stat1Valor, stat2Valor, stat3Valor, stat4Valor, stat5Valor, stat6Valor};
        for (int i = 0; i < etiquetas.length; i++) {
            etiquetas[i].setText(titulos[i]);
            numeros[i].setText(Integer.toString(valores[i]));
        }
    }

    private void mostrarActividad(java.util.List<Postulacion> postulaciones) {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String texto = postulaciones.stream().sorted(Comparator.comparing(Postulacion::getFechaPostulacion).reversed()).limit(6)
                .map(p -> "• " + p.getFechaPostulacion().format(formato) + "  " + p.getTrabajadorNombre() + " — " + p.getOfertaCargo() + " · " + p.getEstado())
                .collect(java.util.stream.Collectors.joining("\n"));
        actividadLabel.setText(texto.isBlank() ? "Todavía no hay actividad de selección." : texto);
    }

    private void mostrarOfertas(java.util.List<OfertaLaboral> ofertas) {
        String texto = ofertas.stream().filter(OfertaLaboral::isActiva)
                .filter(o -> usuario.getRol() != RolUsuario.EMPRESA || o.getEmpresaId().equals(usuario.getId()))
                .sorted(Comparator.comparing(OfertaLaboral::getFechaPublicacion).reversed()).limit(5)
                .map(o -> "• " + o.getCargo() + " — " + o.getEmpresaNombre() + " · " + o.getUbicacion())
                .collect(java.util.stream.Collectors.joining("\n"));
        ofertasLabel.setText(texto.isBlank() ? "No hay ofertas activas para mostrar." : texto);
    }

    private void actualizarGrafico(java.util.List<Postulacion> postulaciones) {
        EnumMap<co.conectaempleo.model.EstadoPostulacion, Integer> conteo = new EnumMap<>(co.conectaempleo.model.EstadoPostulacion.class);
        postulaciones.stream().filter(p -> !"Retirada".equals(p.getEstado())).forEach(p -> conteo.merge(p.getEstadoEnum(), 1, Integer::sum));
        var datos = FXCollections.<PieChart.Data>observableArrayList();
        conteo.forEach((estado, cantidad) -> datos.add(new PieChart.Data(estado.getEtiqueta() + " · " + cantidad, cantidad)));
        estadosChart.setData(datos);
        estadosChart.setTitle("Procesos por estado");
    }

    @FXML private void abrirAcceso1() { navegar(1); }
    @FXML private void abrirAcceso2() { navegar(2); }
    @FXML private void abrirAcceso3() { navegar(3); }
    private void navegar(int indice) { ModuloGestion destino = destinos.get(indice); if (destino != null) navegacion.accept(destino); }

    @FXML private void restaurarDemo() {
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION,
                "Se reemplazarán los registros de demostración; los datos reales se conservarán.", ButtonType.OK, ButtonType.CANCEL);
        confirmacion.setTitle("Restaurar demostración"); confirmacion.setHeaderText("¿Restaurar los datos de ejemplo?");
        if (confirmacion.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;
        try {
            servicio.restaurarDatosDemostracion(usuario);
            refrescar();
            new Alert(Alert.AlertType.INFORMATION, "Los datos de demostración fueron restaurados.", ButtonType.OK).showAndWait();
        } catch (RuntimeException ex) {
            new Alert(Alert.AlertType.ERROR, ex.getMessage(), ButtonType.OK).showAndWait();
        }
    }
}
