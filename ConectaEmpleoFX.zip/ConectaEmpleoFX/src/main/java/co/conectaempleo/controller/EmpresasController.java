package co.conectaempleo.controller;

import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public final class EmpresasController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private Button nuevaButton, editarButton, eliminarButton;

    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.EMPRESAS,
                "NIT", "Nombre comercial", "Usuario", "Sector", "Correo", "Teléfono", "Dirección", "Ofertas", "Origen");
        nuevaButton.setVisible(actor.getRol() == RolUsuario.ADMINISTRADOR);
        editarButton.setVisible(actor.getRol() == RolUsuario.ADMINISTRADOR || actor.getRol() == RolUsuario.EMPRESA);
        eliminarButton.setVisible(actor.getRol() == RolUsuario.ADMINISTRADOR);
        cargarTabla();
    }
    private void cargarTabla() { cargar(tabla, filtroField, resultadoLabel, ModuloGestion.EMPRESAS); }
    @FXML private void actualizarTabla() { cargarTabla(); }

    @FXML private void registrarEmpresa() {
        List<String> campos = List.of("NIT", "Nombre comercial", "Usuario", "Contraseña", "Sector", "Dirección (opcional)", "Teléfono (opcional)", "Correo electrónico", "Descripción (opcional)");
        pedirDatos("Registrar empresa", campos, null, ModuloGestion.EMPRESAS).ifPresent(datos -> ejecutar(
                () -> servicio.crear(ModuloGestion.EMPRESAS, datos, actor), this::cargarTabla, "La empresa fue registrada."));
    }

    @FXML private void editarEmpresa() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try {
            List<String> campos = List.of("NIT", "Nombre comercial", "Usuario", "Contraseña (vacío conserva la actual)", "Sector", "Dirección (opcional)", "Teléfono (opcional)", "Correo electrónico", "Descripción (opcional)");
            pedirDatos("Editar empresa", campos, servicio.obtenerCamposFormulario(ModuloGestion.EMPRESAS, fila.getId(), actor), ModuloGestion.EMPRESAS)
                    .ifPresent(datos -> ejecutar(() -> servicio.actualizar(ModuloGestion.EMPRESAS, fila.getId(), datos, actor), this::cargarTabla, "Los datos fueron actualizados."));
        } catch (RuntimeException ex) { error(ex.getMessage()); }
    }

    @FXML private void verDetalles() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Empresa empresa = servicio.buscarEmpresa(fila.getId()); if (empresa == null) return;
        long ofertas = servicio.listarOfertas().stream().filter(x -> x.getEmpresaId().equals(empresa.getId())).count();
        verDetalle(empresa.getNombre(), "NIT: " + empresa.getNit() + "\nSector: " + empresa.getSector() + "\nCorreo: " + empresa.getCorreo()
                + "\nTeléfono: " + empresa.getTelefono() + "\nDirección: " + empresa.getDireccion()
                + "\nOfertas publicadas e históricas: " + ofertas + "\n\n" + empresa.getDescripcion());
    }

    @FXML private void consultarOfertas() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Empresa empresa = servicio.buscarEmpresa(fila.getId());
        var ofertas = servicio.listarOfertas().stream().filter(x -> x.getEmpresaId().equals(fila.getId()))
                .map(x -> "• " + x.getCargo() + " — " + (x.isActiva() ? "Publicada" : "Cerrada"))
                .collect(java.util.stream.Collectors.joining("\n"));
        verDetalle("Ofertas de " + empresa.getNombre(), ofertas.isBlank() ? "Esta empresa todavía no tiene ofertas." : ofertas);
    }

    @FXML private void eliminarEmpresa() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Eliminar empresa", "¿Confirmas la eliminación? Las empresas con ofertas históricas se conservarán.")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.EMPRESAS, fila.getId(), actor); } catch (Exception ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "El registro fue eliminado.");
    }
}
