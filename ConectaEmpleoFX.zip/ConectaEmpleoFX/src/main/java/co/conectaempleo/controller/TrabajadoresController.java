package co.conectaempleo.controller;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

public final class TrabajadoresController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private Button nuevoButton, editarButton, eliminarButton, adjuntarButton, abrirButton;

    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.TRABAJADORES,
                "Iniciales", "Cédula", "Nombre", "Usuario", "Correo", "Teléfono", "Ubicación", "Habilidades", "Disponibilidad", "Origen");
        nuevoButton.setVisible(actor.getRol() == RolUsuario.ADMINISTRADOR);
        editarButton.setVisible(actor.getRol() == RolUsuario.ADMINISTRADOR || actor.getRol() == RolUsuario.TRABAJADOR);
        eliminarButton.setVisible(actor.getRol() == RolUsuario.ADMINISTRADOR);
        adjuntarButton.setVisible(actor instanceof Trabajador);
        cargarTabla();
    }
    private void cargarTabla() { cargar(tabla, filtroField, resultadoLabel, ModuloGestion.TRABAJADORES); }
    @FXML private void actualizarTabla() { cargarTabla(); }

    @FXML private void nuevoTrabajador() {
        List<String> etiquetas = List.of("Cédula", "Nombre", "Usuario", "Contraseña", "Correo (opcional)", "Teléfono (opcional)", "Ubicación (opcional)", "Perfil profesional (opcional)", "Habilidades separadas por coma", "Disponibilidad");
        pedirDatos("Registrar trabajador", etiquetas, null, ModuloGestion.TRABAJADORES).ifPresent(datos -> ejecutar(
                () -> servicio.crear(ModuloGestion.TRABAJADORES, datos, actor), this::cargarTabla, "El perfil fue registrado."));
    }

    @FXML private void editarTrabajador() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try {
            var valores = servicio.obtenerCamposFormulario(ModuloGestion.TRABAJADORES, fila.getId(), actor);
            List<String> etiquetas = List.of("Cédula", "Nombre", "Usuario", "Contraseña (vacío conserva la actual)", "Correo (opcional)", "Teléfono (opcional)", "Ubicación (opcional)", "Perfil profesional (opcional)", "Habilidades separadas por coma", "Disponibilidad");
            pedirDatos("Editar perfil", etiquetas, valores, ModuloGestion.TRABAJADORES).ifPresent(datos -> ejecutar(
                    () -> servicio.actualizar(ModuloGestion.TRABAJADORES, fila.getId(), datos, actor), this::cargarTabla, "El perfil fue actualizado."));
        } catch (RuntimeException ex) { error(ex.getMessage()); }
    }

    @FXML private void verPerfil() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Trabajador t = servicio.buscarTrabajador(fila.getId()); if (t == null) return;
        verDetalle("Perfil de " + t.getNombre(), "Documento: " + t.getCedula() + "\nCorreo: " + t.getCorreo()
                + "\nTeléfono: " + t.getTelefono() + "\nUbicación: " + t.getUbicacion()
                + "\nDisponibilidad: " + t.getDisponibilidad() + "\nHabilidades: " + String.join(", ", t.getHabilidades())
                + "\n\nPerfil profesional:\n" + t.getPerfilProfesional());
    }

    @FXML private void eliminarTrabajador() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Eliminar trabajador", "¿Confirmas la eliminación? Los perfiles con historial asociado se conservarán.")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.TRABAJADORES, fila.getId(), actor); } catch (IOException ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "El registro fue eliminado.");
    }

    @FXML private void adjuntarCV() {
        FileChooser chooser = new FileChooser(); chooser.setTitle("Seleccionar hoja de vida");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        File archivo = chooser.showOpenDialog(tabla.getScene().getWindow()); if (archivo == null) return;
        if (servicio.tieneDocumento(actor.getId()) && !confirmar("Reemplazar hoja de vida", "La versión anterior será reemplazada.")) return;
        try { servicio.gestionarHojaVida(archivo.toPath(), actor); cargarTabla(); verDetalle("Documento guardado", "La hoja de vida PDF quedó asociada a tu perfil."); }
        catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }

    @FXML private void abrirCV() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try { servicio.abrirDocumento(fila.getId(), actor); }
        catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }
}
