package co.conectaempleo.controller;

import co.conectaempleo.app.ConectaEmpleoApp;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Usuario;
import java.io.IOException;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

/** Controlador MVC de la pantalla de acceso. */
public final class LoginController {
    @FXML private RadioButton administradorRadio;
    @FXML private RadioButton empresaRadio;
    @FXML private RadioButton trabajadorRadio;
    @FXML private TextField nombreUsuarioField;
    @FXML private PasswordField claveField;
    @FXML private TextField claveVisibleField;
    @FXML private CheckBox mostrarClaveCheck;
    @FXML private Label mensajeError;
    private ConectaEmpleoApp app;

    public void setApp(ConectaEmpleoApp app) { this.app = app; }

    @FXML private void alternarVisibilidadClave() {
        boolean mostrar = mostrarClaveCheck.isSelected();
        if (mostrar) claveVisibleField.setText(claveField.getText());
        else claveField.setText(claveVisibleField.getText());
        claveField.setManaged(!mostrar); claveField.setVisible(!mostrar);
        claveVisibleField.setManaged(mostrar); claveVisibleField.setVisible(mostrar);
        (mostrar ? claveVisibleField : claveField).requestFocus();
    }

    @FXML private void iniciarSesion() {
        mostrarError("");
        String clave = mostrarClaveCheck.isSelected() ? claveVisibleField.getText() : claveField.getText();
        Optional<Usuario> usuario = app.getServicio().autenticacion().autenticar(
                nombreUsuarioField.getText(), clave, obtenerRolSeleccionado());
        if (usuario.isEmpty()) {
            mostrarError("No se encontró una cuenta con esos datos y el perfil seleccionado.");
            return;
        }
        try { app.mostrarInicio(usuario.get()); }
        catch (IOException ex) { mostrarError("No se pudo cargar el espacio de trabajo: " + ex.getMessage()); }
    }

    private RolUsuario obtenerRolSeleccionado() {
        if (empresaRadio.isSelected()) return RolUsuario.EMPRESA;
        if (trabajadorRadio.isSelected()) return RolUsuario.TRABAJADOR;
        return RolUsuario.ADMINISTRADOR;
    }

    private void mostrarError(String texto) {
        mensajeError.setText(texto);
        boolean visible = !texto.isBlank();
        mensajeError.setVisible(visible);
        mensajeError.setManaged(visible);
    }
}
