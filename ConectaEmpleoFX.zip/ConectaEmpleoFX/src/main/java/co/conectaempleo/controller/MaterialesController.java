package co.conectaempleo.controller;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;

public final class MaterialesController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private FlowPane categoriasPane;
    @FXML private ChoiceBox<String> categoriaFiltro;
    @FXML private Button nuevoButton, editarButton, eliminarButton;
    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.MATERIALES,
                "Material", "Categoría", "Cantidad", "Unidad", "Ubicación", "Disponibilidad", "Descripción", "Origen");
        categoriaFiltro.getItems().setAll("Todas");
        servicio.listarMateriales().forEach(x -> { if (!categoriaFiltro.getItems().contains(x.getCategoria())) categoriaFiltro.getItems().add(x.getCategoria()); });
        categoriaFiltro.getSelectionModel().selectFirst();
        categoriaFiltro.getSelectionModel().selectedItemProperty().addListener((o,a,b) -> cargarTabla());
        boolean admin = actor.getRol() == RolUsuario.ADMINISTRADOR;
        nuevoButton.setVisible(admin); editarButton.setVisible(admin); eliminarButton.setVisible(admin); cargarTabla();
    }
    private void cargarTabla() {
        actualizarTarjetas();
        cargar(tabla, filtroField, resultadoLabel, ModuloGestion.MATERIALES);
        if (!"Todas".equals(categoriaFiltro.getValue())) tabla.getItems().removeIf(x -> !x.getCelda(1).equals(categoriaFiltro.getValue()));
        resultadoLabel.setText(tabla.getItems().size() + " materiales");
    }

    private void actualizarTarjetas() {
        categoriasPane.getChildren().clear();
        servicio.listarMateriales().stream().collect(java.util.stream.Collectors.groupingBy(
                co.conectaempleo.model.MaterialReciclable::getCategoria, java.util.TreeMap::new, java.util.stream.Collectors.toList()))
                .forEach((categoria, registros) -> {
                    VBox tarjeta = new VBox(6);
                    tarjeta.getStyleClass().add("material-category-card");
                    Label nombre = new Label(categoria); nombre.getStyleClass().add("card-title");
                    Label cantidad = new Label(registros.size() + " registros"); cantidad.getStyleClass().add("muted-text");
                    tarjeta.getChildren().addAll(nombre, cantidad);
                    tarjeta.setOnMouseClicked(event -> categoriaFiltro.getSelectionModel().select(categoria));
                    categoriasPane.getChildren().add(tarjeta);
                });
    }
    @FXML private void actualizarTabla() { cargarTabla(); }
    private List<String> etiquetas() { return List.of("Nombre", "Categoría", "Cantidad", "Unidad", "Ubicación", "Estado o disponibilidad", "Descripción"); }
    @FXML private void nuevoMaterial() {
        pedirDatos("Registrar material reciclable", etiquetas(), null, ModuloGestion.MATERIALES).ifPresent(datos -> ejecutar(
                () -> servicio.crear(ModuloGestion.MATERIALES, datos, actor), this::cargarTabla, "El material fue registrado."));
    }
    @FXML private void editarMaterial() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try { pedirDatos("Editar material", etiquetas(), servicio.obtenerCamposFormulario(ModuloGestion.MATERIALES, fila.getId(), actor), ModuloGestion.MATERIALES)
                .ifPresent(datos -> ejecutar(() -> servicio.actualizar(ModuloGestion.MATERIALES, fila.getId(), datos, actor), this::cargarTabla, "El material fue actualizado.")); }
        catch (RuntimeException ex) { error(ex.getMessage()); }
    }
    @FXML private void eliminarMaterial() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Eliminar material", "¿Eliminar este registro del inventario?")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.MATERIALES, fila.getId(), actor); } catch (Exception ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "El material fue eliminado.");
    }
}
