package co.conectaempleo.controller;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

/** Utilidades compartidas de presentación; cada módulo conserva su propio controlador y eventos. */
abstract class ControladorModuloBase {
    protected ServicioConectaEmpleo servicio;
    protected Usuario actor;

    protected void configurarBase(ServicioConectaEmpleo servicio, Usuario actor) {
        this.servicio = servicio;
        this.actor = actor;
    }

    protected void prepararTabla(TableView<FilaModulo> tabla, TextField filtro, Label conteo,
                                 ModuloGestion modulo, String... encabezados) {
        tabla.getColumns().clear();
        for (int i = 0; i < encabezados.length; i++) {
            int indice = i; // El identificador de acciones se conserva aparte, en FilaModulo.getId().
            TableColumn<FilaModulo, String> columna = new TableColumn<>(encabezados[i]);
            columna.setCellValueFactory(celda -> new ReadOnlyStringWrapper(
                    indice < celda.getValue().cantidadCeldas() ? celda.getValue().getCelda(indice) : ""));
            columna.setMinWidth(90);
            tabla.getColumns().add(columna);
        }
        tabla.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        tabla.setPlaceholder(new Label("No hay registros para mostrar."));
        filtro.textProperty().addListener((obs, antes, ahora) -> cargar(tabla, filtro, conteo, modulo));
    }

    protected void cargar(TableView<FilaModulo> tabla, TextField filtro, Label conteo, ModuloGestion modulo) {
        try {
            tabla.setItems(FXCollections.observableArrayList(servicio.listar(modulo, actor, filtro.getText())));
            conteo.setText(tabla.getItems().size() + " registros");
        } catch (RuntimeException ex) {
            error(ex.getMessage());
        }
    }

    protected FilaModulo seleccionada(TableView<FilaModulo> tabla) {
        FilaModulo seleccion = tabla.getSelectionModel().getSelectedItem();
        if (seleccion == null) error("Selecciona primero un registro.");
        return seleccion;
    }

    protected Optional<ArrayList<String>> pedirDatos(String titulo, List<String> etiquetas,
                                                     List<String> valores, ModuloGestion modulo) {
        Dialog<ArrayList<String>> dialogo = new Dialog<>();
        dialogo.setTitle(titulo);
        dialogo.setHeaderText("Completa los datos requeridos");
        ButtonType guardar = new ButtonType("Guardar", ButtonBar.ButtonData.OK_DONE);
        dialogo.getDialogPane().getButtonTypes().addAll(guardar, ButtonType.CANCEL);
        GridPane formulario = new GridPane();
        formulario.setHgap(12);
        formulario.setVgap(10);
        formulario.setPrefWidth(550);
        ArrayList<javafx.scene.control.Control> controles = new ArrayList<>();
        for (int i = 0; i < etiquetas.size(); i++) {
            String etiqueta = etiquetas.get(i);
            javafx.scene.control.Control control;
            if (modulo == ModuloGestion.OFERTAS && i == 8
                    || modulo == ModuloGestion.CAPACITACIONES && i == 5) {
                DatePicker fecha = new DatePicker();
                fecha.setPromptText("Fecha límite");
                if (valores != null && i < valores.size() && !valores.get(i).isBlank()) {
                    try { fecha.setValue(java.time.LocalDate.parse(valores.get(i))); } catch (RuntimeException ignored) { }
                }
                control = fecha;
            } else if (modulo == ModuloGestion.OFERTAS && i == 6) {
                ChoiceBox<String> opciones = new ChoiceBox<>();
                opciones.getItems().setAll("Tiempo completo", "Medio tiempo", "Por turnos", "Temporal");
                opciones.getSelectionModel().selectFirst();
                control = opciones;
            } else if (modulo == ModuloGestion.CAPACITACIONES && i == 7) {
                ChoiceBox<String> opciones = new ChoiceBox<>(); opciones.getItems().setAll("Disponible", "Cerrada"); opciones.getSelectionModel().selectFirst(); control = opciones;
            } else if (modulo == ModuloGestion.MATERIALES && i == 5) {
                ChoiceBox<String> opciones = new ChoiceBox<>(); opciones.getItems().setAll("Disponible", "Reservado", "Agotado"); opciones.getSelectionModel().selectFirst(); control = opciones;
            } else if (etiqueta.toLowerCase(java.util.Locale.ROOT).startsWith("contraseña")) {
                PasswordField campo = new PasswordField();
                campo.setPromptText(etiqueta);
                control = campo;
            } else if (etiqueta.toLowerCase(java.util.Locale.ROOT).contains("descripción")
                    || etiqueta.toLowerCase(java.util.Locale.ROOT).contains("perfil profesional")
                    || etiqueta.toLowerCase(java.util.Locale.ROOT).contains("requisitos")) {
                TextArea area = new TextArea();
                area.setPrefRowCount(3);
                area.setWrapText(true);
                control = area;
            } else {
                TextField campo = new TextField();
                campo.setPromptText(etiqueta.replace(" (opcional)", ""));
                control = campo;
            }
            if (valores != null && i < valores.size()) {
                if (control instanceof TextField campo) campo.setText(valores.get(i));
                if (control instanceof TextArea area) area.setText(valores.get(i));
                if (control instanceof ChoiceBox<?> opciones) {
                    int indice = opciones.getItems().indexOf(valores.get(i));
                    if (indice >= 0) opciones.getSelectionModel().select(indice);
                }
            }
            if (modulo == ModuloGestion.OFERTAS && i == 0 && actor instanceof co.conectaempleo.model.Empresa) {
                if (control instanceof TextField campo) campo.setText(actor.getId());
                control.setDisable(true);
            }
            formulario.add(new Label(etiqueta.replace(" (separadas por coma)", "")), 0, i);
            formulario.add(control, 1, i);
            controles.add(control);
        }
        dialogo.getDialogPane().setContent(formulario);
        dialogo.setResultConverter(boton -> {
            if (boton != guardar) return null;
            ArrayList<String> resultado = new ArrayList<>();
            for (javafx.scene.control.Control control : controles) {
                if (control instanceof TextField campo) resultado.add(campo.getText().trim());
                else if (control instanceof TextArea area) resultado.add(area.getText().trim());
                else if (control instanceof DatePicker fecha) resultado.add(fecha.getValue() == null ? "" : fecha.getValue().toString());
                else if (control instanceof ChoiceBox<?> opciones) resultado.add(opciones.getValue() == null ? "" : opciones.getValue().toString());
            }
            return resultado;
        });
        return dialogo.showAndWait();
    }

    protected void verDetalle(String titulo, String contenido) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("ConectaEmpleo");
        alerta.setHeaderText(titulo);
        alerta.setContentText(contenido);
        alerta.getDialogPane().setPrefWidth(560);
        alerta.showAndWait();
    }

    protected boolean confirmar(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alerta.setTitle("Confirmar acción");
        alerta.setHeaderText(titulo);
        return alerta.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK;
    }

    protected void error(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("ConectaEmpleo");
        alerta.setHeaderText("No se pudo completar la acción");
        alerta.setContentText(mensaje == null ? "Ocurrió un error inesperado." : mensaje);
        alerta.showAndWait();
    }

    protected void ejecutar(Runnable accion, Runnable refrescar, String mensaje) {
        try {
            accion.run();
            refrescar.run();
            verDetalle("Acción completada", mensaje);
        } catch (RuntimeException ex) {
            error(ex.getMessage());
        }
    }
}
