package co.conectaempleo.controller;

import co.conectaempleo.app.ConectaEmpleoApp;
import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.Usuario;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/** Controlador del marco de navegación y sus permisos por rol. */
public final class ShellController {
    @FXML private Label usuarioLabel;
    @FXML private Label rolLabel;
    @FXML private StackPane contentArea;
    @FXML private Button trabajadoresButton;
    @FXML private Button empresasButton;
    @FXML private Button ofertasButton;
    @FXML private Button postulacionesButton;
    @FXML private Button habilidadesButton;
    @FXML private Button capacitacionesButton;
    @FXML private Button materialesButton;
    @FXML private Button documentosButton;

    private ConectaEmpleoApp app;
    private Usuario usuario;

    public void configurar(ConectaEmpleoApp app, Usuario usuario) {
        this.app = app;
        this.usuario = usuario;
        usuarioLabel.setText(usuario.getNombre());
        rolLabel.setText(usuario.getRol().getEtiqueta());
        configurarPermisos();
        mostrarDashboard();
    }

    private void configurarPermisos() {
        configurarBoton(trabajadoresButton, ModuloGestion.TRABAJADORES);
        configurarBoton(empresasButton, ModuloGestion.EMPRESAS);
        configurarBoton(ofertasButton, ModuloGestion.OFERTAS);
        configurarBoton(postulacionesButton, ModuloGestion.POSTULACIONES);
        configurarBoton(habilidadesButton, ModuloGestion.HABILIDADES);
        configurarBoton(capacitacionesButton, ModuloGestion.CAPACITACIONES);
        configurarBoton(materialesButton, ModuloGestion.MATERIALES);
        configurarBoton(documentosButton, ModuloGestion.DOCUMENTOS);
    }

    private void configurarBoton(Button boton, ModuloGestion modulo) {
        boolean visible = modulo.permite(usuario.getRol());
        boton.setVisible(visible);
        boton.setManaged(visible);
    }

    @FXML private void mostrarDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/dashboard-view.fxml"));
            Parent vista = loader.load();
            DashboardController controller = loader.getController();
            controller.configurar(app.getServicio(), usuario, this::mostrarModulo);
            contentArea.getChildren().setAll(vista);
        } catch (IOException ex) { mostrarError("No se pudo abrir el panel de inicio.", ex); }
    }

    private void mostrarModulo(ModuloGestion modulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaVista(modulo)));
            Parent vista = loader.load();
            if (vista instanceof javafx.scene.layout.Region region) {
                region.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            }
            Object controller = loader.getController();
            configurarControlador(modulo, controller);
            contentArea.getChildren().setAll(vista);
        } catch (IOException | RuntimeException ex) { mostrarError("No se pudo abrir " + modulo.getTitulo() + ".", ex); }
    }

    private void configurarControlador(ModuloGestion modulo, Object controller) {
        switch (modulo) {
            case TRABAJADORES -> ((TrabajadoresController) controller).configurar(app.getServicio(), usuario);
            case EMPRESAS -> ((EmpresasController) controller).configurar(app.getServicio(), usuario);
            case OFERTAS -> ((OfertasController) controller).configurar(app.getServicio(), usuario);
            case POSTULACIONES -> ((PostulacionesController) controller).configurar(app.getServicio(), usuario);
            case HABILIDADES -> ((HabilidadesController) controller).configurar(app.getServicio(), usuario);
            case CAPACITACIONES -> ((CapacitacionesController) controller).configurar(app.getServicio(), usuario);
            case MATERIALES -> ((MaterialesController) controller).configurar(app.getServicio(), usuario);
            case DOCUMENTOS -> ((DocumentosController) controller).configurar(app.getServicio(), usuario);
        }
    }

    private static String rutaVista(ModuloGestion modulo) {
        return switch (modulo) {
            case TRABAJADORES -> "/fxml/trabajadores-view.fxml";
            case EMPRESAS -> "/fxml/empresas-view.fxml";
            case OFERTAS -> "/fxml/ofertas-view.fxml";
            case POSTULACIONES -> "/fxml/postulaciones-view.fxml";
            case HABILIDADES -> "/fxml/habilidades-view.fxml";
            case CAPACITACIONES -> "/fxml/capacitaciones-view.fxml";
            case MATERIALES -> "/fxml/materiales-view.fxml";
            case DOCUMENTOS -> "/fxml/documentos-view.fxml";
        };
    }

    @FXML private void mostrarTrabajadores() { mostrarModulo(ModuloGestion.TRABAJADORES); }
    @FXML private void mostrarEmpresas() { mostrarModulo(ModuloGestion.EMPRESAS); }
    @FXML private void mostrarOfertas() { mostrarModulo(ModuloGestion.OFERTAS); }
    @FXML private void mostrarPostulaciones() { mostrarModulo(ModuloGestion.POSTULACIONES); }
    @FXML private void mostrarHabilidades() { mostrarModulo(ModuloGestion.HABILIDADES); }
    @FXML private void mostrarCapacitaciones() { mostrarModulo(ModuloGestion.CAPACITACIONES); }
    @FXML private void mostrarMateriales() { mostrarModulo(ModuloGestion.MATERIALES); }
    @FXML private void mostrarDocumentos() { mostrarModulo(ModuloGestion.DOCUMENTOS); }

    @FXML private void cerrarSesion() {
        try { app.mostrarLogin(); }
        catch (IOException ex) { mostrarError("No se pudo volver al inicio de sesión.", ex); }
    }

    private void mostrarError(String titulo, Exception ex) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("ConectaEmpleo");
        alerta.setHeaderText(titulo);
        alerta.setContentText(ex.getMessage());
        alerta.showAndWait();
    }
}
