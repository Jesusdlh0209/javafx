package co.conectaempleo.controller;

import co.conectaempleo.model.Habilidad;
import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public final class HabilidadesController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private Button nuevaButton, editarButton, eliminarButton, asociarButton, trabajadoresButton;
    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.HABILIDADES, "Habilidad", "Categoría", "Origen");
        boolean admin = actor.getRol() == RolUsuario.ADMINISTRADOR;
        nuevaButton.setVisible(admin); editarButton.setVisible(admin); eliminarButton.setVisible(admin);
        trabajadoresButton.setVisible(admin);
        asociarButton.setVisible(actor.getRol() == RolUsuario.TRABAJADOR); cargarTabla();
    }
    private void cargarTabla() { cargar(tabla, filtroField, resultadoLabel, ModuloGestion.HABILIDADES); }
    @FXML private void actualizarTabla() { cargarTabla(); }
    @FXML private void registrarHabilidad() {
        pedirDatos("Nueva habilidad", List.of("Nombre de la habilidad", "Categoría"), null, ModuloGestion.HABILIDADES)
                .ifPresent(datos -> ejecutar(() -> servicio.crear(ModuloGestion.HABILIDADES, datos, actor), this::cargarTabla, "La habilidad fue registrada."));
    }
    @FXML private void editarHabilidad() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try { pedirDatos("Editar habilidad", List.of("Nombre de la habilidad", "Categoría"),
                servicio.obtenerCamposFormulario(ModuloGestion.HABILIDADES, fila.getId(), actor), ModuloGestion.HABILIDADES)
                .ifPresent(datos -> ejecutar(() -> servicio.actualizar(ModuloGestion.HABILIDADES, fila.getId(), datos, actor), this::cargarTabla, "La habilidad fue actualizada.")); }
        catch (RuntimeException ex) { error(ex.getMessage()); }
    }
    @FXML private void eliminarHabilidad() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Eliminar habilidad", "¿Eliminar esta habilidad del catálogo? Los perfiles conservarán sus textos ya guardados.")) return;
        ejecutar(() -> { try { servicio.eliminar(ModuloGestion.HABILIDADES, fila.getId(), actor); } catch (Exception ex) { throw new IllegalStateException(ex.getMessage(), ex); } }, this::cargarTabla, "Habilidad eliminada.");
    }
    @FXML private void asociarMiPerfil() {
        FilaModulo fila = seleccionada(tabla); if (fila != null) ejecutar(() -> servicio.agregarHabilidadPerfil(fila.getId(), actor), this::cargarTabla, "Habilidad añadida a tu perfil.");
    }
    @FXML private void consultarTrabajadores() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        Habilidad habilidad = servicio.listarHabilidades().stream().filter(x -> x.getId().equals(fila.getId())).findFirst().orElse(null);
        if (habilidad == null) return;
        String asociados = servicio.listarTrabajadores().stream().filter(x -> x.getHabilidades().stream().anyMatch(h -> h.equalsIgnoreCase(habilidad.getNombre())))
                .map(x -> "• " + x.getNombre() + " — " + x.getUbicacion()).collect(java.util.stream.Collectors.joining("\n"));
        verDetalle("Trabajadores con " + habilidad.getNombre(), asociados.isBlank() ? "No hay perfiles asociados." : asociados);
    }
}
