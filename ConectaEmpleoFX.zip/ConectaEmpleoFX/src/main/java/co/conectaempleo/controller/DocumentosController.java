package co.conectaempleo.controller;

import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.services.AnalisisHojaVida;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.viewmodel.FilaModulo;
import java.io.File;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

public final class DocumentosController extends ControladorModuloBase {
    @FXML private Label resultadoLabel;
    @FXML private TextField filtroField;
    @FXML private TableView<FilaModulo> tabla;
    @FXML private Button adjuntarButton, analizarButton, abrirButton, eliminarButton;
    public void configurar(ServicioConectaEmpleo servicio, co.conectaempleo.model.Usuario actor) {
        configurarBase(servicio, actor);
        prepararTabla(tabla, filtroField, resultadoLabel, ModuloGestion.DOCUMENTOS,
                "Trabajador", "Documento", "Hoja de vida PDF", "Origen");
        adjuntarButton.setVisible(actor instanceof Trabajador);
        boolean permitido = actor.getRol() == RolUsuario.ADMINISTRADOR || actor instanceof Trabajador;
        analizarButton.setVisible(permitido); abrirButton.setVisible(permitido); eliminarButton.setVisible(permitido); cargarTabla();
    }
    private void cargarTabla() { cargar(tabla, filtroField, resultadoLabel, ModuloGestion.DOCUMENTOS); }
    @FXML private void actualizarTabla() { cargarTabla(); }
    @FXML private void adjuntarDocumento() {
        FileChooser chooser = new FileChooser(); chooser.setTitle("Seleccionar hoja de vida PDF");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Documento PDF", "*.pdf"));
        File archivo = chooser.showOpenDialog(tabla.getScene().getWindow()); if (archivo == null) return;
        if (servicio.tieneDocumento(actor.getId()) && !confirmar("Reemplazar hoja de vida", "El archivo anterior será sustituido.")) return;
        try { servicio.gestionarHojaVida(archivo.toPath(), actor); cargarTabla(); verDetalle("Documento guardado", "El PDF quedó vinculado a tu perfil."); }
        catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }
    @FXML private void abrirDocumento() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try { servicio.abrirDocumento(fila.getId(), actor); }
        catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }
    @FXML private void analizarDocumento() {
        FilaModulo fila = seleccionada(tabla); if (fila == null) return;
        try {
            AnalisisHojaVida analisis = servicio.analizarDocumento(fila.getId(), actor);
            String habilidades = analisis.habilidadesSugeridas().isEmpty() ? "No se detectaron habilidades del catálogo." : String.join(", ", analisis.habilidadesSugeridas());
            verDetalle("Análisis local con PDFBox", "Archivo: " + analisis.nombreArchivo() + "\nPáginas: " + analisis.paginas()
                    + "\nTítulo: " + (analisis.titulo().isBlank() ? "Sin título en metadatos" : analisis.titulo())
                    + "\nCaracteres de texto: " + analisis.caracteresExtraidos() + "\nHabilidades sugeridas: " + habilidades
                    + "\n\nLas sugerencias son una ayuda; no se guardan en el perfil automáticamente.");
        } catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }
    @FXML private void eliminarDocumento() {
        FilaModulo fila = seleccionada(tabla); if (fila == null || !confirmar("Eliminar hoja de vida", "¿Eliminar el archivo PDF asociado a este perfil?")) return;
        try { servicio.eliminarDocumento(fila.getId(), actor); cargarTabla(); }
        catch (IOException | RuntimeException ex) { error(ex.getMessage()); }
    }
}
