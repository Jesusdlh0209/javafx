package co.conectaempleo.viewmodel;

import java.util.ArrayList;
import java.util.List;

/** Proyección de lectura para presentar entidades en una tabla JavaFX. */
public final class FilaModulo {
    private final String id;
    private final ArrayList<String> celdas;

    public FilaModulo(String id, List<String> celdas) {
        this.id = id;
        this.celdas = new ArrayList<>(celdas);
    }

    public String getId() { return id; }
    public String getCelda(int indice) { return celdas.get(indice); }
    public int cantidadCeldas() { return celdas.size(); }
}
