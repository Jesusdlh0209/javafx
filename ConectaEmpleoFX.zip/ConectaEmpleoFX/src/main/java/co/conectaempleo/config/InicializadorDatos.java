package co.conectaempleo.config;

import co.conectaempleo.model.Administrador;
import co.conectaempleo.model.Capacitacion;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.Habilidad;
import co.conectaempleo.model.MaterialReciclable;
import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.Postulacion;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import co.conectaempleo.services.DocumentoService;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Crea registros ficticios identificados solo al instalar o restaurar la demo. */
public final class InicializadorDatos {
    private InicializadorDatos() { }

    public static void cargarSiEsNecesario(RepositorioLocal repo) {
        if (repo.requiereInicializarDemostracion()) sembrar(repo);
    }

    public static void restaurarDemostracion(RepositorioLocal repo) {
        Usuario administrador = repo.listarUsuarios().stream()
                .filter(x -> x instanceof Administrador).findFirst()
                .orElseThrow(() -> new IllegalStateException("No se encontró una cuenta administradora para restaurar la demostración."));
        DocumentoService documentos = new DocumentoService(repo);
        for (Trabajador trabajador : repo.listarTrabajadores()) {
            if (!trabajador.isDemo()) continue;
            documentos.migrarRutaLegada(trabajador);
            if (!documentos.tieneDocumento(trabajador.getId())) continue;
            try { documentos.eliminar(trabajador.getId(), administrador); }
            catch (IOException ex) { throw new IllegalStateException("No se pudo quitar un PDF de demostración: " + ex.getMessage(), ex); }
        }
        repo.eliminarDatosDemostracion();
        sembrar(repo);
    }

    private static void sembrar(RepositorioLocal repo) {
        Administrador admin = new Administrador("ADM-001", "Administrador Demo", "admin", "admin");
        admin.setDemo(true);
        repo.guardarUsuario(admin);

        String[][] empresaDatos = {
            {"EMP-DEMO-01", "EcoVerde Cartagena", "empresa01", "900000001", "Reciclaje y aprovechamiento", "Zona Industrial de Mamonal", "000-000-0101", "empresa01@example.invalid", "Recolección y clasificación de plásticos posconsumo."},
            {"EMP-DEMO-02", "Circular del Caribe", "empresa02", "900000002", "Economía circular", "Barrio El Bosque", "000-000-0102", "empresa02@example.invalid", "Transformación de residuos en nuevos insumos."},
            {"EMP-DEMO-03", "Logística Reutiliza", "empresa03", "900000003", "Logística sostenible", "Zona Portuaria", "000-000-0103", "empresa03@example.invalid", "Operación logística para materiales recuperables."},
            {"EMP-DEMO-04", "Vidrio Vivo", "empresa04", "900000004", "Reutilización de vidrio", "Sector La Boquilla", "000-000-0104", "empresa04@example.invalid", "Recuperación, selección y reutilización de envases."},
            {"EMP-DEMO-05", "Metales Renueva", "empresa05", "900000005", "Gestión de metales", "Parque Industrial de Cartagena", "000-000-0105", "empresa05@example.invalid", "Acopio y separación de metales reciclables."}
        };
        ArrayList<Empresa> empresas = new ArrayList<>();
        for (String[] d : empresaDatos) {
            Empresa empresa = new Empresa(d[0], d[1], d[2], "empresa123", d[3], d[4], d[5], d[6], d[7], d[8]);
            empresa.setDemo(true);
            empresas.add(empresa);
            repo.guardarEmpresa(empresa);
        }

        String[][] trabajadoresDatos = {
            {"Ana Demo Circular", "Clasificación de PET, Trabajo en equipo", "Disponible", "Reciclaje manual", "Centro"},
            {"Luis Demo Caribe", "Logística, Inventario", "Disponible", "Auxiliar logístico", "El Bosque"},
            {"María Demo Verde", "Separación de residuos, Seguridad industrial", "Medio tiempo", "Gestión de residuos", "Manga"},
            {"Carlos Demo Azul", "Manejo de montacargas, Bodega", "Disponible", "Operador de bodega", "Mamonal"},
            {"Sofía Demo Reusa", "Atención al cliente, Emprendimiento", "Por turnos", "Economía circular", "La Boquilla"},
            {"Jorge Demo Metal", "Clasificación de metales, Soldadura", "Disponible", "Procesamiento de metales", "Olaya"},
            {"Valentina Demo PET", "Prensado industrial, Calidad", "Medio tiempo", "Transformación de plásticos", "Pie de la Popa"},
            {"Andrés Demo Cartón", "Alistamiento, Trabajo en equipo", "Disponible", "Cadena de aprovechamiento", "Bazurto"},
            {"Camila Demo Vidrio", "Manipulación segura, Clasificación", "Por turnos", "Reutilización de envases", "Crespo"},
            {"Mateo Demo Circular", "Inventario, Gestión ambiental", "Disponible", "Operaciones sostenibles", "San Fernando"}
        };
        ArrayList<Trabajador> trabajadores = new ArrayList<>();
        for (int i = 0; i < trabajadoresDatos.length; i++) {
            String id = String.format("TRA-DEMO-%02d", i + 1);
            Trabajador trabajador = new Trabajador(id, trabajadoresDatos[i][0], String.format("trabajador%02d", i + 1),
                    "trabajador123", String.format("DEMO-%04d", i + 1), String.format("trabajador%02d@example.invalid", i + 1),
                    String.format("000-000-%04d", i + 1), "Cartagena · " + trabajadoresDatos[i][4],
                    trabajadoresDatos[i][3], dividir(trabajadoresDatos[i][1]), trabajadoresDatos[i][2]);
            trabajador.setDemo(true);
            trabajadores.add(trabajador);
            repo.guardarTrabajador(trabajador);
        }

        String[][] habilidadDatos = {
            {"Clasificación de PET", "Operativa"}, {"Separación de residuos", "Ambiental"},
            {"Logística", "Operativa"}, {"Inventario", "Administrativa"},
            {"Trabajo en equipo", "Transversal"}, {"Seguridad industrial", "Seguridad"},
            {"Prensado industrial", "Operativa"}, {"Gestión ambiental", "Ambiental"},
            {"Clasificación de metales", "Operativa"}, {"Atención al cliente", "Transversal"}
        };
        ArrayList<Habilidad> habilidades = new ArrayList<>();
        for (int i = 0; i < habilidadDatos.length; i++) {
            Habilidad habilidad = new Habilidad(String.format("HAB-DEMO-%02d", i + 1), habilidadDatos[i][0], habilidadDatos[i][1]);
            habilidad.setDemo(true);
            habilidades.add(habilidad);
            repo.guardarHabilidad(habilidad);
        }

        String[][] ofertaDatos = {
            {"Auxiliar de clasificación", "Apoyar la separación y el alistamiento de plásticos recuperados.", "Clasificación, seguridad básica", "Clasificación de PET, Trabajo en equipo", "Cartagena · Mamonal", "Tiempo completo", "1450000", "EMP-DEMO-01"},
            {"Operario de aprovechamiento", "Participar en procesos de recuperación de materiales.", "Disponibilidad por turnos", "Separación de residuos, Seguridad industrial", "Cartagena · El Bosque", "Por turnos", "1500000", "EMP-DEMO-02"},
            {"Auxiliar logístico", "Apoyar inventario y movimiento de materiales reciclables.", "Experiencia en bodega deseable", "Logística, Inventario", "Cartagena · Zona Portuaria", "Tiempo completo", "1600000", "EMP-DEMO-03"},
            {"Clasificador de vidrio", "Revisar y clasificar envases reutilizables.", "Manipulación segura", "Clasificación, Trabajo en equipo", "Cartagena · La Boquilla", "Tiempo completo", "1450000", "EMP-DEMO-04"},
            {"Auxiliar de metales", "Separar materiales metálicos según tipo y estado.", "Uso de elementos de protección", "Clasificación de metales, Seguridad industrial", "Cartagena · Mamonal", "Tiempo completo", "1550000", "EMP-DEMO-05"},
            {"Promotor de economía circular", "Orientar a clientes y aliados sobre reutilización.", "Comunicación clara", "Atención al cliente, Emprendimiento", "Cartagena · Centro", "Medio tiempo", "900000", "EMP-DEMO-02"},
            {"Operador de prensa", "Operar equipos de compactación de material recuperado.", "Capacitación en seguridad", "Prensado industrial, Calidad", "Cartagena · Mamonal", "Tiempo completo", "1700000", "EMP-DEMO-01"},
            {"Auxiliar de inventarios", "Mantener registros de entradas y salidas de material.", "Manejo básico de inventarios", "Inventario, Gestión ambiental", "Cartagena · Zona Portuaria", "Tiempo completo", "1500000", "EMP-DEMO-03"}
        };
        ArrayList<OfertaLaboral> ofertas = new ArrayList<>();
        for (int i = 0; i < ofertaDatos.length; i++) {
            String[] d = ofertaDatos[i];
            Empresa empresa = empresas.stream().filter(x -> x.getId().equals(d[7])).findFirst().orElseThrow();
            OfertaLaboral oferta = new OfertaLaboral(String.format("OFE-DEMO-%03d", i + 1), empresa.getId(), empresa.getNombre(),
                    d[0], d[1], d[2], dividir(d[3]), d[4], d[5], new BigDecimal(d[6]),
                    LocalDate.now().minusDays(i), LocalDate.now().plusDays(20 + i), 2 + i % 3, true);
            oferta.setDemo(true);
            ofertas.add(oferta);
            repo.guardarOferta(oferta);
        }

        for (int i = 0; i < 8; i++) {
            Trabajador trabajador = trabajadores.get(i);
            OfertaLaboral oferta = ofertas.get(i);
            Postulacion postulacion = new Postulacion(String.format("POS-DEMO-%03d", i + 1), trabajador.getId(),
                    trabajador.getNombre(), oferta.getId(), oferta.getCargo(), oferta.getEmpresaId());
            if (i == 1) postulacion.setEstado("En revisión");
            if (i == 3) postulacion.setEstado("Aceptada");
            if (i == 5) postulacion.setEstado("Rechazada");
            postulacion.setDemo(true);
            repo.guardarPostulacion(postulacion);
        }

        String[][] cursos = {
            {"Clasificación segura de residuos", "Separación de residuos", "Centro Demo de Aprovechamiento"},
            {"Introducción a la economía circular", "Gestión ambiental", "Aula Circular Cartagena"},
            {"Buenas prácticas en bodega", "Inventario", "Centro Demo de Logística"},
            {"Reutilización creativa de materiales", "Emprendimiento", "Taller Reusa"},
            {"Seguridad en procesos de reciclaje", "Seguridad industrial", "Aula Circular Cartagena"}
        };
        for (int i = 0; i < cursos.length; i++) {
            Capacitacion curso = new Capacitacion(String.format("CAP-DEMO-%02d", i + 1), cursos[i][0], cursos[i][1], cursos[i][2]);
            curso.setDescripcion("Formación práctica para fortalecer " + cursos[i][1].toLowerCase(java.util.Locale.ROOT) + " en actividades laborales.");
            curso.setDuracionHoras(6 + i * 2);
            curso.setFechaInicio(LocalDate.now().plusDays(7L * (i + 1)));
            curso.setCupos(20 + i * 5);
            curso.setDemo(true);
            curso.agregarParticipante(trabajadores.get(i).getId());
            repo.guardarCapacitacion(curso);
        }

        String[][] materialesDatos = {
            {"Botellas PET", "Plástico", "850", "kg", "Mamonal"},
            {"Cartón corrugado", "Cartón", "420", "kg", "El Bosque"},
            {"Envases reutilizables", "Vidrio", "310", "unidades", "La Boquilla"},
            {"Papel blanco", "Papel", "275", "kg", "Centro"},
            {"Aluminio mixto", "Metales", "190", "kg", "Zona Portuaria"}
        };
        for (int i = 0; i < materialesDatos.length; i++) {
            String[] d = materialesDatos[i];
            MaterialReciclable material = new MaterialReciclable(String.format("MAT-DEMO-%02d", i + 1),
                    d[0], d[1], Double.parseDouble(d[2]), d[3]);
            material.setUbicacion("Cartagena · " + d[4]);
            material.setDescripcion("Registro ficticio de demostración.");
            material.setDemo(true);
            repo.guardarMaterial(material);
        }
        repo.marcarDemostracionInicializada();
    }

    private static ArrayList<String> dividir(String valores) {
        return new ArrayList<>(List.of(valores.split(",\\s*")));
    }
}
