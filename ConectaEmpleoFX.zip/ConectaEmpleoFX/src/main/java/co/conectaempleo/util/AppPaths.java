package co.conectaempleo.util;

import java.nio.file.Path;

/** Rutas portables basadas en el directorio desde el que se ejecuta Maven. */
public final class AppPaths {
    private static final Path ROOT = Path.of(System.getProperty("user.dir")).toAbsolutePath().normalize();

    private AppPaths() { }

    public static Path getRoot() { return ROOT; }
    public static Path getDataDirectory() { return ROOT.resolve("data"); }
    public static Path getDataFile() { return getDataDirectory().resolve("conectaempleo.dat"); }
    public static Path getDocumentsDirectory() { return ROOT.resolve("documents"); }
    public static Path getCvDirectory() { return getDocumentsDirectory().resolve("cv"); }
    public static Path getBackupsDirectory() { return ROOT.resolve("backups"); }
}
