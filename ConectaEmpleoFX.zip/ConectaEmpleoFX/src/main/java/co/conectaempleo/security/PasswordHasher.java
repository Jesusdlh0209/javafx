package co.conectaempleo.security;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Hash de contraseñas PBKDF2-HMAC-SHA256 con sal aleatoria por cuenta. */
public final class PasswordHasher {
    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int ITERACIONES = 310_000;
    private static final int BITS = 256;
    private static final int BYTES_SAL = 16;
    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordHasher() { }

    public static String hash(char[] clave) {
        if (clave == null || clave.length == 0) throw new IllegalArgumentException("La contraseña es obligatoria.");
        byte[] sal = new byte[BYTES_SAL];
        RANDOM.nextBytes(sal);
        byte[] derivada = derivar(clave, sal, ITERACIONES);
        return "pbkdf2-sha256$" + ITERACIONES + "$" + Base64.getEncoder().encodeToString(sal)
                + "$" + Base64.getEncoder().encodeToString(derivada);
    }

    public static boolean verificar(char[] clave, String formato) {
        if (clave == null || formato == null) return false;
        try {
            String[] partes = formato.split("\\$", -1);
            if (partes.length != 4 || !partes[0].equals("pbkdf2-sha256")) return false;
            int iteraciones = Integer.parseInt(partes[1]);
            if (iteraciones < 100_000 || iteraciones > 2_000_000) return false;
            byte[] sal = Base64.getDecoder().decode(partes[2]);
            byte[] almacenada = Base64.getDecoder().decode(partes[3]);
            byte[] calculada = derivar(clave, sal, iteraciones);
            return MessageDigest.isEqual(almacenada, calculada);
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    private static byte[] derivar(char[] clave, byte[] sal, int iteraciones) {
        PBEKeySpec especificacion = new PBEKeySpec(clave, sal, iteraciones, BITS);
        try {
            return SecretKeyFactory.getInstance(ALGORITHM).generateSecret(especificacion).getEncoded();
        } catch (GeneralSecurityException ex) {
            throw new IllegalStateException("No está disponible el algoritmo de hash requerido.", ex);
        } finally {
            especificacion.clearPassword();
        }
    }
}
