package co.conectaempleo.app;

import co.conectaempleo.model.Usuario;
import co.conectaempleo.config.InicializadorDatos;
import co.conectaempleo.repository.RepositorioLocal;
import co.conectaempleo.services.ServicioConectaEmpleo;
import co.conectaempleo.controller.LoginController;
import co.conectaempleo.controller.ShellController;
import java.io.IOException;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/** Punto de entrada y coordinador de pantallas de ConectaEmpleo. */
public final class ConectaEmpleoApp extends Application {

    private RepositorioLocal repositorio;
    private ServicioConectaEmpleo servicio;

    private Stage stage;

    @Override
    public void start(Stage primaryStage) throws IOException {
        stage = primaryStage;
        // Fija el marco nativo de Windows para conservar minimizar, maximizar y cerrar.
        // Se configura antes de mostrar la ventana; el contenido JavaFX no dibuja controles propios.
        stage.initStyle(StageStyle.DECORATED);
        try {
            repositorio = new RepositorioLocal();
            InicializadorDatos.cargarSiEsNecesario(repositorio);
            servicio = new ServicioConectaEmpleo(repositorio);
        } catch (RuntimeException ex) {
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setTitle("ConectaEmpleo");
            alerta.setHeaderText("No se pudo preparar el almacenamiento local");
            alerta.setContentText(ex.getMessage());
            alerta.showAndWait();
            javafx.application.Platform.exit();
            return;
        }
        stage.setTitle("ConectaEmpleo | Cartagena");
        stage.setMinWidth(980);
        stage.setMinHeight(680);
        stage.setResizable(true);
        mostrarLogin();
        stage.show();
        stage.setMaximized(true);
    }

    public ServicioConectaEmpleo getServicio() { return servicio; }

    public void mostrarLogin() throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/login-view.fxml"));
        Parent root = loader.load();
        LoginController controller = loader.getController();
        controller.setApp(this);
        stage.setScene(crearScene(root, 1280, 800));
    }

    public void mostrarInicio(Usuario usuario) throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/shell-view.fxml"));
        Parent root = loader.load();
        ShellController controller = loader.getController();
        controller.configurar(this, usuario);
        stage.setScene(crearScene(root));
        stage.setMaximized(true);
    }

    private Scene crearScene(Parent root) {
        Scene scene = new Scene(root);
        URL stylesheet = getClass().getResource("/css/app.css");
        if (stylesheet != null) scene.getStylesheets().add(stylesheet.toExternalForm());
        return scene;
    }

    private Scene crearScene(Parent root, double width, double height) {
        Scene scene = new Scene(root, width, height);
        URL stylesheet = getClass().getResource("/css/app.css");
        if (stylesheet != null) {
            scene.getStylesheets().add(stylesheet.toExternalForm());
        }
        return scene;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
