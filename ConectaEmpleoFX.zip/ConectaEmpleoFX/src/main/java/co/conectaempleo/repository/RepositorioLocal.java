package co.conectaempleo.repository;

import co.conectaempleo.model.Administrador;
import co.conectaempleo.model.Capacitacion;
import co.conectaempleo.model.Documento;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.Habilidad;
import co.conectaempleo.model.MaterialReciclable;
import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.Postulacion;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serial;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import co.conectaempleo.util.AppPaths;

/** Repositorio local con colecciones ArrayList y persistencia por serialización. */
public final class RepositorioLocal {

    private final Path archivoDatos;
    private final Path directorioRespaldos;
    private final Path directorioDocumentos;
    private DatosSistema datos;
    private boolean recuperadoDesdeRespaldo;
    private String avisoRecuperacion = "";

    public RepositorioLocal() {
        this(AppPaths.getDataFile());
    }

    public RepositorioLocal(Path archivoDatos) {
        this.archivoDatos = Objects.requireNonNull(archivoDatos, "archivoDatos").toAbsolutePath().normalize();
        Path parent = this.archivoDatos.getParent();
        Path root = parent != null && "data".equalsIgnoreCase(String.valueOf(parent.getFileName()))
                && parent.getParent() != null ? parent.getParent() : parent;
        if (root == null) root = Path.of(System.getProperty("user.dir")).toAbsolutePath().normalize();
        this.directorioRespaldos = root.resolve("backups");
        this.directorioDocumentos = root.resolve("documents").resolve("cv");
        if (this.archivoDatos.equals(AppPaths.getDataFile().toAbsolutePath().normalize())) {
            migrarRutaAnteriorSiAplica();
        }
        cargar();
    }

    private void migrarRutaAnteriorSiAplica() {
        Path rutaAnterior = Path.of(System.getProperty("user.home"), ".conectaempleo", "datos.dat").toAbsolutePath().normalize();
        if (Files.exists(archivoDatos) || rutaAnterior.equals(archivoDatos) || !Files.isRegularFile(rutaAnterior)) return;
        try {
            Files.createDirectories(archivoDatos.getParent());
            Files.copy(rutaAnterior, archivoDatos, StandardCopyOption.COPY_ATTRIBUTES);
        } catch (IOException ex) {
            avisoRecuperacion = "No se pudo importar el archivo local anterior: " + ex.getMessage();
        }
    }

    private void cargar() {
        if (!Files.exists(archivoDatos)) {
            datos = new DatosSistema();
            Administrador admin = new Administrador("ADM-001", "Administrador", "admin", "admin");
            admin.setDemo(true);
            datos.usuarios.add(admin);
            guardar();
            return;
        }

        try {
            datos = leerDatos(archivoDatos);
            boolean legado = datos.versionFormato == 0;
            normalizarDatos();
            if (legado) {
                // Los archivos anteriores se consideran información existente: no se vuelven a sembrar.
                datos.versionFormato = 1;
                datos.demostracionInicializada = true;
                guardar();
            }
        } catch (IOException | ClassNotFoundException | RuntimeException errorLectura) {
            preservarArchivoDaniado();
            DatosSistema respaldo = buscarRespaldoValido();
            if (respaldo == null) {
                throw new IllegalStateException("El archivo de datos está dañado y no hay una copia de seguridad válida. "
                        + "El archivo original se conservó en " + archivoDatos + ". Detalle: " + errorLectura.getMessage(), errorLectura);
            }
            datos = respaldo;
            normalizarDatos();
            recuperadoDesdeRespaldo = true;
            avisoRecuperacion = "Se recuperó la información desde una copia de seguridad local.";
            guardar();
        }
    }

    public void guardar() {
        Path temporal = archivoDatos.resolveSibling(archivoDatos.getFileName() + ".tmp");
        try {
            Files.createDirectories(archivoDatos.getParent());
            Files.createDirectories(directorioRespaldos);
            try (FileOutputStream flujo = new FileOutputStream(temporal.toFile());
                 ObjectOutputStream salida = new ObjectOutputStream(flujo)) {
                salida.writeObject(datos);
                salida.flush();
                flujo.getFD().sync();
            }
            if (Files.isRegularFile(archivoDatos)) crearRespaldo();
            try {
                Files.move(temporal, archivoDatos, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException falloAtomico) {
                try {
                    Files.move(temporal, archivoDatos, StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException falloReserva) {
                    falloReserva.addSuppressed(falloAtomico);
                    throw falloReserva;
                }
            }
            limitarRespaldos(5);
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporal); } catch (IOException ignored) { }
            throw new IllegalStateException("No se pudieron guardar los datos locales: " + ex.getMessage(), ex);
        }
    }

    private DatosSistema leerDatos(Path archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(Files.newInputStream(archivo))) {
            Object contenido = entrada.readObject();
            if (!(contenido instanceof DatosSistema almacenado)) throw new IOException("Formato de archivo no reconocido.");
            return almacenado;
        }
    }

    private void normalizarDatos() {
        if (datos.documentos == null) datos.documentos = new ArrayList<>();
        if (datos.usuarios == null) datos.usuarios = new ArrayList<>();
        if (datos.trabajadores == null) datos.trabajadores = new ArrayList<>();
        if (datos.empresas == null) datos.empresas = new ArrayList<>();
        if (datos.ofertas == null) datos.ofertas = new ArrayList<>();
        if (datos.postulaciones == null) datos.postulaciones = new ArrayList<>();
        if (datos.habilidades == null) datos.habilidades = new ArrayList<>();
        if (datos.capacitaciones == null) datos.capacitaciones = new ArrayList<>();
        if (datos.materiales == null) datos.materiales = new ArrayList<>();
        if (datos.versionFormato == 0) datos.versionFormato = 1;
    }

    private void preservarArchivoDaniado() {
        try {
            Files.createDirectories(directorioRespaldos);
            Path copia = directorioRespaldos.resolve("danado-" + System.currentTimeMillis() + "-" + archivoDatos.getFileName());
            Files.copy(archivoDatos, copia, StandardCopyOption.COPY_ATTRIBUTES);
        } catch (IOException ex) {
            avisoRecuperacion = "No se pudo copiar el archivo dañado antes de intentar recuperarlo: " + ex.getMessage();
        }
    }

    private DatosSistema buscarRespaldoValido() {
        if (!Files.isDirectory(directorioRespaldos)) return null;
        try (var archivos = Files.list(directorioRespaldos)) {
            for (Path copia : archivos.filter(p -> p.getFileName().toString().startsWith("conectaempleo-")
                            && p.getFileName().toString().endsWith(".bak"))
                    .sorted(Comparator.comparingLong(this::ultimaModificacion).reversed()).toList()) {
                try { return leerDatos(copia); }
                catch (IOException | ClassNotFoundException ignored) { }
            }
        } catch (IOException ignored) { }
        return null;
    }

    private long ultimaModificacion(Path archivo) {
        try { return Files.getLastModifiedTime(archivo).toMillis(); }
        catch (IOException ex) { return 0; }
    }

    private void crearRespaldo() throws IOException {
        String sello = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"));
        Path destino = directorioRespaldos.resolve("conectaempleo-" + sello + ".bak");
        Files.copy(archivoDatos, destino, StandardCopyOption.COPY_ATTRIBUTES);
    }

    private void limitarRespaldos(int maximos) throws IOException {
        try (var archivos = Files.list(directorioRespaldos)) {
            List<Path> copias = archivos.filter(p -> p.getFileName().toString().startsWith("conectaempleo-")
                            && p.getFileName().toString().endsWith(".bak"))
                    .sorted(Comparator.comparingLong(this::ultimaModificacion).reversed()).toList();
            for (int i = maximos; i < copias.size(); i++) Files.deleteIfExists(copias.get(i));
        }
    }

    public Path getArchivoDatos() { return archivoDatos; }
    public Path getDirectorioDocumentos() { return directorioDocumentos; }
    public Path getDirectorioRespaldos() { return directorioRespaldos; }
    public boolean isRecuperadoDesdeRespaldo() { return recuperadoDesdeRespaldo; }
    public String getAvisoRecuperacion() { return avisoRecuperacion; }
    public boolean requiereInicializarDemostracion() { return !datos.demostracionInicializada; }
    public void marcarDemostracionInicializada() { datos.demostracionInicializada = true; guardar(); }
    public void eliminarDatosDemostracion() {
        HashSet<String> trabajadoresDemo = datos.trabajadores.stream().filter(Trabajador::isDemo)
                .map(Trabajador::getId).collect(java.util.stream.Collectors.toCollection(HashSet::new));
        HashSet<String> ofertasDemo = datos.ofertas.stream().filter(OfertaLaboral::isDemo)
                .map(OfertaLaboral::getId).collect(java.util.stream.Collectors.toCollection(HashSet::new));
        datos.usuarios.removeIf(Usuario::isDemo);
        datos.trabajadores.removeIf(Trabajador::isDemo);
        datos.empresas.removeIf(Empresa::isDemo);
        datos.ofertas.removeIf(OfertaLaboral::isDemo);
        datos.postulaciones.removeIf(x -> x.isDemo() || trabajadoresDemo.contains(x.getTrabajadorId())
                || ofertasDemo.contains(x.getOfertaId()));
        datos.habilidades.removeIf(Habilidad::isDemo);
        datos.capacitaciones.removeIf(Capacitacion::isDemo);
        datos.materiales.removeIf(MaterialReciclable::isDemo);
        datos.documentos.removeIf(x -> x.isDemo() || trabajadoresDemo.contains(x.getTrabajadorId()));
        datos.demostracionInicializada = false;
        guardar();
    }
    public ArrayList<Documento> listarDocumentos() { return new ArrayList<>(datos.documentos); }
    public void guardarDocumento(Documento documento) { reemplazar(datos.documentos, documento, Documento::getId); guardar(); }
    public void eliminarDocumento(String id) { datos.documentos.removeIf(x -> x.getId().equals(id)); guardar(); }
    public ArrayList<Usuario> listarUsuarios() { return new ArrayList<>(datos.usuarios); }
    public ArrayList<Trabajador> listarTrabajadores() { return new ArrayList<>(datos.trabajadores); }
    public ArrayList<Empresa> listarEmpresas() { return new ArrayList<>(datos.empresas); }
    public ArrayList<OfertaLaboral> listarOfertas() { return new ArrayList<>(datos.ofertas); }
    public ArrayList<Postulacion> listarPostulaciones() { return new ArrayList<>(datos.postulaciones); }
    public ArrayList<Habilidad> listarHabilidades() { return new ArrayList<>(datos.habilidades); }
    public ArrayList<Capacitacion> listarCapacitaciones() { return new ArrayList<>(datos.capacitaciones); }
    public ArrayList<MaterialReciclable> listarMateriales() { return new ArrayList<>(datos.materiales); }

    public Usuario buscarUsuario(String id) { return datos.usuarios.stream().filter(x -> x.getId().equals(id)).findFirst().orElse(null); }
    public Trabajador buscarTrabajador(String id) { return datos.trabajadores.stream().filter(x -> x.getId().equals(id)).findFirst().orElse(null); }
    public Empresa buscarEmpresa(String id) { return datos.empresas.stream().filter(x -> x.getId().equals(id)).findFirst().orElse(null); }
    public OfertaLaboral buscarOferta(String id) { return datos.ofertas.stream().filter(x -> x.getId().equals(id)).findFirst().orElse(null); }

    public void guardarUsuario(Usuario usuario) {
        Objects.requireNonNull(usuario, "usuario");
        boolean duplicado = datos.usuarios.stream().anyMatch(actual ->
                actual.getNombreUsuario().equalsIgnoreCase(usuario.getNombreUsuario())
                && !actual.getId().equals(usuario.getId()));
        if (duplicado) throw new IllegalArgumentException("Ese usuario ya existe.");
        if (usuario instanceof Trabajador trabajador) {
            boolean correoDuplicado = !trabajador.getCorreo().isBlank() && (datos.trabajadores.stream().anyMatch(actual ->
                    actual.getCorreo().equalsIgnoreCase(trabajador.getCorreo()) && !actual.getId().equals(trabajador.getId()))
                    || datos.empresas.stream().anyMatch(actual -> actual.getCorreo().equalsIgnoreCase(trabajador.getCorreo())));
            if (correoDuplicado) throw new IllegalArgumentException("Ese correo ya está asociado a otra cuenta.");
            boolean cedulaDuplicada = datos.trabajadores.stream().anyMatch(actual ->
                    actual.getCedula().equalsIgnoreCase(trabajador.getCedula())
                    && !actual.getId().equals(trabajador.getId()));
            if (cedulaDuplicada) throw new IllegalArgumentException("Ya existe un trabajador con esa cédula.");
        }
        if (usuario instanceof Empresa empresa) {
            boolean correoDuplicado = !empresa.getCorreo().isBlank() && (datos.empresas.stream().anyMatch(actual ->
                    actual.getCorreo().equalsIgnoreCase(empresa.getCorreo()) && !actual.getId().equals(empresa.getId()))
                    || datos.trabajadores.stream().anyMatch(actual -> actual.getCorreo().equalsIgnoreCase(empresa.getCorreo())));
            if (correoDuplicado) throw new IllegalArgumentException("Ese correo ya está asociado a otra cuenta.");
            boolean nitDuplicado = datos.empresas.stream().anyMatch(actual ->
                    actual.getNit().equalsIgnoreCase(empresa.getNit())
                    && !actual.getId().equals(empresa.getId()));
            if (nitDuplicado) throw new IllegalArgumentException("Ya existe una empresa con ese NIT.");
        }
        reemplazar(datos.usuarios, usuario, Usuario::getId);
        if (usuario instanceof Trabajador trabajador) reemplazar(datos.trabajadores, trabajador, Trabajador::getId);
        if (usuario instanceof Empresa empresa) reemplazar(datos.empresas, empresa, Empresa::getId);
        guardar();
    }

    public void eliminarUsuario(String id) {
        datos.usuarios.removeIf(x -> x.getId().equals(id));
        datos.trabajadores.removeIf(x -> x.getId().equals(id));
        datos.empresas.removeIf(x -> x.getId().equals(id));
        guardar();
    }
    public void guardarTrabajador(Trabajador x) { guardarUsuario(x); }
    public void eliminarTrabajador(String id) {
        if (datos.postulaciones.stream().anyMatch(x -> x.getTrabajadorId().equals(id))
                || datos.capacitaciones.stream().anyMatch(x -> x.getParticipantes().contains(id))
                || datos.documentos.stream().anyMatch(x -> x.getTrabajadorId().equals(id))) {
            throw new IllegalArgumentException("No se puede eliminar el trabajador mientras tenga historial, inscripciones o documentos asociados.");
        }
        eliminarUsuario(id);
    }
    public void guardarEmpresa(Empresa x) { guardarUsuario(x); }
    public void eliminarEmpresa(String id) {
        if (datos.ofertas.stream().anyMatch(x -> x.getEmpresaId().equals(id))) {
            throw new IllegalArgumentException("No se puede eliminar una empresa con ofertas registradas.");
        }
        eliminarUsuario(id);
    }
    public void guardarOferta(OfertaLaboral x) { reemplazar(datos.ofertas, x, OfertaLaboral::getId); guardar(); }
    public void eliminarOferta(String id) {
        if (datos.postulaciones.stream().anyMatch(x -> x.getOfertaId().equals(id))) {
            throw new IllegalArgumentException("No se puede eliminar una oferta con postulaciones; ciérrala para conservar el historial.");
        }
        datos.ofertas.removeIf(x -> x.getId().equals(id));
        guardar();
    }
    public void guardarPostulacion(Postulacion x) { reemplazar(datos.postulaciones, x, Postulacion::getId); guardar(); }
    public void eliminarPostulacion(String id) { datos.postulaciones.removeIf(x -> x.getId().equals(id)); guardar(); }
    public void guardarHabilidad(Habilidad x) { reemplazar(datos.habilidades, x, Habilidad::getId); guardar(); }
    public void eliminarHabilidad(String id) { datos.habilidades.removeIf(x -> x.getId().equals(id)); guardar(); }
    public void guardarCapacitacion(Capacitacion x) { reemplazar(datos.capacitaciones, x, Capacitacion::getId); guardar(); }
    public void eliminarCapacitacion(String id) {
        if (datos.capacitaciones.stream().anyMatch(x -> x.getId().equals(id) && !x.getParticipantes().isEmpty())) {
            throw new IllegalArgumentException("No se puede eliminar una capacitación con participantes registrados.");
        }
        datos.capacitaciones.removeIf(x -> x.getId().equals(id)); guardar();
    }
    public void guardarMaterial(MaterialReciclable x) { reemplazar(datos.materiales, x, MaterialReciclable::getId); guardar(); }
    public void eliminarMaterial(String id) { datos.materiales.removeIf(x -> x.getId().equals(id)); guardar(); }

    private static <T> void reemplazar(ArrayList<T> lista, T nuevo, Function<T, String> id) {
        lista.removeIf(actual -> id.apply(actual).equals(id.apply(nuevo)));
        lista.add(nuevo);
    }

    private static final class DatosSistema implements Serializable {
        @Serial private static final long serialVersionUID = 1L;
        private int versionFormato = 1;
        private boolean demostracionInicializada;
        private ArrayList<Usuario> usuarios = new ArrayList<>();
        private ArrayList<Trabajador> trabajadores = new ArrayList<>();
        private ArrayList<Empresa> empresas = new ArrayList<>();
        private ArrayList<OfertaLaboral> ofertas = new ArrayList<>();
        private ArrayList<Postulacion> postulaciones = new ArrayList<>();
        private ArrayList<Habilidad> habilidades = new ArrayList<>();
        private ArrayList<Capacitacion> capacitaciones = new ArrayList<>();
        private ArrayList<MaterialReciclable> materiales = new ArrayList<>();
        private ArrayList<Documento> documentos = new ArrayList<>();
    }
}
