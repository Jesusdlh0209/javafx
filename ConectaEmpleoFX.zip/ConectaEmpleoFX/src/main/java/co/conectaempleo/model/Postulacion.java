package co.conectaempleo.model;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;

public final class Postulacion implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String trabajadorId;
    private final String trabajadorNombre;
    private final String ofertaId;
    private final String ofertaCargo;
    private final String empresaId;
    private String estado;
    private LocalDateTime fechaPostulacion = LocalDateTime.now();
    private ArrayList<String> historialEstados = new ArrayList<>();
    private boolean demo;

    public Postulacion(String id, String trabajadorId, String trabajadorNombre,
                       String ofertaId, String ofertaCargo, String empresaId) {
        this.id = Objects.requireNonNull(id);
        this.trabajadorId = Objects.requireNonNull(trabajadorId);
        this.trabajadorNombre = Objects.requireNonNull(trabajadorNombre);
        this.ofertaId = Objects.requireNonNull(ofertaId);
        this.ofertaCargo = Objects.requireNonNull(ofertaCargo);
        this.empresaId = Objects.requireNonNull(empresaId);
        this.estado = "Pendiente";
        this.historialEstados.add(LocalDateTime.now() + " · Pendiente");
    }

    public String getId() { return id; }
    public String getTrabajadorId() { return trabajadorId; }
    public String getTrabajadorNombre() { return trabajadorNombre; }
    public String getOfertaId() { return ofertaId; }
    public String getOfertaCargo() { return ofertaCargo; }
    public String getEmpresaId() { return empresaId; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) {
        this.estado = Objects.requireNonNull(estado);
        if (historialEstados == null) historialEstados = new ArrayList<>();
        this.historialEstados.add(LocalDateTime.now() + " · " + estado);
    }
    public EstadoPostulacion getEstadoEnum() {
        return switch (estado) {
            case "En revisión" -> EstadoPostulacion.EN_REVISION;
            case "Aceptada", "Seleccionado" -> EstadoPostulacion.ACEPTADA;
            case "Rechazada", "No seleccionado" -> EstadoPostulacion.RECHAZADA;
            case "Retirada" -> EstadoPostulacion.RETIRADA;
            default -> EstadoPostulacion.PENDIENTE;
        };
    }
    public ArrayList<String> getHistorialEstados() {
        if (historialEstados == null) historialEstados = new ArrayList<>();
        if (historialEstados.isEmpty() && estado != null) historialEstados.add(estado);
        return new ArrayList<>(historialEstados);
    }
    public boolean isDemo() { return demo; }
    public void setDemo(boolean demo) { this.demo = demo; }
    public LocalDateTime getFechaPostulacion() { return fechaPostulacion == null ? LocalDateTime.now() : fechaPostulacion; }
    public void setFechaPostulacion(LocalDateTime fechaPostulacion) { this.fechaPostulacion = Objects.requireNonNull(fechaPostulacion); }
}
