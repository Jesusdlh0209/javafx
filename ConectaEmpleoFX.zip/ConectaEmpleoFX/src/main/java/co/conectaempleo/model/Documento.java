package co.conectaempleo.model;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/** Metadatos de un documento guardado dentro del directorio local de la aplicación. */
public final class Documento implements Serializable {
    @Serial private static final long serialVersionUID = 1L;

    private final String id;
    private final String trabajadorId;
    private final String nombreOriginal;
    private final String rutaRelativa;
    private final long tamanoBytes;
    private final LocalDateTime fechaCarga;
    private boolean demo;

    public Documento(String id, String trabajadorId, String nombreOriginal,
                     String rutaRelativa, long tamanoBytes, LocalDateTime fechaCarga) {
        this.id = Objects.requireNonNull(id);
        this.trabajadorId = Objects.requireNonNull(trabajadorId);
        this.nombreOriginal = Objects.requireNonNull(nombreOriginal);
        this.rutaRelativa = Objects.requireNonNull(rutaRelativa);
        this.tamanoBytes = tamanoBytes;
        this.fechaCarga = Objects.requireNonNull(fechaCarga);
    }

    public String getId() { return id; }
    public String getTrabajadorId() { return trabajadorId; }
    public String getNombreOriginal() { return nombreOriginal; }
    public String getRutaRelativa() { return rutaRelativa; }
    public long getTamanoBytes() { return tamanoBytes; }
    public LocalDateTime getFechaCarga() { return fechaCarga; }
    public boolean isDemo() { return demo; }
    public void setDemo(boolean demo) { this.demo = demo; }
}
