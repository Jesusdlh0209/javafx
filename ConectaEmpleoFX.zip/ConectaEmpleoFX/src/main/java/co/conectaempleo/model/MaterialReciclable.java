package co.conectaempleo.model;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

public final class MaterialReciclable implements Serializable {
    @Serial private static final long serialVersionUID = 1L;
    private final String id;
    private String nombre;
    private String categoria;
    private double cantidad;
    private String unidad;
    private String ubicacion = "";
    private String estado = "Disponible";
    private String descripcion = "";
    private boolean demo;

    public MaterialReciclable(String id, String nombre, String categoria,
                              double cantidad, String unidad) {
        this.id = Objects.requireNonNull(id);
        this.nombre = Objects.requireNonNull(nombre);
        this.categoria = Objects.requireNonNull(categoria);
        this.cantidad = cantidad;
        this.unidad = Objects.requireNonNull(unidad);
    }
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = Objects.requireNonNull(nombre); }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = Objects.requireNonNull(categoria); }
    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }
    public String getUnidad() { return unidad; }
    public void setUnidad(String unidad) { this.unidad = Objects.requireNonNull(unidad); }
    public String getUbicacion() { return Objects.requireNonNullElse(ubicacion, ""); }
    public void setUbicacion(String ubicacion) { this.ubicacion = Objects.requireNonNullElse(ubicacion, ""); }
    public String getEstado() { return Objects.requireNonNullElse(estado, "Disponible"); }
    public void setEstado(String estado) { this.estado = Objects.requireNonNullElse(estado, "Disponible"); }
    public String getDescripcion() { return Objects.requireNonNullElse(descripcion, ""); }
    public void setDescripcion(String descripcion) { this.descripcion = Objects.requireNonNullElse(descripcion, ""); }
    public boolean isDemo() { return demo; }
    public void setDemo(boolean demo) { this.demo = demo; }
}
