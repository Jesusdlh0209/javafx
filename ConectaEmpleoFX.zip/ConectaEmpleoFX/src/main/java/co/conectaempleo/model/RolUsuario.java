package co.conectaempleo.model;

public enum RolUsuario {
    ADMINISTRADOR("Administrador"),
    EMPRESA("Empresa"),
    TRABAJADOR("Trabajador");

    private final String etiqueta;

    RolUsuario(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }
}
