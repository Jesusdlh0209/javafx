package co.conectaempleo.model;

import java.io.Serial;
import java.io.Serializable;
import java.io.ObjectStreamException;
import java.util.Objects;
import java.util.ArrayList;

public final class Capacitacion implements Serializable {
    @Serial private static final long serialVersionUID = 1L;
    private final String id;
    private String nombre;
    private String habilidad;
    private String entidad;
    private String descripcion = "";
    private int duracionHoras;
    private java.time.LocalDate fechaInicio;
    private int cupos = 30;
    private boolean activa = true;
    private ArrayList<String> participantes = new ArrayList<>();
    private boolean demo;

    public Capacitacion(String id, String nombre, String habilidad, String entidad) {
        this.id = Objects.requireNonNull(id);
        this.nombre = Objects.requireNonNull(nombre);
        this.habilidad = Objects.requireNonNull(habilidad);
        this.entidad = Objects.requireNonNull(entidad);
    }
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = Objects.requireNonNull(nombre); }
    public String getHabilidad() { return habilidad; }
    public void setHabilidad(String habilidad) { this.habilidad = Objects.requireNonNull(habilidad); }
    public String getEntidad() { return entidad; }
    public void setEntidad(String entidad) { this.entidad = Objects.requireNonNull(entidad); }
    public String getDescripcion() { return Objects.requireNonNullElse(descripcion, ""); }
    public void setDescripcion(String descripcion) { this.descripcion = Objects.requireNonNullElse(descripcion, ""); }
    public int getDuracionHoras() { return duracionHoras; }
    public void setDuracionHoras(int duracionHoras) { if (duracionHoras < 0) throw new IllegalArgumentException("La duración no puede ser negativa."); this.duracionHoras = duracionHoras; }
    public java.time.LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(java.time.LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    public int getCupos() { return cupos < 1 ? 30 : cupos; }
    public void setCupos(int cupos) { if (cupos < 1) throw new IllegalArgumentException("Los cupos deben ser mayores que cero."); this.cupos = cupos; }
    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }
    public boolean tieneCupos() { return getParticipantes().size() < getCupos(); }
    public ArrayList<String> getParticipantes() { return participantes == null ? new ArrayList<>() : new ArrayList<>(participantes); }
    public void setParticipantes(ArrayList<String> participantes) { this.participantes = participantes == null ? new ArrayList<>() : new ArrayList<>(participantes); }
    public void agregarParticipante(String trabajadorId) {
        if (participantes == null) participantes = new ArrayList<>();
        if (!participantes.contains(trabajadorId)) participantes.add(trabajadorId);
    }
    public boolean isDemo() { return demo; }
    public void setDemo(boolean demo) { this.demo = demo; }

    @Serial
    private Object readResolve() throws ObjectStreamException {
        // En los ficheros previos aún no existían cupos, descripción ni estado: eran cursos abiertos.
        if (cupos == 0 && descripcion == null && !activa) {
            cupos = 30;
            activa = true;
        }
        return this;
    }
}
