package co.conectaempleo.model;

import java.io.Serial;

public final class Administrador extends Usuario {

    @Serial
    private static final long serialVersionUID = 1L;

    public Administrador(String id, String nombre, String nombreUsuario,
                         String claveDemo) {
        super(id, nombre, nombreUsuario, claveDemo, RolUsuario.ADMINISTRADOR);
    }

    @Override
    public String getResumenPerfil() {
        return "Administración de trabajadores, empresas y oportunidades laborales.";
    }
}
