package co.conectaempleo.model;

import java.io.Serial;
import java.util.ArrayList;
import java.util.Objects;

public final class Trabajador extends Usuario {

    @Serial
    private static final long serialVersionUID = 1L;

    private String cedula;
    private final ArrayList<String> habilidades;
    private String disponibilidad = "Disponible";
    private String rutaHojaVida = "";
    private String correo = "";
    private String telefono = "";
    private String ubicacion = "";
    private String perfilProfesional = "";

    public Trabajador(String id, String nombre, String nombreUsuario,
                      String claveDemo, String cedula,
                      ArrayList<String> habilidades) {
        super(id, nombre, nombreUsuario, claveDemo, RolUsuario.TRABAJADOR);
        this.cedula = Objects.requireNonNull(cedula, "cedula");
        this.habilidades = habilidades == null
                ? new ArrayList<>()
                : new ArrayList<>(habilidades);
    }

    public Trabajador(String id, String nombre, String nombreUsuario, String claveDemo,
                      String cedula, String correo, String telefono, String ubicacion,
                      String perfilProfesional, ArrayList<String> habilidades,
                      String disponibilidad) {
        this(id, nombre, nombreUsuario, claveDemo, cedula, habilidades);
        this.correo = Objects.requireNonNullElse(correo, "");
        this.telefono = Objects.requireNonNullElse(telefono, "");
        this.ubicacion = Objects.requireNonNullElse(ubicacion, "");
        this.perfilProfesional = Objects.requireNonNullElse(perfilProfesional, "");
        this.disponibilidad = Objects.requireNonNullElse(disponibilidad, "Disponible");
    }

    public String getCedula() {
        return cedula;
    }

    public String getCorreo() { return Objects.requireNonNullElse(correo, ""); }
    public void setCorreo(String correo) { this.correo = Objects.requireNonNullElse(correo, ""); }
    public String getTelefono() { return Objects.requireNonNullElse(telefono, ""); }
    public void setTelefono(String telefono) { this.telefono = Objects.requireNonNullElse(telefono, ""); }
    public String getUbicacion() { return Objects.requireNonNullElse(ubicacion, ""); }
    public void setUbicacion(String ubicacion) { this.ubicacion = Objects.requireNonNullElse(ubicacion, ""); }
    public String getPerfilProfesional() { return Objects.requireNonNullElse(perfilProfesional, ""); }
    public void setPerfilProfesional(String perfilProfesional) { this.perfilProfesional = Objects.requireNonNullElse(perfilProfesional, ""); }

    public void setCedula(String cedula) { this.cedula = Objects.requireNonNull(cedula, "cedula"); }

    public void setHabilidades(ArrayList<String> habilidades) {
        this.habilidades.clear();
        if (habilidades != null) this.habilidades.addAll(habilidades);
    }

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = Objects.requireNonNull(disponibilidad, "disponibilidad");
    }

    public String getRutaHojaVida() {
        return Objects.requireNonNullElse(rutaHojaVida, "");
    }

    public void setRutaHojaVida(String rutaHojaVida) {
        this.rutaHojaVida = Objects.requireNonNull(rutaHojaVida, "rutaHojaVida");
    }

    public void agregarHabilidad(String habilidad) {
        String normalizada = Objects.requireNonNull(habilidad, "habilidad").trim();
        if (!normalizada.isEmpty() && habilidades.stream()
                .noneMatch(actual -> actual.equalsIgnoreCase(normalizada))) {
            habilidades.add(normalizada);
        }
    }

    public ArrayList<String> getHabilidades() {
        return new ArrayList<>(habilidades);
    }

    @Override
    public String getResumenPerfil() {
        return habilidades.isEmpty()
                ? "Completa tu perfil para empezar a buscar oportunidades."
                : "Habilidades registradas: " + String.join(", ", habilidades) + ".";
    }
}
