package co.conectaempleo.model;

public enum EstadoOferta {
    PUBLICADA("Publicada"), CERRADA("Cerrada"), VENCIDA("Vencida");

    private final String etiqueta;
    EstadoOferta(String etiqueta) { this.etiqueta = etiqueta; }
    public String getEtiqueta() { return etiqueta; }
}
