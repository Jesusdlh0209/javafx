package co.conectaempleo.model;

import java.io.Serial;
import java.util.Objects;

public final class Empresa extends Usuario {

    @Serial
    private static final long serialVersionUID = 1L;

    private String nit;
    private String sector;
    private String direccion = "";
    private String telefono = "";
    private String correo = "";
    private String descripcion = "";

    public Empresa(String id, String nombre, String nombreUsuario,
                   String claveDemo, String nit, String sector) {
        super(id, nombre, nombreUsuario, claveDemo, RolUsuario.EMPRESA);
        this.nit = Objects.requireNonNull(nit, "nit");
        this.sector = Objects.requireNonNull(sector, "sector");
    }

    public Empresa(String id, String nombre, String nombreUsuario, String clave,
                   String nit, String sector, String direccion, String telefono,
                   String correo, String descripcion) {
        this(id, nombre, nombreUsuario, clave, nit, sector);
        this.direccion = Objects.requireNonNullElse(direccion, "");
        this.telefono = Objects.requireNonNullElse(telefono, "");
        this.correo = Objects.requireNonNullElse(correo, "");
        this.descripcion = Objects.requireNonNullElse(descripcion, "");
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) { this.nit = Objects.requireNonNull(nit, "nit"); }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) { this.sector = Objects.requireNonNull(sector, "sector"); }

    public String getDireccion() { return Objects.requireNonNullElse(direccion, ""); }
    public void setDireccion(String direccion) { this.direccion = Objects.requireNonNullElse(direccion, ""); }
    public String getTelefono() { return Objects.requireNonNullElse(telefono, ""); }
    public void setTelefono(String telefono) { this.telefono = Objects.requireNonNullElse(telefono, ""); }
    public String getCorreo() { return Objects.requireNonNullElse(correo, ""); }
    public void setCorreo(String correo) { this.correo = Objects.requireNonNullElse(correo, ""); }
    public String getDescripcion() { return Objects.requireNonNullElse(descripcion, ""); }
    public void setDescripcion(String descripcion) { this.descripcion = Objects.requireNonNullElse(descripcion, ""); }

    @Override
    public String getResumenPerfil() {
        return "Empresa del sector " + sector + " · NIT " + nit + ".";
    }
}
