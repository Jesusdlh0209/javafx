package co.conectaempleo.model;

public enum EstadoPostulacion {
    PENDIENTE("Pendiente"), EN_REVISION("En revisión"), ACEPTADA("Aceptada"), RECHAZADA("Rechazada"), RETIRADA("Retirada");

    private final String etiqueta;
    EstadoPostulacion(String etiqueta) { this.etiqueta = etiqueta; }
    public String getEtiqueta() { return etiqueta; }
}
