package co.conectaempleo.model;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

public final class Habilidad implements Serializable {
    @Serial private static final long serialVersionUID = 1L;
    private final String id;
    private String nombre;
    private String categoria;
    private boolean demo;

    public Habilidad(String id, String nombre, String categoria) {
        this.id = Objects.requireNonNull(id);
        this.nombre = Objects.requireNonNull(nombre);
        this.categoria = Objects.requireNonNull(categoria);
    }
    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = Objects.requireNonNull(nombre); }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = Objects.requireNonNull(categoria); }
    public boolean isDemo() { return demo; }
    public void setDemo(boolean demo) { this.demo = demo; }
}
