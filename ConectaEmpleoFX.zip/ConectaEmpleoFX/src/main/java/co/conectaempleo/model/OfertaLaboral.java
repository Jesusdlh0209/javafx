package co.conectaempleo.model;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.math.BigDecimal;
import java.time.LocalDate;

public final class OfertaLaboral implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String empresaId;
    private final String empresaNombre;
    private String cargo;
    private String descripcion;
    private ArrayList<String> habilidadesRequeridas;
    private int vacantes;
    private boolean activa;
    private String requisitos = "";
    private String ubicacion = "";
    private String tipoContrato = "";
    private BigDecimal salario;
    private LocalDate fechaPublicacion = LocalDate.now();
    private LocalDate fechaLimite;
    private boolean demo;

    public OfertaLaboral(String id, String empresaId, String empresaNombre,
                         String cargo, String descripcion,
                         List<String> habilidadesRequeridas, int vacantes) {
        this.id = Objects.requireNonNull(id, "id");
        this.empresaId = Objects.requireNonNull(empresaId, "empresaId");
        this.empresaNombre = Objects.requireNonNull(empresaNombre, "empresaNombre");
        this.cargo = Objects.requireNonNull(cargo, "cargo");
        this.descripcion = Objects.requireNonNull(descripcion, "descripcion");
        this.habilidadesRequeridas = new ArrayList<>(habilidadesRequeridas);
        this.vacantes = vacantes;
        this.activa = true;
    }

    public OfertaLaboral(String id, String empresaId, String empresaNombre,
                         String cargo, String descripcion, String requisitos,
                         List<String> habilidadesRequeridas, String ubicacion,
                         String tipoContrato, BigDecimal salario,
                         LocalDate fechaPublicacion, LocalDate fechaLimite,
                         int vacantes, boolean activa) {
        this(id, empresaId, empresaNombre, cargo, descripcion, habilidadesRequeridas, vacantes);
        this.requisitos = Objects.requireNonNullElse(requisitos, "");
        this.ubicacion = Objects.requireNonNullElse(ubicacion, "");
        this.tipoContrato = Objects.requireNonNullElse(tipoContrato, "");
        this.salario = salario;
        this.fechaPublicacion = Objects.requireNonNullElse(fechaPublicacion, LocalDate.now());
        this.fechaLimite = fechaLimite;
        this.activa = activa;
    }

    public String getId() { return id; }
    public String getEmpresaId() { return empresaId; }
    public String getEmpresaNombre() { return empresaNombre; }
    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = Objects.requireNonNull(cargo); }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = Objects.requireNonNull(descripcion); }
    public ArrayList<String> getHabilidadesRequeridas() { return new ArrayList<>(habilidadesRequeridas); }
    public void setHabilidadesRequeridas(List<String> habilidades) { this.habilidadesRequeridas = new ArrayList<>(habilidades); }
    public int getVacantes() { return vacantes; }
    public void setVacantes(int vacantes) { this.vacantes = vacantes; }
    public boolean isActiva() { return activa && !estaVencida(); }
    public void setActiva(boolean activa) { this.activa = activa; }
    public EstadoOferta getEstado() {
        if (!activa) return EstadoOferta.CERRADA;
        return estaVencida() ? EstadoOferta.VENCIDA : EstadoOferta.PUBLICADA;
    }
    public void setEstado(EstadoOferta estado) { this.activa = estado == EstadoOferta.PUBLICADA; }
    public boolean isDemo() { return demo; }
    public void setDemo(boolean demo) { this.demo = demo; }
    public String getRequisitos() { return Objects.requireNonNullElse(requisitos, ""); }
    public void setRequisitos(String requisitos) { this.requisitos = Objects.requireNonNullElse(requisitos, ""); }
    public String getUbicacion() { return Objects.requireNonNullElse(ubicacion, ""); }
    public void setUbicacion(String ubicacion) { this.ubicacion = Objects.requireNonNullElse(ubicacion, ""); }
    public String getTipoContrato() { return Objects.requireNonNullElse(tipoContrato, ""); }
    public void setTipoContrato(String tipoContrato) { this.tipoContrato = Objects.requireNonNullElse(tipoContrato, ""); }
    public BigDecimal getSalario() { return salario; }
    public void setSalario(BigDecimal salario) { this.salario = salario; }
    public LocalDate getFechaPublicacion() { return fechaPublicacion == null ? LocalDate.now() : fechaPublicacion; }
    public void setFechaPublicacion(LocalDate fechaPublicacion) { this.fechaPublicacion = Objects.requireNonNullElse(fechaPublicacion, LocalDate.now()); }
    public LocalDate getFechaLimite() { return fechaLimite; }
    public void setFechaLimite(LocalDate fechaLimite) { this.fechaLimite = fechaLimite; }
    public boolean estaVencida() { return fechaLimite != null && fechaLimite.isBefore(LocalDate.now()); }
}
