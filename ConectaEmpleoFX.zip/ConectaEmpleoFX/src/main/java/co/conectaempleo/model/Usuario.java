package co.conectaempleo.model;

import java.io.Serializable;
import java.util.Objects;
import co.conectaempleo.security.PasswordHasher;

/** Base común de las cuentas del sistema. */
public abstract class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String id;
    private String nombre;
    private String nombreUsuario;
    /** Campo heredado solo para migrar archivos antiguos; se vacía al migrarlos. */
    private String claveDemo;
    private String passwordHash;
    private final RolUsuario rol;
    private boolean demo;

    protected Usuario(String id, String nombre, String nombreUsuario,
                      String claveDemo, RolUsuario rol) {
        this.id = Objects.requireNonNull(id, "id");
        this.nombre = Objects.requireNonNull(nombre, "nombre");
        this.nombreUsuario = Objects.requireNonNull(nombreUsuario, "nombreUsuario");
        Objects.requireNonNull(claveDemo, "claveDemo");
        this.passwordHash = PasswordHasher.hash(claveDemo.toCharArray());
        this.rol = Objects.requireNonNull(rol, "rol");
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = Objects.requireNonNull(nombre, "nombre");
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = Objects.requireNonNull(nombreUsuario, "nombreUsuario");
    }

    public void setClaveDemo(String claveDemo) {
        if (claveDemo != null && !claveDemo.isBlank()) {
            this.passwordHash = PasswordHasher.hash(claveDemo.toCharArray());
            this.claveDemo = null;
        }
    }

    public RolUsuario getRol() {
        return rol;
    }

    public boolean isDemo() { return demo; }

    public void setDemo(boolean demo) { this.demo = demo; }

    /** Valida la clave local de la cuenta del proyecto de aula. */
    public boolean validarClave(String clave) {
        if (clave == null) return false;
        if (passwordHash != null) return PasswordHasher.verificar(clave.toCharArray(), passwordHash);
        return claveDemo != null && claveDemo.equals(clave);
    }

    public boolean necesitaMigrarClave() {
        return passwordHash == null && claveDemo != null;
    }

    public void migrarClaveLegada(String clave) {
        if (necesitaMigrarClave() && claveDemo.equals(clave)) setClaveDemo(clave);
    }

    public abstract String getResumenPerfil();
}
