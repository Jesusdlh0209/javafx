package co.conectaempleo.model;

import java.util.EnumSet;
import java.util.List;

/** Catálogo central de formularios, columnas y permisos de navegación. */
public enum ModuloGestion {
    TRABAJADORES("Trabajadores", "Directorio y perfiles profesionales",
            List.of("Cédula", "Nombre", "Usuario", "Contraseña", "Correo electrónico (opcional)",
                    "Teléfono (opcional)", "Ubicación (opcional)", "Perfil profesional (opcional)",
                    "Habilidades (separadas por coma)", "Disponibilidad"),
            List.of("Iniciales", "Cédula", "Nombre", "Usuario", "Correo", "Teléfono", "Ubicación", "Habilidades", "Disponibilidad", "Origen"),
            EnumSet.of(RolUsuario.ADMINISTRADOR, RolUsuario.TRABAJADOR)),
    EMPRESAS("Empresas", "Directorio y perfiles de empresas",
            List.of("NIT", "Nombre de empresa", "Usuario", "Contraseña", "Sector", "Dirección (opcional)",
                    "Teléfono (opcional)", "Correo electrónico (opcional)", "Descripción (opcional)"),
            List.of("NIT", "Empresa", "Usuario", "Sector", "Correo", "Teléfono", "Dirección", "Ofertas", "Origen"),
            EnumSet.of(RolUsuario.ADMINISTRADOR, RolUsuario.EMPRESA)),
    OFERTAS("Ofertas laborales", "Publica y consulta oportunidades laborales",
            List.of("Empresa (ID o NIT; solo admin)", "Cargo", "Descripción", "Requisitos",
                    "Habilidades requeridas (separadas por coma)", "Ubicación", "Tipo de contrato",
                    "Salario mensual (opcional)", "Fecha límite AAAA-MM-DD (opcional)", "Vacantes"),
            List.of("Empresa", "Cargo", "Ubicación", "Contrato", "Salario", "Publicado", "Fecha límite", "Habilidades", "Vacantes", "Estado", "Origen"),
            EnumSet.allOf(RolUsuario.class)),
    POSTULACIONES("Postulaciones", "Seguimiento de candidatos y procesos",
            List.of(), List.of("Trabajador", "Oferta", "Empresa", "Fecha", "Estado", "Origen"), EnumSet.allOf(RolUsuario.class)),
    HABILIDADES("Habilidades", "Catálogo de competencias laborales",
            List.of("Nombre", "Categoría"), List.of("Habilidad", "Categoría", "Origen"),
            EnumSet.of(RolUsuario.ADMINISTRADOR, RolUsuario.TRABAJADOR)),
    CAPACITACIONES("Capacitaciones", "Oferta de formación para el empleo",
            List.of("Nombre", "Habilidad relacionada", "Entidad formadora", "Descripción (opcional)", "Duración en horas", "Fecha de inicio (opcional)", "Cupos", "Estado (Disponible o Cerrada)"),
            List.of("Capacitación", "Habilidad", "Entidad", "Descripción", "Duración", "Fecha", "Cupos", "Participantes", "Estado", "Origen"),
            EnumSet.of(RolUsuario.ADMINISTRADOR, RolUsuario.TRABAJADOR)),
    MATERIALES("Materiales reciclables", "Inventario local de materiales",
            List.of("Nombre", "Categoría", "Cantidad", "Unidad", "Ubicación", "Estado", "Descripción"),
            List.of("Material", "Categoría", "Cantidad", "Unidad", "Ubicación", "Estado", "Descripción", "Origen"),
            EnumSet.of(RolUsuario.ADMINISTRADOR)),
    DOCUMENTOS("Documentos y hojas de vida", "Adjunta y consulta hojas de vida en PDF",
            List.of(), List.of("Trabajador", "Cédula", "Documento PDF", "Origen"),
            EnumSet.of(RolUsuario.ADMINISTRADOR, RolUsuario.TRABAJADOR));

    private final String titulo;
    private final String descripcion;
    private final List<String> campos;
    private final List<String> columnas;
    private final EnumSet<RolUsuario> roles;

    ModuloGestion(String titulo, String descripcion, List<String> campos,
                  List<String> columnas, EnumSet<RolUsuario> roles) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.campos = campos;
        this.columnas = columnas;
        this.roles = roles;
    }

    public String getTitulo() { return titulo; }
    public String getDescripcion() { return descripcion; }
    public List<String> getCampos() { return campos; }
    public List<String> getColumnas() { return columnas; }
    public boolean permite(RolUsuario rol) { return roles.contains(rol); }
}
