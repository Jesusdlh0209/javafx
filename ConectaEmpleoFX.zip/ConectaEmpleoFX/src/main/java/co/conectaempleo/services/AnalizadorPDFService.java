package co.conectaempleo.services;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.text.Normalizer;
import java.util.Objects;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

/** Lee texto y metadatos de una hoja de vida con PDFBox, sin inferir datos personales. */
public final class AnalizadorPDFService {
    private static final List<String> HABILIDADES = List.of(
            "java", "ventas", "atención al cliente", "redes sociales", "excel", "cocina",
            "contabilidad", "servicio al cliente", "programación", "marketing", "diseño",
            "administración", "liderazgo", "inglés", "logística", "inventario",
            "seguridad industrial", "gestión ambiental", "trabajo en equipo", "reciclaje");

    public AnalisisHojaVida analizar(Path archivo) throws IOException {
        Objects.requireNonNull(archivo, "archivo");
        try (PDDocument documento = Loader.loadPDF(archivo.toFile())) {
            if (documento.isEncrypted()) {
                throw new IOException("El PDF está protegido con contraseña y no se puede analizar.");
            }
            String texto = new PDFTextStripper().getText(documento);
            String normalizado = normalizar(texto);
            ArrayList<String> sugeridas = new ArrayList<>();
            for (String habilidad : HABILIDADES) {
                if (normalizado.contains(normalizar(habilidad))) {
                    sugeridas.add(habilidad.substring(0, 1).toUpperCase(Locale.ROOT) + habilidad.substring(1));
                }
            }
            String titulo = documento.getDocumentInformation() == null
                    ? "" : Objects.requireNonNullElse(documento.getDocumentInformation().getTitle(), "").trim();
            return new AnalisisHojaVida(archivo.getFileName().toString(), documento.getNumberOfPages(),
                    titulo, texto.length(), sugeridas);
        } catch (IOException ex) {
            throw new IOException("No se pudo leer el PDF. Puede estar dañado, cifrado o usar un formato no compatible. Detalle: "
                    + Objects.requireNonNullElse(ex.getMessage(), "error de lectura"), ex);
        }
    }

    private static String normalizar(String valor) {
        return Normalizer.normalize(valor.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
    }
}
