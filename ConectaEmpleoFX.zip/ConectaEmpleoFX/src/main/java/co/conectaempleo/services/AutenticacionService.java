package co.conectaempleo.services;

import co.conectaempleo.repository.RepositorioLocal;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Usuario;
import java.util.Objects;
import java.util.Optional;

public final class AutenticacionService {

    private final RepositorioLocal repositorio;

    public AutenticacionService(RepositorioLocal repositorio) {
        this.repositorio = Objects.requireNonNull(repositorio, "repositorio");
    }

    public Optional<Usuario> autenticar(String nombreUsuario, String clave,
                                        RolUsuario rolSeleccionado) {
        if (nombreUsuario == null || nombreUsuario.isBlank()
                || clave == null || clave.isEmpty() || rolSeleccionado == null) {
            return Optional.empty();
        }

        String usuarioNormalizado = nombreUsuario.trim();
        Optional<Usuario> encontrado = repositorio.listarUsuarios().stream()
                .filter(usuario -> usuario.getNombreUsuario()
                        .equalsIgnoreCase(usuarioNormalizado))
                .filter(usuario -> usuario.getRol() == rolSeleccionado)
                .filter(usuario -> usuario.validarClave(clave))
                .findFirst();
        encontrado.filter(Usuario::necesitaMigrarClave).ifPresent(usuario -> {
            usuario.migrarClaveLegada(clave);
            repositorio.guardarUsuario(usuario);
        });
        return encontrado;
    }

    public void cambiarClave(Usuario usuario, String claveActual, String claveNueva) {
        Objects.requireNonNull(usuario, "usuario");
        if (!usuario.validarClave(claveActual)) throw new IllegalArgumentException("La contraseña actual no coincide.");
        if (claveNueva == null || claveNueva.length() < 8) throw new IllegalArgumentException("La nueva contraseña debe tener al menos 8 caracteres.");
        usuario.setClaveDemo(claveNueva);
        repositorio.guardarUsuario(usuario);
    }
}
