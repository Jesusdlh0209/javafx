package co.conectaempleo.services;

import co.conectaempleo.model.Capacitacion;
import co.conectaempleo.model.Empresa;
import co.conectaempleo.viewmodel.FilaModulo;
import co.conectaempleo.model.Habilidad;
import co.conectaempleo.model.MaterialReciclable;
import co.conectaempleo.model.ModuloGestion;
import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.Postulacion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.config.InicializadorDatos;
import co.conectaempleo.repository.RepositorioLocal;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Reglas de negocio de ConectaEmpleo; no contiene controles de interfaz. */
public final class ServicioConectaEmpleo {

    private final RepositorioLocal repositorio;
    private final DocumentoService documentos;
    private final TrabajadorService trabajadores;
    private final EmpresaService empresas;
    private final OfertaService ofertas;
    private final PostulacionService postulaciones;
    private final CatalogoService catalogos;

    public ServicioConectaEmpleo(RepositorioLocal repositorio) {
        this.repositorio = Objects.requireNonNull(repositorio);
        this.documentos = new DocumentoService(repositorio);
        this.trabajadores = new TrabajadorService(repositorio);
        this.empresas = new EmpresaService(repositorio);
        this.ofertas = new OfertaService(repositorio);
        this.postulaciones = new PostulacionService(repositorio);
        this.catalogos = new CatalogoService(repositorio);
    }

    public AutenticacionService autenticacion() { return new AutenticacionService(repositorio); }
    public int contarTrabajadores() { return (int) repositorio.listarTrabajadores().stream().filter(x -> !x.isDemo()).count(); }
    public int contarEmpresas() { return (int) repositorio.listarEmpresas().stream().filter(x -> !x.isDemo()).count(); }
    public int contarOfertasActivas() { return (int) repositorio.listarOfertas().stream().filter(x -> !x.isDemo() && x.isActiva()).count(); }
    public int contarPostulaciones() { return (int) repositorio.listarPostulaciones().stream().filter(x -> !x.isDemo()).count(); }
    public int contarTrabajadoresDemo() { return (int) repositorio.listarTrabajadores().stream().filter(Trabajador::isDemo).count(); }
    public int contarEmpresasDemo() { return (int) repositorio.listarEmpresas().stream().filter(Empresa::isDemo).count(); }
    public int contarOfertasDemo() { return (int) repositorio.listarOfertas().stream().filter(OfertaLaboral::isDemo).count(); }
    public int contarPostulacionesDemo() { return (int) repositorio.listarPostulaciones().stream().filter(Postulacion::isDemo).count(); }
    public Path getArchivoDatos() { return repositorio.getArchivoDatos(); }
    public Trabajador buscarTrabajador(String id) { return repositorio.buscarTrabajador(id); }
    public Empresa buscarEmpresa(String id) { return repositorio.buscarEmpresa(id); }
    public OfertaLaboral buscarOferta(String id) { return repositorio.buscarOferta(id); }
    public Postulacion buscarPostulacion(String id) { return postulaciones.buscar(id); }
    public ArrayList<Trabajador> listarTrabajadores() { return repositorio.listarTrabajadores(); }
    public ArrayList<Empresa> listarEmpresas() { return repositorio.listarEmpresas(); }
    public ArrayList<OfertaLaboral> listarOfertas() { return repositorio.listarOfertas(); }
    public ArrayList<Postulacion> listarPostulaciones() { return repositorio.listarPostulaciones(); }
    public ArrayList<Habilidad> listarHabilidades() { return repositorio.listarHabilidades(); }
    public ArrayList<Capacitacion> listarCapacitaciones() { return repositorio.listarCapacitaciones(); }
    public ArrayList<MaterialReciclable> listarMateriales() { return repositorio.listarMateriales(); }
    public boolean tieneDocumento(String trabajadorId) { return documentos.tieneDocumento(trabajadorId); }
    public AnalisisHojaVida analizarDocumento(String trabajadorId, Usuario actor) throws IOException {
        return documentos.analizar(trabajadorId, actor);
    }

    public void restaurarDatosDemostracion(Usuario actor) {
        exigirAdministrador(Objects.requireNonNull(actor, "actor"));
        InicializadorDatos.restaurarDemostracion(repositorio);
    }

    public ArrayList<FilaModulo> listar(ModuloGestion modulo, Usuario usuario, String filtro) {
        validarAcceso(modulo, usuario);
        String q = filtro == null ? "" : filtro.trim().toLowerCase(Locale.ROOT);
        ArrayList<FilaModulo> filas = new ArrayList<>();
        switch (modulo) {
            case TRABAJADORES -> repositorio.listarTrabajadores().stream()
                    .filter(x -> usuario.getRol() != RolUsuario.TRABAJADOR || x.getId().equals(usuario.getId()))
                    .forEach(x -> agregarSiCoincide(filas, q, x.getId(), iniciales(x.getNombre()), x.getCedula(), x.getNombre(), x.getNombreUsuario(),
                            x.getCorreo(), x.getTelefono(), x.getUbicacion(), String.join(", ", x.getHabilidades()),
                            x.getDisponibilidad(), origen(x.isDemo())));
            case EMPRESAS -> repositorio.listarEmpresas().stream()
                    .filter(x -> usuario.getRol() != RolUsuario.EMPRESA || x.getId().equals(usuario.getId()))
                    .forEach(x -> agregarSiCoincide(filas, q, x.getId(), x.getNit(), x.getNombre(), x.getNombreUsuario(),
                            x.getSector(), x.getCorreo(), x.getTelefono(), x.getDireccion(),
                            Long.toString(repositorio.listarOfertas().stream().filter(o -> o.getEmpresaId().equals(x.getId())).count()), origen(x.isDemo())));
            case OFERTAS -> repositorio.listarOfertas().stream()
                    .filter(x -> usuario.getRol() != RolUsuario.EMPRESA || x.getEmpresaId().equals(usuario.getId()))
                    .filter(x -> usuario.getRol() != RolUsuario.TRABAJADOR || x.isActiva() && !x.estaVencida())
                    .forEach(x -> agregarSiCoincide(filas, q, x.getId(), x.getEmpresaNombre(), x.getCargo(), x.getUbicacion(),
                            x.getTipoContrato(), x.getSalario() == null ? "Por acordar" : x.getSalario().toPlainString(),
                            x.getFechaPublicacion() == null ? "Sin fecha" : x.getFechaPublicacion().toString(),
                            x.getFechaLimite() == null ? "Sin límite" : x.getFechaLimite().toString(),
                            String.join(", ", x.getHabilidadesRequeridas()), Integer.toString(x.getVacantes()),
                            x.estaVencida() ? "Vencida" : x.isActiva() ? "Publicada" : "Cerrada", origen(x.isDemo())));
            case POSTULACIONES -> repositorio.listarPostulaciones().stream()
                    .filter(x -> usuario.getRol() == RolUsuario.ADMINISTRADOR
                            || usuario.getRol() == RolUsuario.EMPRESA && x.getEmpresaId().equals(usuario.getId())
                            || usuario.getRol() == RolUsuario.TRABAJADOR && x.getTrabajadorId().equals(usuario.getId()))
                    .forEach(x -> {
                        Empresa empresa = repositorio.buscarEmpresa(x.getEmpresaId());
                        agregarSiCoincide(filas, q, x.getId(), x.getTrabajadorNombre(), x.getOfertaCargo(),
                                empresa == null ? x.getEmpresaId() : empresa.getNombre(),
                                x.getFechaPostulacion().toLocalDate().toString(), x.getEstado(), origen(x.isDemo()));
                    });
            case HABILIDADES -> repositorio.listarHabilidades().forEach(x -> agregarSiCoincide(filas, q, x.getId(), x.getNombre(), x.getCategoria(), origen(x.isDemo())));
            case CAPACITACIONES -> repositorio.listarCapacitaciones().forEach(x -> agregarSiCoincide(filas, q, x.getId(), x.getNombre(), x.getHabilidad(), x.getEntidad(),
                    x.getDescripcion(), x.getDuracionHoras() == 0 ? "Por definir" : x.getDuracionHoras() + " h",
                    x.getFechaInicio() == null ? "Por definir" : x.getFechaInicio().toString(),
                    x.getParticipantes().size() + "/" + x.getCupos(), Integer.toString(x.getParticipantes().size()),
                    x.isActiva() ? "Disponible" : "Cerrada", origen(x.isDemo())));
            case MATERIALES -> repositorio.listarMateriales().forEach(x -> agregarSiCoincide(filas, q, x.getId(), x.getNombre(), x.getCategoria(),
                    String.valueOf(x.getCantidad()), x.getUnidad(), x.getUbicacion(), x.getEstado(), x.getDescripcion(), origen(x.isDemo())));
            case DOCUMENTOS -> repositorio.listarTrabajadores().stream()
                    .filter(x -> usuario.getRol() == RolUsuario.ADMINISTRADOR || x.getId().equals(usuario.getId()))
                    .forEach(x -> {
                        var documento = documentos.migrarRutaLegada(x);
                        if (documento == null) documento = documentos.buscar(x.getId());
                        if (documento == null) return;
                        String detalle = documento.getNombreOriginal()
                                + " · " + Math.max(1, documento.getTamanoBytes() / 1024) + " KB";
                        agregarSiCoincide(filas, q, x.getId(), x.getNombre(), x.getCedula(), detalle, origen(x.isDemo()));
                    });
        }
        return filas;
    }

    private void agregarSiCoincide(ArrayList<FilaModulo> destino, String q, String id, String... valores) {
        String concatenado = (id + " " + String.join(" ", valores)).toLowerCase(Locale.ROOT);
        if (q.isEmpty() || concatenado.contains(q)) destino.add(new FilaModulo(id, Arrays.asList(valores)));
    }

    private static String origen(boolean demo) { return demo ? "DEMOSTRACIÓN" : "REGISTRO"; }
    private static String iniciales(String nombre) {
        String[] partes = nombre == null ? new String[0] : nombre.trim().split("\\s+");
        if (partes.length == 0 || partes[0].isBlank()) return "?";
        return (partes[0].substring(0, 1) + (partes.length > 1 ? partes[partes.length - 1].substring(0, 1) : ""))
                .toUpperCase(Locale.ROOT);
    }

    public void crear(ModuloGestion modulo, List<String> campos, Usuario actor) {
        validarAcceso(modulo, actor);
        validarCampos(campos, modulo, false);
        String id = nuevoId(modulo);
        switch (modulo) {
            case TRABAJADORES -> {
                exigirAdministrador(actor);
                validarClaveNueva(campo(campos, 3));
                validarCorreo(campo(campos, 4));
                Trabajador x = new Trabajador(id, campo(campos, 1), campo(campos, 2), campo(campos, 3),
                        campo(campos, 0), campo(campos, 4), campo(campos, 5), campo(campos, 6),
                        campo(campos, 7), dividir(campo(campos, 8)), campo(campos, 9));
                trabajadores.guardar(x, actor);
            }
            case EMPRESAS -> {
                exigirAdministrador(actor);
                validarClaveNueva(campo(campos, 3));
                validarCorreo(campo(campos, 7));
                empresas.guardar(new Empresa(id, campo(campos, 1), campo(campos, 2), campo(campos, 3),
                        campo(campos, 0), campo(campos, 4), campo(campos, 5), campo(campos, 6), campo(campos, 7), campo(campos, 8)), actor);
            }
            case OFERTAS -> {
                Empresa empresa = resolverEmpresa(campo(campos, 0), actor);
                int vacantes = enteroPositivo(campo(campos, 9), "La cantidad de vacantes debe ser mayor que cero.");
                OfertaLaboral oferta = new OfertaLaboral(id, empresa.getId(), empresa.getNombre(), campo(campos, 1),
                        campo(campos, 2), campo(campos, 3), dividir(campo(campos, 4)), campo(campos, 5), campo(campos, 6),
                        salario(campo(campos, 7)), LocalDate.now(), fecha(campo(campos, 8)), vacantes, true);
                ofertas.guardar(oferta, actor);
            }
            case HABILIDADES -> catalogos.guardar(new Habilidad(id, campo(campos, 0), campo(campos, 1)), actor);
            case CAPACITACIONES -> {
                Capacitacion curso = new Capacitacion(id, campo(campos, 0), campo(campos, 1), campo(campos, 2));
                curso.setDescripcion(campo(campos, 3)); curso.setDuracionHoras(enteroPositivo(campo(campos, 4), "La duración debe ser mayor que cero."));
                curso.setFechaInicio(fecha(campo(campos, 5))); curso.setCupos(enteroPositivo(campo(campos, 6), "Los cupos deben ser mayores que cero."));
                curso.setActiva(!"Cerrada".equalsIgnoreCase(campo(campos, 7)));
                catalogos.guardar(curso, actor);
            }
            case MATERIALES -> {
                exigirAdministrador(actor);
                double cantidad = decimalNoNegativo(campo(campos, 2));
                MaterialReciclable material = new MaterialReciclable(id, campo(campos, 0), campo(campos, 1), cantidad, campo(campos, 3));
                material.setUbicacion(campo(campos, 4));
                material.setEstado(campo(campos, 5));
                material.setDescripcion(campo(campos, 6));
                catalogos.guardar(material, actor);
            }
            default -> throw new IllegalArgumentException("Este módulo no permite crear registros desde este formulario.");
        }
    }

    public void actualizar(ModuloGestion modulo, String id, List<String> campos, Usuario actor) {
        validarAcceso(modulo, actor);
        validarCampos(campos, modulo, true);
        switch (modulo) {
            case TRABAJADORES -> {
                Trabajador anterior = requerir(repositorio.buscarTrabajador(id), "No se encontró el trabajador.");
                boolean administrador = actor.getRol() == RolUsuario.ADMINISTRADOR;
                if (!administrador && (!(actor instanceof Trabajador) || !actor.getId().equals(id))) {
                    throw new IllegalArgumentException("Solo puedes editar tu propio perfil.");
                }
                anterior.setNombre(campo(campos, 1));
                if (administrador) {
                    anterior.setNombreUsuario(campo(campos, 2));
                    anterior.setCedula(campo(campos, 0));
                }
                actualizarClave(anterior, campo(campos, 3));
                validarCorreo(campo(campos, 4));
                anterior.setCorreo(campo(campos, 4));
                anterior.setTelefono(campo(campos, 5));
                anterior.setUbicacion(campo(campos, 6));
                anterior.setPerfilProfesional(campo(campos, 7));
                anterior.setHabilidades(dividir(campo(campos, 8)));
                anterior.setDisponibilidad(campo(campos, 9));
                trabajadores.guardar(anterior, actor);
            }
            case EMPRESAS -> {
                Empresa anterior = requerir(repositorio.buscarEmpresa(id), "No se encontró la empresa.");
                boolean administrador = actor.getRol() == RolUsuario.ADMINISTRADOR;
                if (!administrador && (!(actor instanceof Empresa) || !actor.getId().equals(id))) {
                    throw new IllegalArgumentException("Solo puedes editar el perfil de tu empresa.");
                }
                anterior.setNombre(campo(campos, 1));
                if (administrador) {
                    anterior.setNombreUsuario(campo(campos, 2));
                    anterior.setNit(campo(campos, 0));
                }
                actualizarClave(anterior, campo(campos, 3));
                anterior.setSector(campo(campos, 4));
                anterior.setDireccion(campo(campos, 5));
                anterior.setTelefono(campo(campos, 6));
                validarCorreo(campo(campos, 7));
                anterior.setCorreo(campo(campos, 7));
                anterior.setDescripcion(campo(campos, 8));
                empresas.guardar(anterior, actor);
            }
            case OFERTAS -> {
                OfertaLaboral anterior = requerir(repositorio.buscarOferta(id), "No se encontró la oferta.");
                if (actor.getRol() == RolUsuario.EMPRESA && !anterior.getEmpresaId().equals(actor.getId())) throw new IllegalArgumentException("Solo puedes editar tus ofertas.");
                Empresa empresa = resolverEmpresa(campo(campos, 0), actor);
                if (!anterior.getEmpresaId().equals(empresa.getId())) throw new IllegalArgumentException("Una oferta no puede cambiar de empresa.");
                anterior.setCargo(campo(campos, 1));
                anterior.setDescripcion(campo(campos, 2));
                anterior.setRequisitos(campo(campos, 3));
                anterior.setHabilidadesRequeridas(dividir(campo(campos, 4)));
                anterior.setUbicacion(campo(campos, 5));
                anterior.setTipoContrato(campo(campos, 6));
                anterior.setSalario(salario(campo(campos, 7)));
                anterior.setFechaLimite(fecha(campo(campos, 8)));
                anterior.setVacantes(enteroPositivo(campo(campos, 9), "Vacantes inválidas."));
                ofertas.guardar(anterior, actor);
            }
            case HABILIDADES -> {
                exigirAdministrador(actor);
                Habilidad habilidad = buscarHabilidad(id);
                habilidad.setNombre(campo(campos, 0));
                habilidad.setCategoria(campo(campos, 1));
                catalogos.guardar(habilidad, actor);
            }
            case CAPACITACIONES -> {
                exigirAdministrador(actor);
                Capacitacion curso = buscarCapacitacion(id);
                curso.setNombre(campo(campos, 0));
                curso.setHabilidad(campo(campos, 1));
                curso.setEntidad(campo(campos, 2));
                curso.setDescripcion(campo(campos, 3));
                curso.setDuracionHoras(enteroPositivo(campo(campos, 4), "La duración debe ser mayor que cero."));
                curso.setFechaInicio(fecha(campo(campos, 5)));
                curso.setCupos(enteroPositivo(campo(campos, 6), "Los cupos deben ser mayores que cero."));
                curso.setActiva(!"Cerrada".equalsIgnoreCase(campo(campos, 7)));
                catalogos.guardar(curso, actor);
            }
            case MATERIALES -> {
                exigirAdministrador(actor);
                MaterialReciclable material = buscarMaterial(id);
                material.setNombre(campo(campos, 0));
                material.setCategoria(campo(campos, 1));
                material.setCantidad(decimalNoNegativo(campo(campos, 2)));
                material.setUnidad(campo(campos, 3));
                material.setUbicacion(campo(campos, 4));
                material.setEstado(campo(campos, 5));
                material.setDescripcion(campo(campos, 6));
                catalogos.guardar(material, actor);
            }
            default -> throw new IllegalArgumentException("Este módulo no permite editar registros.");
        }
    }

    public ArrayList<String> obtenerCamposFormulario(ModuloGestion modulo, String id, Usuario actor) {
        validarAcceso(modulo, actor);
        ArrayList<String> valores = new ArrayList<>();
        switch (modulo) {
            case TRABAJADORES -> {
                Trabajador x = requerir(repositorio.buscarTrabajador(id), "No se encontró el trabajador.");
                if (actor.getRol() != RolUsuario.ADMINISTRADOR && !actor.getId().equals(id)) throw new IllegalArgumentException("Solo puedes editar tu propio perfil.");
                valores.addAll(List.of(x.getCedula(), x.getNombre(), x.getNombreUsuario(), "", x.getCorreo(), x.getTelefono(),
                        x.getUbicacion(), x.getPerfilProfesional(), String.join(", ", x.getHabilidades()), x.getDisponibilidad()));
            }
            case EMPRESAS -> {
                Empresa x = requerir(repositorio.buscarEmpresa(id), "No se encontró la empresa.");
                if (actor.getRol() != RolUsuario.ADMINISTRADOR && !actor.getId().equals(id)) throw new IllegalArgumentException("Solo puedes editar tu propia empresa.");
                valores.addAll(List.of(x.getNit(), x.getNombre(), x.getNombreUsuario(), "", x.getSector(), x.getDireccion(),
                        x.getTelefono(), x.getCorreo(), x.getDescripcion()));
            }
            case OFERTAS -> {
                OfertaLaboral x = requerir(repositorio.buscarOferta(id), "No se encontró la oferta.");
                if (actor.getRol() == RolUsuario.EMPRESA && !x.getEmpresaId().equals(actor.getId())) throw new IllegalArgumentException("No puedes editar la oferta de otra empresa.");
                valores.addAll(List.of(x.getEmpresaId(), x.getCargo(), x.getDescripcion(), x.getRequisitos(),
                        String.join(", ", x.getHabilidadesRequeridas()), x.getUbicacion(), x.getTipoContrato(),
                        x.getSalario() == null ? "" : x.getSalario().toPlainString(),
                        x.getFechaLimite() == null ? "" : x.getFechaLimite().toString(), Integer.toString(x.getVacantes())));
            }
            case HABILIDADES -> {
                Habilidad x = repositorio.listarHabilidades().stream().filter(a -> a.getId().equals(id)).findFirst().orElseThrow(() -> new IllegalArgumentException("No se encontró la habilidad."));
                valores.addAll(List.of(x.getNombre(), x.getCategoria()));
            }
            case CAPACITACIONES -> {
                Capacitacion x = repositorio.listarCapacitaciones().stream().filter(a -> a.getId().equals(id)).findFirst().orElseThrow(() -> new IllegalArgumentException("No se encontró la capacitación."));
                valores.addAll(List.of(x.getNombre(), x.getHabilidad(), x.getEntidad(), x.getDescripcion(),
                        Integer.toString(x.getDuracionHoras()), x.getFechaInicio() == null ? "" : x.getFechaInicio().toString(),
                        Integer.toString(x.getCupos()), x.isActiva() ? "Disponible" : "Cerrada"));
            }
            case MATERIALES -> {
                MaterialReciclable x = repositorio.listarMateriales().stream().filter(a -> a.getId().equals(id)).findFirst().orElseThrow(() -> new IllegalArgumentException("No se encontró el material."));
                valores.addAll(List.of(x.getNombre(), x.getCategoria(), Double.toString(x.getCantidad()), x.getUnidad(),
                        x.getUbicacion(), x.getEstado(), x.getDescripcion()));
            }
            default -> throw new IllegalArgumentException("Este módulo no tiene formulario de edición.");
        }
        return valores;
    }

    public void eliminar(ModuloGestion modulo, String id, Usuario actor) throws IOException {
        validarAcceso(modulo, actor);
        switch (modulo) {
            case TRABAJADORES -> {
                exigirAdministrador(actor);
                trabajadores.validarEliminacion(id, actor);
                if (documentos.tieneDocumento(id)) documentos.eliminar(id, actor);
                trabajadores.eliminar(id, actor);
            }
            case EMPRESAS -> empresas.eliminar(id, actor);
            case OFERTAS -> ofertas.eliminar(id, actor);
            case HABILIDADES -> catalogos.eliminarHabilidad(id, actor);
            case CAPACITACIONES -> catalogos.eliminarCapacitacion(id, actor);
            case MATERIALES -> catalogos.eliminarMaterial(id, actor);
            case POSTULACIONES -> postulaciones.retirar(id, actor);
            case DOCUMENTOS -> documentos.eliminar(id, actor);
            default -> throw new IllegalArgumentException("Este módulo no permite eliminar registros.");
        }
    }

    public void postularse(String ofertaId, Usuario actor) {
        postulaciones.postular(ofertaId, actor);
    }

    public void agregarHabilidadPerfil(String habilidadId, Usuario actor) {
        catalogos.agregarHabilidadPerfil(habilidadId, actor);
    }

    public void inscribirseCapacitacion(String capacitacionId, Usuario actor) {
        catalogos.inscribir(capacitacionId, actor);
    }

    public void cambiarEstadoPostulacion(String id, String estado, Usuario actor) {
        postulaciones.cambiarEstado(id, estado, actor);
    }

    public void alternarEstadoOferta(String id, Usuario actor) {
        ofertas.alternarEstado(id, actor);
    }

    public void gestionarHojaVida(Path origen, Usuario actor) throws IOException { documentos.guardarHojaVida(origen, actor); }
    public void abrirDocumento(String trabajadorId, Usuario actor) throws IOException { documentos.abrir(trabajadorId, actor); }
    public boolean existeDocumento(String trabajadorId) { return documentos.tieneDocumento(trabajadorId); }
    public void eliminarDocumento(String trabajadorId, Usuario actor) throws IOException { documentos.eliminar(trabajadorId, actor); }

    private Empresa resolverEmpresa(String empresaId, Usuario actor) {
        if (actor instanceof Empresa empresa) return empresa;
        return repositorio.listarEmpresas().stream().filter(x -> x.getId().equals(empresaId) || x.getNit().equals(empresaId))
                .findFirst().orElseThrow(() -> new IllegalArgumentException("Indica el ID o NIT de una empresa registrada."));
    }
    private static String nuevoId(ModuloGestion modulo) { return modulo.name().substring(0, Math.min(3, modulo.name().length())) + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT); }
    private static String campo(List<String> campos, int indice) { return campos.get(indice).trim(); }
    private static void validarCampos(List<String> campos, ModuloGestion modulo, boolean actualizacion) {
        if (campos.size() != modulo.getCampos().size()) throw new IllegalArgumentException("Formulario incompleto.");
        for (int i = 0; i < campos.size(); i++) {
            String etiqueta = modulo.getCampos().get(i).toLowerCase(Locale.ROOT);
            boolean claveVaciaEnEdicion = actualizacion && etiqueta.startsWith("contraseña")
                    && (campos.get(i) == null || campos.get(i).isBlank());
            boolean noObligatorio = etiqueta.contains("(opcional)");
            if (!claveVaciaEnEdicion && !noObligatorio && (campos.get(i) == null || campos.get(i).isBlank())) {
                throw new IllegalArgumentException("Completa todos los campos obligatorios.");
            }
        }
    }
    private static void validarClaveNueva(String clave) {
        if (clave == null || clave.length() < 8) throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres.");
    }
    private static void actualizarClave(Usuario usuario, String clave) {
        if (clave == null || clave.isBlank()) return;
        validarClaveNueva(clave);
        usuario.setClaveDemo(clave);
    }
    private static void validarCorreo(String correo) {
        if (correo != null && !correo.isBlank()
                && !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException("Escribe un correo electrónico válido.");
        }
    }
    private static BigDecimal salario(String valor) {
        if (valor == null || valor.isBlank()) return null;
        try {
            BigDecimal monto = new BigDecimal(valor.trim().replace(',', '.'));
            if (monto.signum() >= 0) return monto;
        } catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException("El salario debe ser un monto numérico igual o mayor que cero.");
    }
    private static LocalDate fecha(String valor) {
        if (valor == null || valor.isBlank()) return null;
        try { return LocalDate.parse(valor.trim()); }
        catch (java.time.format.DateTimeParseException ex) {
            throw new IllegalArgumentException("La fecha límite debe usar el formato AAAA-MM-DD.");
        }
    }
    private Habilidad buscarHabilidad(String id) {
        return repositorio.listarHabilidades().stream().filter(x -> x.getId().equals(id)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró la habilidad."));
    }
    private Capacitacion buscarCapacitacion(String id) {
        return repositorio.listarCapacitaciones().stream().filter(x -> x.getId().equals(id)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró la capacitación."));
    }
    private MaterialReciclable buscarMaterial(String id) {
        return repositorio.listarMateriales().stream().filter(x -> x.getId().equals(id)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró el material."));
    }
    private static int enteroPositivo(String valor, String mensaje) {
        try { int n = Integer.parseInt(valor); if (n > 0) return n; } catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException(mensaje);
    }
    private static double decimalNoNegativo(String valor) {
        try { double n = Double.parseDouble(valor.replace(',', '.')); if (Double.isFinite(n) && n >= 0) return n; } catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException("Escribe una cantidad numérica igual o mayor que cero.");
    }
    private static ArrayList<String> dividir(String texto) {
        return Arrays.stream(texto.split(",")).map(String::trim).filter(x -> !x.isEmpty()).distinct().collect(Collectors.toCollection(ArrayList::new));
    }
    private static <T> T requerir(T objeto, String mensaje) { if (objeto == null) throw new IllegalArgumentException(mensaje); return objeto; }
    private static void validarAcceso(ModuloGestion modulo, Usuario actor) {
        Objects.requireNonNull(actor, "actor");
        if (!modulo.permite(actor.getRol())) throw new IllegalArgumentException("Tu rol no tiene acceso a este módulo.");
    }
    private static void exigirAdministrador(Usuario actor) {
        if (actor.getRol() != RolUsuario.ADMINISTRADOR) throw new IllegalArgumentException("Solo el administrador puede realizar esta acción.");
    }
}
