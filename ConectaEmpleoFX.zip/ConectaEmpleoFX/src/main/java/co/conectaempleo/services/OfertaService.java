package co.conectaempleo.services;

import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import java.util.ArrayList;
import java.util.Objects;

/** Reglas de publicación, edición y vigencia de ofertas laborales. */
public final class OfertaService {
    private final RepositorioLocal repositorio;

    public OfertaService(RepositorioLocal repositorio) { this.repositorio = Objects.requireNonNull(repositorio); }
    public ArrayList<OfertaLaboral> listar() { return repositorio.listarOfertas(); }
    public OfertaLaboral buscar(String id) { return repositorio.buscarOferta(id); }

    public void guardar(OfertaLaboral oferta, Usuario actor) {
        Objects.requireNonNull(actor, "actor");
        if (actor.getRol() == RolUsuario.TRABAJADOR) throw new IllegalArgumentException("Un trabajador no puede publicar ofertas.");
        Empresa empresa = repositorio.buscarEmpresa(oferta.getEmpresaId());
        if (empresa == null) throw new IllegalArgumentException("La oferta debe pertenecer a una empresa registrada.");
        if (actor instanceof Empresa cuentaEmpresa && !cuentaEmpresa.getId().equals(oferta.getEmpresaId())) {
            throw new IllegalArgumentException("Solo puedes gestionar las ofertas de tu empresa.");
        }
        if (repositorio.listarOfertas().stream().anyMatch(actual ->
                actual.getEmpresaId().equals(oferta.getEmpresaId()) && actual.getCargo().equalsIgnoreCase(oferta.getCargo())
                && actual.getUbicacion().equalsIgnoreCase(oferta.getUbicacion()) && !actual.getId().equals(oferta.getId()))) {
            throw new IllegalArgumentException("Ya existe una oferta con ese cargo y ubicación para la empresa.");
        }
        OfertaLaboral anterior = repositorio.buscarOferta(oferta.getId());
        if (anterior != null && !anterior.getEmpresaId().equals(oferta.getEmpresaId())) {
            throw new IllegalArgumentException("Una oferta no puede cambiar de empresa.");
        }
        repositorio.guardarOferta(oferta);
    }

    public void eliminar(String id, Usuario actor) {
        OfertaLaboral oferta = requerir(id);
        validarPropiedad(oferta, actor);
        boolean tieneHistorial = repositorio.listarPostulaciones().stream()
                .anyMatch(postulacion -> postulacion.getOfertaId().equals(id));
        if (tieneHistorial) {
            oferta.setActiva(false);
            repositorio.guardarOferta(oferta);
        } else {
            repositorio.eliminarOferta(id);
        }
    }

    public void alternarEstado(String id, Usuario actor) {
        OfertaLaboral oferta = requerir(id);
        validarPropiedad(oferta, actor);
        if (oferta.estaVencida()) throw new IllegalArgumentException("La oferta está vencida. Edita su fecha límite antes de volver a publicarla.");
        oferta.setActiva(!oferta.isActiva());
        repositorio.guardarOferta(oferta);
    }

    private OfertaLaboral requerir(String id) {
        OfertaLaboral oferta = repositorio.buscarOferta(id);
        if (oferta == null) throw new IllegalArgumentException("No se encontró la oferta.");
        return oferta;
    }

    private static void validarPropiedad(OfertaLaboral oferta, Usuario actor) {
        if (actor == null || actor.getRol() == RolUsuario.TRABAJADOR)
            throw new IllegalArgumentException("Solo una empresa o el administrador puede gestionar ofertas.");
        if (actor instanceof Empresa empresa && !oferta.getEmpresaId().equals(empresa.getId()))
            throw new IllegalArgumentException("Esta oferta pertenece a otra empresa.");
    }
}
