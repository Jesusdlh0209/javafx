package co.conectaempleo.services;

import co.conectaempleo.model.OfertaLaboral;
import co.conectaempleo.model.Postulacion;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Reglas de postulación, retiro y seguimiento de procesos laborales. */
public final class PostulacionService {
    private final RepositorioLocal repositorio;

    public PostulacionService(RepositorioLocal repositorio) { this.repositorio = Objects.requireNonNull(repositorio); }
    public ArrayList<Postulacion> listar() { return repositorio.listarPostulaciones(); }

    public void postular(String ofertaId, Usuario actor) {
        if (!(actor instanceof Trabajador trabajador)) throw new IllegalArgumentException("Solo un trabajador puede postularse.");
        if (repositorio.buscarTrabajador(trabajador.getId()) == null) throw new IllegalArgumentException("Registra tu perfil antes de postularte.");
        OfertaLaboral oferta = repositorio.buscarOferta(ofertaId);
        if (oferta == null) throw new IllegalArgumentException("La oferta ya no existe.");
        if (!oferta.isActiva() || oferta.estaVencida()) throw new IllegalArgumentException("La oferta está cerrada o vencida.");
        boolean duplicada = repositorio.listarPostulaciones().stream().anyMatch(p ->
                p.getOfertaId().equals(ofertaId) && p.getTrabajadorId().equals(trabajador.getId()));
        if (duplicada) throw new IllegalArgumentException("Ya estás postulado a esta oferta.");
        String id = "POS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(java.util.Locale.ROOT);
        repositorio.guardarPostulacion(new Postulacion(id, trabajador.getId(), trabajador.getNombre(),
                oferta.getId(), oferta.getCargo(), oferta.getEmpresaId()));
    }

    public void cambiarEstado(String id, String estado, Usuario actor) {
        if (actor == null || actor.getRol() == RolUsuario.TRABAJADOR)
            throw new IllegalArgumentException("Las empresas y el administrador gestionan los estados.");
        Postulacion postulacion = buscar(id);
        if (actor.getRol() == RolUsuario.EMPRESA && !postulacion.getEmpresaId().equals(actor.getId()))
            throw new IllegalArgumentException("Esta postulación pertenece a otra empresa.");
        if (!List.of("Pendiente", "En revisión", "Seleccionado", "No seleccionado", "Retirada").contains(estado))
            throw new IllegalArgumentException("Estado no válido.");
        postulacion.setEstado(estado);
        repositorio.guardarPostulacion(postulacion);
    }

    public void retirar(String id, Usuario actor) {
        Postulacion postulacion = buscar(id);
        if (actor == null || (actor.getRol() != RolUsuario.ADMINISTRADOR
                && !(actor instanceof Trabajador && postulacion.getTrabajadorId().equals(actor.getId())))) {
            throw new IllegalArgumentException("No puedes retirar esta postulación.");
        }
        if (!"Retirada".equals(postulacion.getEstado())) {
            postulacion.setEstado("Retirada");
            repositorio.guardarPostulacion(postulacion);
        }
    }

    public Postulacion buscar(String id) {
        return repositorio.listarPostulaciones().stream().filter(x -> x.getId().equals(id)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró la postulación."));
    }
}
