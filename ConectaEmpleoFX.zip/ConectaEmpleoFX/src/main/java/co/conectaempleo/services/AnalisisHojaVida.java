package co.conectaempleo.services;

import java.util.ArrayList;

/** Resultado de una lectura local de PDF: datos técnicos y habilidades sugeridas. */
public record AnalisisHojaVida(String nombreArchivo, int paginas, String titulo,
                               int caracteresExtraidos, ArrayList<String> habilidadesSugeridas) {
    public AnalisisHojaVida {
        habilidadesSugeridas = new ArrayList<>(habilidadesSugeridas);
    }

    @Override
    public ArrayList<String> habilidadesSugeridas() {
        return new ArrayList<>(habilidadesSugeridas);
    }
}
