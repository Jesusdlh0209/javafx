package co.conectaempleo.services;

import co.conectaempleo.model.Capacitacion;
import co.conectaempleo.model.Habilidad;
import co.conectaempleo.model.MaterialReciclable;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import java.util.Objects;

/** Reglas de los catálogos de habilidades, formación y materiales. */
public final class CatalogoService {
    private final RepositorioLocal repositorio;

    public CatalogoService(RepositorioLocal repositorio) { this.repositorio = Objects.requireNonNull(repositorio); }

    public void guardar(Habilidad habilidad, Usuario actor) {
        exigirAdministrador(actor);
        if (repositorio.listarHabilidades().stream().anyMatch(x -> x.getNombre().equalsIgnoreCase(habilidad.getNombre()) && !x.getId().equals(habilidad.getId())))
            throw new IllegalArgumentException("Ya existe esa habilidad en el catálogo.");
        repositorio.guardarHabilidad(habilidad);
    }
    public void guardar(Capacitacion capacitacion, Usuario actor) {
        exigirAdministrador(actor);
        if (repositorio.listarCapacitaciones().stream().anyMatch(x -> x.getNombre().equalsIgnoreCase(capacitacion.getNombre())
                && x.getEntidad().equalsIgnoreCase(capacitacion.getEntidad()) && !x.getId().equals(capacitacion.getId())))
            throw new IllegalArgumentException("Ya existe una capacitación con ese nombre y entidad.");
        repositorio.guardarCapacitacion(capacitacion);
    }
    public void guardar(MaterialReciclable material, Usuario actor) {
        exigirAdministrador(actor);
        if (repositorio.listarMateriales().stream().anyMatch(x -> x.getNombre().equalsIgnoreCase(material.getNombre())
                && x.getCategoria().equalsIgnoreCase(material.getCategoria()) && x.getUbicacion().equalsIgnoreCase(material.getUbicacion())
                && !x.getId().equals(material.getId())))
            throw new IllegalArgumentException("Ya existe un registro igual para esa categoría y ubicación.");
        repositorio.guardarMaterial(material);
    }
    public void eliminarHabilidad(String id, Usuario actor) { exigirAdministrador(actor); repositorio.eliminarHabilidad(id); }
    public void eliminarCapacitacion(String id, Usuario actor) {
        exigirAdministrador(actor);
        Capacitacion curso = repositorio.listarCapacitaciones().stream().filter(x -> x.getId().equals(id)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró la capacitación."));
        if (!curso.getParticipantes().isEmpty()) {
            curso.setActiva(false);
            repositorio.guardarCapacitacion(curso);
            return;
        }
        repositorio.eliminarCapacitacion(id);
    }
    public void eliminarMaterial(String id, Usuario actor) { exigirAdministrador(actor); repositorio.eliminarMaterial(id); }

    public void agregarHabilidadPerfil(String habilidadId, Usuario actor) {
        if (!(actor instanceof Trabajador trabajador)) throw new IllegalArgumentException("Solo un trabajador puede editar sus habilidades.");
        Habilidad habilidad = repositorio.listarHabilidades().stream().filter(x -> x.getId().equals(habilidadId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró la habilidad."));
        trabajador.agregarHabilidad(habilidad.getNombre());
        repositorio.guardarTrabajador(trabajador);
    }

    public void inscribir(String capacitacionId, Usuario actor) {
        if (!(actor instanceof Trabajador trabajador)) throw new IllegalArgumentException("Solo un trabajador puede inscribirse.");
        if (repositorio.buscarTrabajador(trabajador.getId()) == null) throw new IllegalArgumentException("Registra tu perfil antes de inscribirte.");
        Capacitacion capacitacion = repositorio.listarCapacitaciones().stream()
                .filter(x -> x.getId().equals(capacitacionId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No se encontró la capacitación."));
        if (!capacitacion.isActiva()) throw new IllegalArgumentException("Esta capacitación está cerrada.");
        if (capacitacion.getParticipantes().contains(trabajador.getId())) throw new IllegalArgumentException("Ya tienes una inscripción en esta capacitación.");
        if (!capacitacion.getParticipantes().contains(trabajador.getId()) && !capacitacion.tieneCupos())
            throw new IllegalArgumentException("Ya no quedan cupos disponibles.");
        capacitacion.agregarParticipante(trabajador.getId());
        repositorio.guardarCapacitacion(capacitacion);
    }

    private static void exigirAdministrador(Usuario actor) {
        if (actor == null || actor.getRol() != RolUsuario.ADMINISTRADOR)
            throw new IllegalArgumentException("Solo el administrador puede gestionar este catálogo.");
    }
}
