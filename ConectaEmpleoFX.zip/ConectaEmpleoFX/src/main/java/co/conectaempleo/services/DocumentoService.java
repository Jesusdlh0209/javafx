package co.conectaempleo.services;

import co.conectaempleo.model.Documento;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import java.awt.Desktop;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

/** Gestiona hojas de vida PDF dentro del directorio local, con rutas relativas. */
public final class DocumentoService {
    private static final long MAXIMO_BYTES = 20L * 1024 * 1024;
    private final RepositorioLocal repositorio;
    private final AnalizadorPDFService analizador = new AnalizadorPDFService();

    public DocumentoService(RepositorioLocal repositorio) {
        this.repositorio = Objects.requireNonNull(repositorio);
    }

    public boolean tieneDocumento(String trabajadorId) {
        return buscar(trabajadorId) != null;
    }

    public Documento buscar(String trabajadorId) {
        return repositorio.listarDocumentos().stream()
                .filter(x -> x.getTrabajadorId().equals(trabajadorId))
                .findFirst().orElse(null);
    }

    /** Importa de forma no destructiva la ruta absoluta usada por versiones anteriores. */
    public Documento migrarRutaLegada(Trabajador trabajador) {
        if (trabajador == null || tieneDocumento(trabajador.getId()) || trabajador.getRutaHojaVida().isBlank()) return buscar(trabajador == null ? "" : trabajador.getId());
        try {
            Path anterior = Path.of(trabajador.getRutaHojaVida());
            if (!Files.isRegularFile(anterior)) return null;
            return guardarHojaVida(anterior, trabajador);
        } catch (IOException | RuntimeException ex) {
            return null;
        }
    }

    public Documento guardarHojaVida(Path origen, Usuario actor) throws IOException {
        if (!(actor instanceof Trabajador trabajador)) {
            throw new IllegalArgumentException("Solo el trabajador puede adjuntar su propia hoja de vida.");
        }
        if (repositorio.buscarTrabajador(trabajador.getId()) == null) {
            throw new IllegalArgumentException("El perfil del trabajador no está registrado.");
        }
        validarPdf(origen);
        Path carpeta = repositorio.getDirectorioDocumentos();
        Files.createDirectories(carpeta);

        Documento anterior = buscar(trabajador.getId());
        String nombre = trabajador.getId() + "-" + UUID.randomUUID() + ".pdf";
        Path temporal = carpeta.resolve(nombre + ".tmp");
        Path destino = carpeta.resolve(nombre);
        try {
            Files.copy(origen, temporal);
            mover(temporal, destino);
            Documento nuevo = new Documento("CV-" + trabajador.getId(), trabajador.getId(),
                    origen.getFileName().toString(), nombre, Files.size(destino), LocalDateTime.now());
            nuevo.setDemo(trabajador.isDemo());
            repositorio.guardarDocumento(nuevo);
            trabajador.setRutaHojaVida(nombre);
            repositorio.guardarTrabajador(trabajador);
            if (anterior != null) eliminarArchivoAnterior(anterior);
            return nuevo;
        } catch (IOException | RuntimeException ex) {
            Files.deleteIfExists(temporal);
            if (buscar(trabajador.getId()) == null
                    || !buscar(trabajador.getId()).getRutaRelativa().equals(nombre)) {
                Files.deleteIfExists(destino);
            }
            throw ex;
        }
    }

    public Path resolverRuta(Documento documento) {
        Objects.requireNonNull(documento, "documento");
        Path relativa = Path.of(documento.getRutaRelativa()).normalize();
        if (relativa.isAbsolute() || relativa.startsWith("..")) {
            throw new IllegalArgumentException("La ruta del PDF no es relativa o segura.");
        }
        Path ruta = repositorio.getDirectorioDocumentos().resolve(relativa).normalize();
        if (!ruta.startsWith(repositorio.getDirectorioDocumentos().normalize())) {
            throw new IllegalArgumentException("La ruta del PDF sale del directorio permitido.");
        }
        return ruta;
    }

    public AnalisisHojaVida analizar(String trabajadorId, Usuario actor) throws IOException {
        validarPermiso(trabajadorId, actor);
        Documento documento = buscar(trabajadorId);
        if (documento == null) documento = migrarRutaLegada(repositorio.buscarTrabajador(trabajadorId));
        if (documento == null) throw new IllegalArgumentException("Este trabajador todavía no tiene una hoja de vida PDF.");
        Path archivo = resolverRuta(documento);
        if (!Files.isRegularFile(archivo)) throw new IllegalArgumentException("El archivo PDF no está disponible en el directorio local.");
        return analizador.analizar(archivo);
    }

    public void abrir(String trabajadorId, Usuario actor) throws IOException {
        validarPermiso(trabajadorId, actor);
        Documento documento = buscar(trabajadorId);
        if (documento == null) documento = migrarRutaLegada(repositorio.buscarTrabajador(trabajadorId));
        if (documento == null) throw new IllegalArgumentException("Este trabajador todavía no tiene una hoja de vida PDF.");
        Path archivo = resolverRuta(documento);
        if (!Files.isRegularFile(archivo)) throw new IllegalArgumentException("El archivo PDF no está disponible en el directorio local.");
        if (!Desktop.isDesktopSupported()) throw new IllegalStateException("Este equipo no permite abrir documentos desde la aplicación.");
        Desktop.getDesktop().open(archivo.toFile());
    }

    public void eliminar(String trabajadorId, Usuario actor) throws IOException {
        validarPermiso(trabajadorId, actor);
        Documento documento = buscar(trabajadorId);
        if (documento == null) documento = migrarRutaLegada(repositorio.buscarTrabajador(trabajadorId));
        if (documento == null) return;
        Path archivo = resolverRuta(documento);
        repositorio.eliminarDocumento(documento.getId());
        Trabajador trabajador = repositorio.buscarTrabajador(trabajadorId);
        if (trabajador != null) {
            trabajador.setRutaHojaVida("");
            repositorio.guardarTrabajador(trabajador);
        }
        Files.deleteIfExists(archivo);
    }

    private void validarPermiso(String trabajadorId, Usuario actor) {
        Objects.requireNonNull(actor, "actor");
        if (actor.getRol() == RolUsuario.ADMINISTRADOR) return;
        if (actor instanceof Trabajador trabajador && trabajador.getId().equals(trabajadorId)) return;
        if (actor instanceof co.conectaempleo.model.Empresa empresa
                && repositorio.listarPostulaciones().stream().anyMatch(postulacion ->
                        postulacion.getTrabajadorId().equals(trabajadorId)
                        && postulacion.getEmpresaId().equals(empresa.getId()))) return;
        throw new IllegalArgumentException("No tienes permiso para acceder a esta hoja de vida.");
    }

    private void validarPdf(Path origen) throws IOException {
        if (origen == null || !Files.isRegularFile(origen)
                || !origen.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(".pdf")) {
            throw new IllegalArgumentException("Selecciona un archivo PDF válido.");
        }
        long bytes = Files.size(origen);
        if (bytes < 8 || bytes > MAXIMO_BYTES) {
            throw new IllegalArgumentException("El PDF debe pesar entre 8 bytes y 20 MB.");
        }
        byte[] cabecera = new byte[5];
        try (var flujo = Files.newInputStream(origen)) {
            if (flujo.read(cabecera) != cabecera.length
                    || !new String(cabecera, StandardCharsets.US_ASCII).equals("%PDF-")) {
                throw new IllegalArgumentException("El archivo no tiene una cabecera PDF válida.");
            }
        }
        analizador.analizar(origen); // La cabecera no basta: rechaza archivos dañados o cifrados.
    }

    private void eliminarArchivoAnterior(Documento anterior) throws IOException {
        Path archivo = resolverRuta(anterior);
        if (!archivo.equals(repositorio.getDirectorioDocumentos().resolve(anterior.getRutaRelativa()).normalize())) {
            throw new IllegalArgumentException("La ruta anterior no es válida.");
        }
        Files.deleteIfExists(archivo);
    }

    private static void mover(Path origen, Path destino) throws IOException {
        try {
            Files.move(origen, destino, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            Files.move(origen, destino, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
