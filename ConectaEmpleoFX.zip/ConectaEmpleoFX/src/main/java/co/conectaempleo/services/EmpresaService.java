package co.conectaempleo.services;

import co.conectaempleo.model.Empresa;
import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import java.util.ArrayList;
import java.util.Objects;

/** Reglas de negocio del perfil y directorio de empresas. */
public final class EmpresaService {
    private final RepositorioLocal repositorio;

    public EmpresaService(RepositorioLocal repositorio) { this.repositorio = Objects.requireNonNull(repositorio); }
    public ArrayList<Empresa> listar() { return repositorio.listarEmpresas(); }
    public Empresa buscar(String id) { return repositorio.buscarEmpresa(id); }

    public void guardar(Empresa empresa, Usuario actor) {
        Objects.requireNonNull(actor, "actor");
        if (actor.getRol() != RolUsuario.ADMINISTRADOR
                && (!(actor instanceof Empresa) || !actor.getId().equals(empresa.getId()))) {
            throw new IllegalArgumentException("Solo el administrador puede gestionar otras empresas.");
        }
        repositorio.guardarEmpresa(empresa);
    }

    public void eliminar(String id, Usuario actor) {
        exigirAdministrador(actor);
        if (repositorio.listarOfertas().stream().anyMatch(x -> x.getEmpresaId().equals(id))) {
            throw new IllegalArgumentException("No se puede eliminar esta empresa porque sus ofertas forman parte del historial. Cierra sus ofertas y conserva el registro.");
        }
        repositorio.eliminarEmpresa(id);
    }

    private static void exigirAdministrador(Usuario actor) {
        if (actor == null || actor.getRol() != RolUsuario.ADMINISTRADOR)
            throw new IllegalArgumentException("Solo el administrador puede realizar esta acción.");
    }
}
