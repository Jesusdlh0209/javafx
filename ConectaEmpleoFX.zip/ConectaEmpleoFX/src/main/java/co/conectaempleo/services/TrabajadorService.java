package co.conectaempleo.services;

import co.conectaempleo.model.RolUsuario;
import co.conectaempleo.model.Trabajador;
import co.conectaempleo.model.Usuario;
import co.conectaempleo.repository.RepositorioLocal;
import java.util.ArrayList;
import java.util.Objects;

/** Reglas de negocio del perfil y directorio de trabajadores. */
public final class TrabajadorService {
    private final RepositorioLocal repositorio;

    public TrabajadorService(RepositorioLocal repositorio) { this.repositorio = Objects.requireNonNull(repositorio); }
    public ArrayList<Trabajador> listar() { return repositorio.listarTrabajadores(); }
    public Trabajador buscar(String id) { return repositorio.buscarTrabajador(id); }

    public void guardar(Trabajador trabajador, Usuario actor) {
        Objects.requireNonNull(actor, "actor");
        if (actor.getRol() != RolUsuario.ADMINISTRADOR
                && (!(actor instanceof Trabajador) || !actor.getId().equals(trabajador.getId()))) {
            throw new IllegalArgumentException("Solo el administrador puede gestionar otros trabajadores.");
        }
        repositorio.guardarTrabajador(trabajador);
    }

    public void agregarHabilidad(String nombre, Usuario actor) {
        if (!(actor instanceof Trabajador trabajador)) throw new IllegalArgumentException("Solo un trabajador puede editar sus habilidades.");
        trabajador.agregarHabilidad(nombre);
        repositorio.guardarTrabajador(trabajador);
    }

    public void eliminar(String id, Usuario actor) {
        validarEliminacion(id, actor);
        repositorio.eliminarTrabajador(id);
    }

    public void validarEliminacion(String id, Usuario actor) {
        exigirAdministrador(actor);
        boolean tienePostulaciones = repositorio.listarPostulaciones().stream().anyMatch(x -> x.getTrabajadorId().equals(id));
        boolean inscrito = repositorio.listarCapacitaciones().stream().anyMatch(x -> x.getParticipantes().contains(id));
        if (tienePostulaciones || inscrito) {
            throw new IllegalArgumentException("No se puede eliminar este trabajador porque tiene postulaciones o inscripciones asociadas. Conserva su historial y edita el perfil si necesitas actualizarlo.");
        }
    }

    private static void exigirAdministrador(Usuario actor) {
        if (actor == null || actor.getRol() != RolUsuario.ADMINISTRADOR)
            throw new IllegalArgumentException("Solo el administrador puede realizar esta acción.");
    }
}
